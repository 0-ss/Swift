#define MyAppName "Swift"
#define MyAppVersion "0.1.0"
#define MyAppPublisher "Swift"
#define MyAppExeName "SwiftApp.exe"

[Setup]
AppId={{8B7E6F7A-7C6A-4F9E-9E4B-7A8D9B6F2A11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}

DefaultDirName={autopf}\Swift
DefaultGroupName=Swift

OutputDir=installer
OutputBaseFilename=Swift-Setup-{#MyAppVersion}

ArchitecturesInstallIn64BitMode=x64compatible
ArchitecturesAllowed=x64compatible

Compression=lzma
SolidCompression=yes

WizardStyle=modern

UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Files]
Source: "build\Release\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Swift"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Swift"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Swift"; Flags: nowait postinstall skipifsilent