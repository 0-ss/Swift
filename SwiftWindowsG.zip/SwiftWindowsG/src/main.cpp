#include "AppController.h"
#include "api/YouTubeMusicClient.h"
#include "playback/MusicPlayer.h"
#include "services/AccountService.h"
#include "services/CacheService.h"
#include "services/LibraryService.h"
#include "services/LyricsService.h"
#include "services/PlaylistService.h"
#include "services/SettingsService.h"
#include "services/SystemTrayService.h"
#include <QApplication>
#include <QIcon>
#include <QNetworkAccessManager>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QQuickWindow>
#include <QSGRendererInterface>

#ifdef Q_OS_WIN
#include <QEvent>
#include <QWindow>
#include <QtGui/qevent.h>
#include <windows.h>
#include <dwmapi.h>

// Windows 11 rounds the corners of normal windows, but a frameless window (Qt.FramelessWindowHint,
// used for the custom traffic lights) loses that. Asking DWM for rounded corners restores it.
// Windows 10 and older ignore the request, so the window simply stays square there.
class RoundedCornerFilter : public QObject
{
public:
    using QObject::QObject;

    static void apply(QWindow *window)
    {
        if (!window || !window->handle()) return; // no native window yet
        const HWND hwnd = reinterpret_cast<HWND>(window->winId());
        constexpr DWORD kCornerPreference = 33; // DWMWA_WINDOW_CORNER_PREFERENCE (older SDKs lack the name)
        constexpr DWORD kRound = 2;             // DWMWCP_ROUND
        DwmSetWindowAttribute(hwnd, kCornerPreference, &kRound, sizeof(kRound));
    }

protected:
    // Qt recreates the native window when its flags change (e.g. toggling the custom window
    // buttons in Settings), so apply again every time a native surface is created.
    bool eventFilter(QObject *watched, QEvent *event) override
    {
        if (event->type() == QEvent::PlatformSurface) {
            auto *surface = static_cast<QPlatformSurfaceEvent *>(event);
            if (surface->surfaceEventType() == QPlatformSurfaceEvent::SurfaceCreated)
                apply(qobject_cast<QWindow *>(watched));
        }
        return QObject::eventFilter(watched, event);
    }
};
#endif

int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    QGuiApplication::setOrganizationName("Swift");
    QGuiApplication::setApplicationName("Swift");
    QGuiApplication::setApplicationVersion("0.1.0");
    QQuickStyle::setStyle("Basic"); // every control is custom drawn; Basic avoids native-style overrides

    SettingsService settings;
    AccountService account(&settings);
    CacheService cache(&settings);
    LibraryService library;
    SystemTrayService systemTray;
    systemTray.setEnabled(settings.get("systemTray").toBool());
    QObject::connect(&settings, &SettingsService::changed, &systemTray,
                     [&systemTray](const QString &key, const QVariant &value) {
        if (key == "systemTray") systemTray.setEnabled(value.toBool());
    });
    app.setWindowIcon(QIcon(":/qt/qml/Swift/qml/assets/image.png"));

    QNetworkAccessManager apiNetwork;
    YouTubeMusicClient provider(&apiNetwork, &settings, &account);
    account.setProvider(&provider);
    PlaylistService playlists(&provider, &account);

    MusicPlayer player(&provider, &settings);
    AppController controller(&provider, &settings);
    LyricsService lyrics(&player, &settings);

    QObject::connect(&player, &MusicPlayer::trackStarted, &library, &LibraryService::addRecent);
    QObject::connect(&app, &QGuiApplication::aboutToQuit, &player, &MusicPlayer::saveState);

#ifdef Q_OS_WIN
    RoundedCornerFilter roundedCorners; // declared before the engine so it outlives the windows
#endif

    QQmlApplicationEngine engine; // declared last so it is destroyed first
    engine.setNetworkAccessManagerFactory(&cache);
    QQmlContext *ctx = engine.rootContext();
    ctx->setContextProperty("app", &controller);
    ctx->setContextProperty("player", &player);
    ctx->setContextProperty("library", &library);
    ctx->setContextProperty("lyrics", &lyrics);
    ctx->setContextProperty("playlists", &playlists);
    ctx->setContextProperty("settings", &settings);
    ctx->setContextProperty("account", &account);
    ctx->setContextProperty("cache", &cache);
    ctx->setContextProperty("systemTray", &systemTray);

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app,
                     [] { QCoreApplication::exit(-1); }, Qt::QueuedConnection);
    engine.loadFromModule("Swift", "Main");

#ifdef Q_OS_WIN
    for (QObject *root : engine.rootObjects()) {
        if (auto *window = qobject_cast<QWindow *>(root)) {
            window->installEventFilter(&roundedCorners);
            RoundedCornerFilter::apply(window); // in case the native window already exists
        }
    }
#endif

    return app.exec();
}
