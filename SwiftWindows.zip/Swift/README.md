# Swift

A desktop music client built with Qt 6, Qt Quick and C++20. The UI is modelled on Apple Music for
macOS: a full-height sidebar with inline search, a unified top toolbar (transport, volume and
the "LCD" now-playing display), striped song tables with hover-only row actions, an Up Next
side panel and a full-screen player. It uses no Apple assets: every icon is drawn in
`Glyph.qml`, and music data comes from the unofficial YouTube Music (InnerTube) API behind a
replaceable provider interface.

## Requirements

- Qt 6.5 or newer with: Core, Gui, Qml, Quick, QuickControls2, Network, Multimedia, Widgets and
  ShaderTools (the `QtQuick.Effects` QML module ships with Qt Quick 6.5+)
- CMake 3.21+, a C++20 compiler (GCC 11+, Clang 14+, MSVC 2022)
- Qt WebEngine Core + Widgets. This opens a private, in-app Google sign-in window and imports the
  resulting YouTube Music cookies automatically.
- [QtKeychain](https://github.com/frankosterfeld/qtkeychain) for the OS credential vault (macOS
  Keychain, Windows Credential Manager, or a Linux Secret Service backend). It is required by
  default so Swift cannot silently build an account feature that forgets the session on restart.
  On Arch Linux install `qtkeychain-qt6`; on Debian/Ubuntu install `qtkeychain-qt6-dev`.
- Optional but needed for playback of most tracks: [`yt-dlp`](https://github.com/yt-dlp/yt-dlp)
  on your `PATH` (see "Playback" below)

## Build and run

```sh
cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/Qt/6.x/<kit> -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/Swift            # build/Swift.app on macOS, build\Release\Swift.exe on Windows
```

The in-app sign-in window and persistent secure credential storage are enabled by default. After
installing QtKeychain, rerun CMake (clear the old build directory if needed), build again, and sign
in once; future launches restore the session from the system credential vault. To point CMake at a
non-standard QtKeychain installation, set
`-DQt6Keychain_DIR=/path/to/Qt6Keychain/lib/cmake/Qt6Keychain`. For a development-only build without
QtKeychain, explicitly opt out with `-DSWIFT_REQUIRE_SECURE_SESSION_STORE=OFF`; that mode warns and
keeps imported sessions in memory only. Without Qt WebEngine, configure with
`-DSWIFT_ENABLE_EMBEDDED_LOGIN=OFF`; the session-import fallback remains available.

## Layout

```text
src/api/          MusicProvider, YouTubeMusicClient (InnerTube requests + parsers), ApiRequest
                  (async JSON POST, retry policy, error mapping), Types
src/models/       SongModel, QueueModel, CollectionModel (QAbstractListModel)
src/playback/     MusicPlayer: QMediaPlayer, queue, shuffle/repeat, session restore
src/services/     AccountService (secure account session), PlaylistService (remote playlists),
                  SettingsService, LibraryService, CacheService, LyricsService (LRCLIB lookup,
                  LRC parsing, on-disk cache, current-line tracking)
src/AppController browsing facade for QML: search, home feed and collection pages
qml/              Main.qml, themes/Theme.qml, components/ and pages/
```

All networking is in C++. QML only sees `app`, `player`, `library`, `playlists`, `account`,
`settings`, `cache`, `lyrics` and `systemTray`. To swap the backend, implement `MusicProvider` and construct
it in `main.cpp`.

## Playback

`resolveStream` first asks the player endpoint for a directly playable audio URL. Web responses
usually contain signed formats instead, so Swift then runs the command in Settings > Network
(default `yt-dlp`, called with `-f bestaudio -g <url>`) and plays the URL it prints. Without that
tool, search and browsing work but most tracks report "needs a stream resolver".

Using unofficial endpoints and stream extraction may conflict with YouTube's Terms of Service.
Review them before distributing the app.

## YouTube Music account and playlists

Browsing works signed out. Connecting an account turns **Library > Playlists** into a view of the
person's actual YouTube Music playlists—not a local playlist substitute.

### Connecting

1. In **Settings > YouTube Music Account**, select **Connect**. When Qt WebEngine is available,
   Swift opens an isolated Google sign-in window and collects the required YouTube Music cookies
   itself; users do not need to copy them from another browser.
2. If a build does not include WebEngine, choose **Import Session…** and paste either a complete
   `Cookie` header or copied authenticated request headers from `music.youtube.com`. Swift extracts
   only the Cookie and `X-Goog-AuthUser` selector.
3. The app validates the connected account using `account/account_menu`. Expired/invalid sessions
   are clearly shown as reconnect-required. **Sign out** removes the credential from the keychain.

Raw credentials are never exposed to QML and are not stored in `QSettings`. With QtKeychain they
are persisted in the OS credential vault; without it they are intentionally memory-only.

### Synchronization and editing

- Swift loads the account library from `FEmusic_liked_playlists`; the page, sidebar and empty/loading
  states reflect that remote response. Use **Refresh** to fetch a current library snapshot.
- Opening a playlist fetches its actual rows and `setVideoId` values. `setVideoId` uniquely identifies
  a playlist row, so removal/reordering remains correct even when a playlist contains the same video
  more than once.
- Create, rename, description changes, delete, add, remove and reorder requests are sent to the
  authenticated `playlist/create`, `playlist/delete`, and `browse/edit_playlist` InnerTube endpoints.
- Playlist writes are **not automatically retried**: a lost response could otherwise add or move an
  item twice. The UI remains on confirmed data while a change is syncing, then reloads the playlist
  and verifies the requested result before displaying success. Timeouts/rate limits trigger a refresh
  rather than replaying a write.
- Successful edits are read back from YouTube Music, so they remain after an app restart and appear
  in YouTube Music elsewhere. Local `playlists.json` storage is no longer used.

The endpoint formats are undocumented and can change. Their request construction and response
parsers are intentionally contained in `src/api/YouTubeMusicClient.cpp`.

## Status

Implemented: shell and responsive navigation, light/dark/system themes, accent colors, player bars,
search, album/artist/playlist pages, home feed, queue controls, likes, recents, persisted playback
settings, on-disk artwork cache, account-aware YouTube Music playlist synchronization, and clear
loading/sync/error states.

Not yet:

- OS-level media controls (MPRIS, Now Playing, SMTC) and global media keys
- System tray notifications (the preference is saved but has no effect yet)
- Full account library support beyond playlists (uploads, artists, albums and liked songs)
- Background playback beyond audio continuing while the window is unfocused or minimized
- Unit tests for live InnerTube behavior; endpoint response shapes can change without notice
