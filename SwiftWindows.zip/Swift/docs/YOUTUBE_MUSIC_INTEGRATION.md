# YouTube Music integration notes

> **Scope:** implementation reference for Swift's authenticated playlist integration. These endpoints are undocumented InnerTube endpoints used by `music.youtube.com`; they can change without notice.

## Sources consulted

| Source | What it establishes |
|---|---|
| [ytmusicapi playlist reference](https://ytmusicapi.readthedocs.io/en/stable/reference/playlists.html) | Authenticated creation, title/description edits, add/remove, delete, and order operations. |
| [ytmusicapi library reference](https://ytmusicapi.readthedocs.io/en/stable/reference/library.html) | Account playlist library is fetched through a browse response. |
| [ytmusicapi browser authentication guide](https://ytmusicapi.readthedocs.io/en/stable/setup/browser.html) | Browser cookies support YouTube Music authentication; `__Secure-3PAPISID`/`SAPISID` is used to calculate `SAPISIDHASH`. |
| [ytmusicapi source: `playlists.py`](https://github.com/sigma67/ytmusicapi) | Playlist row removal uses a unique `setVideoId`; reorder uses `ACTION_MOVE_VIDEO_BEFORE` plus `movedSetVideoIdSuccessor`. |
| [YouTube Music Help: edit a playlist](https://support.google.com/youtubemusic/answer/7205933?hl=en) | User-facing YouTube Music behavior supports title changes, additions, removals and reordering. |

## Request model used by Swift

- **Account validation:** `account/account_menu` with an authenticated web-remix context.
- **Playlist library:** `browse` with `browseId: FEmusic_liked_playlists`; pagination follows continuation tokens in the response.
- **Playlist detail:** `browse` with `browseId: VL<playlistId>`. The response exposes each playlist row's `setVideoId` inside its edit action.
- **Writes:** `playlist/create`, `playlist/delete`, and `browse/edit_playlist` with `ACTION_SET_PLAYLIST_NAME`, `ACTION_SET_PLAYLIST_DESCRIPTION`, `ACTION_ADD_VIDEO`, `ACTION_REMOVE_VIDEO`, and `ACTION_MOVE_VIDEO_BEFORE`.
- **Continuation requests:** preserve the original browse body and append both `ctoken=<token>` and `continuation=<token>` query parameters, matching `ytmusicapi`'s `get_continuation_string` implementation.

## Reliability rules

1. Use the browser-cookie `SAPISIDHASH` authorization header and never expose raw cookies to QML.
2. Persist credentials only through QtKeychain. The constrained no-keychain build uses memory only rather than a plaintext fallback.
3. Do **not** automatically retry a playlist write. A request may have reached YouTube Music even if its response is lost.
4. Read the affected playlist again after a successful write and verify the requested name, membership, `setVideoId` removal, or row order before presenting a synchronized state.
5. Read the target playlist before adding tracks so stale UI state cannot cause duplicate additions. De-duplicate only request video IDs; do not de-duplicate returned playlist rows, since a YouTube Music playlist can legitimately contain repeated videos.
