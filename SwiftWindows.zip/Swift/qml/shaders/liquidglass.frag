#version 440
// Liquid Glass for the floating player bar.
//
// Draws, in one pass: a soft drop shadow, the glass body (lens refraction of an already-blurred
// backdrop with chromatic dispersion, tint, sheen) and the lit rim (two opposing specular
// highlights plus a faint inner glow), all from a rounded-rectangle signed distance field.
//
// The effect item is the bar grown by `pad` px on every side. `source` is the blurred backdrop
// at exactly that padded size, so texture coordinates map 1:1 onto the effect item.

layout(location = 0) in vec2 qt_TexCoord0;
layout(location = 0) out vec4 fragColor;

layout(std140, binding = 0) uniform buf {
    mat4 qt_Matrix;
    float qt_Opacity;
    vec2 barSize;        // glass size in px
    vec2 lightDir;       // unit vector from the bar towards the light (screen space, y down)
    vec2 spotPos;        // light hotspot, px relative to the bar centre
    float spot;          // hotspot strength 0..1
    float radius;        // corner radius in px
    float pad;           // padding around the bar in px
    float dark;          // 1.0 in dark mode
    float refraction;    // max lens displacement in px
    float bezel;         // width of the lens zone in px
    float dispersion;    // chromatic split, e.g. 0.12
    float rimStrength;   // specular rim brightness
    float shadowStrength;
    float shadowBlur;    // px
    float shadowOffsetY; // px
    vec4 tint;           // non-premultiplied glass tint
    vec4 base;           // opaque colour used where the backdrop is empty
};

layout(binding = 1) uniform sampler2D source;   // lightly blurred backdrop (glass body)
layout(binding = 2) uniform sampler2D sharp;    // the same backdrop, unblurred (edge reflections)

float sdRoundRect(vec2 p, vec2 halfSize, float r) {
    vec2 q = abs(p) - (halfSize - vec2(r));
    return length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}

// outward unit normal of the rounded rectangle at p
vec2 outwardNormal(vec2 p, vec2 halfSize, float r) {
    vec2 q = abs(p) - (halfSize - vec2(r));
    vec2 n = (q.x > 0.0 && q.y > 0.0) ? normalize(q)
           : (q.x > q.y ? vec2(1.0, 0.0) : vec2(0.0, 1.0));
    vec2 s = vec2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);
    return n * s;
}

vec3 backdropAt(vec2 px, vec2 full) {
    vec2 uv = clamp(px / full, vec2(0.001), vec2(0.999));
    vec4 s = texture(source, uv);
    return s.rgb + base.rgb * (1.0 - s.a);   // texture is premultiplied
}

vec3 sharpAt(vec2 px, vec2 full) {
    vec2 uv = clamp(px / full, vec2(0.001), vec2(0.999));
    vec4 s = texture(sharp, uv);
    return s.rgb + base.rgb * (1.0 - s.a);
}

// three taps along the edge tangent: keeps the mirrored content crisp but not aliased
vec3 sharpSoft(vec2 px, vec2 tang, vec2 full) {
    return 0.5 * sharpAt(px, full) + 0.25 * sharpAt(px + tang * 1.6, full) + 0.25 * sharpAt(px - tang * 1.6, full);
}

void main() {
    vec2 full = barSize + vec2(2.0 * pad);
    vec2 px = qt_TexCoord0 * full;
    vec2 p = px - 0.5 * full;
    vec2 hs = 0.5 * barSize;

    float d = sdRoundRect(p, hs, radius);          // < 0 inside the glass
    float inside = 1.0 - smoothstep(-0.75, 0.75, d);
    float depth = max(-d, 0.0);                    // px in from the edge

    // ---- drop shadow (only visible outside the glass) ---------------------------------------
    float sd = sdRoundRect(p - vec2(0.0, shadowOffsetY), hs, radius);
    float shadow = (1.0 - smoothstep(-0.4 * shadowBlur, shadowBlur, sd));
    shadow *= shadow * shadowStrength;

    // ---- lens refraction ---------------------------------------------------------------------
    vec2 n = outwardNormal(p, hs, radius);
    float t = clamp(depth / bezel, 0.0, 1.0);
    float u = 1.0 - t;
    float lens = 1.0 - sqrt(max(1.0 - u * u, 0.0));   // convex bezel: steep at the edge, flat inside
    lens = pow(lens, 1.35);
    vec2 shift = n * (refraction * lens);

    vec3 col;
    col.r = backdropAt(px + shift * (1.0 + dispersion), full).r;
    col.g = backdropAt(px + shift, full).g;
    col.b = backdropAt(px + shift * (1.0 - dispersion), full).b;

    // Near the edge the glass stops being frosted: the real, unblurred content bends through it.
    float em = pow(1.0 - smoothstep(0.0, 26.0, depth), 1.3);           // 1 at the edge, 0 inside
    float vw = smoothstep(0.30, 0.90, abs(n.y));                       // top and bottom edges
    vec2 tang = vec2(-n.y, n.x);
    vec3 sh;
    sh.r = sharpSoft(px + shift * (1.0 + dispersion), tang, full).r;
    sh.g = sharpSoft(px + shift, tang, full).g;
    sh.b = sharpSoft(px + shift * (1.0 - dispersion), tang, full).b;
    col = mix(col, sh, em * (0.45 + 0.30 * vw));

    // regular-variant tint, a touch of extra vibrancy like the system material
    float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));
    col = mix(vec3(luma), col, 1.12);
    col = mix(col, tint.rgb, tint.a);

    vec2 L = normalize(lightDir);
    float ndl = dot(n, L);
    float lit = pow(max(ndl, 0.0), 2.5);         // edges facing the light
    float back = pow(max(-ndl, 0.0), 2.5);       // opposite edges catch light bent through the glass
    float facing = abs(ndl);

    // soft top-down sheen and faint inner glow near the rim
    float vy = (p.y + hs.y) / barSize.y;
    col += (dark > 0.5 ? 0.03 : 0.045) * (1.0 - smoothstep(0.1, 0.9, vy));
    col += vec3(exp(-depth / 7.0) * (dark > 0.5 ? 0.05 : 0.065));

    // ---- reflection: what is beyond the edge is mirrored back into the rim --------------------
    // Along the top and bottom edges the page content just outside the bar is flipped across
    // the edge and shown, crisp, inside the rim, as on Apple's glass.
    float mirrorDist = 1.8 * depth + 6.0;
    vec3 refl = sharpSoft(px + n * mirrorDist, tang, full);
    vec3 refl2 = sharpSoft(px + n * (mirrorDist + 16.0), tang, full);    // a second, deeper bounce
    float reflMask = pow(1.0 - smoothstep(0.0, 28.0, depth), 1.15) * (0.35 + 0.65 * vw);
    vec3 reflCol = mix(refl, refl2, 0.35);
    col = mix(col, reflCol, reflMask * (dark > 0.5 ? 0.62 : 0.55));
    col += reflCol * reflMask * (0.10 + 0.14 * lit + 0.08 * back);       // a little light through the bounce

    // ---- gloss streak: a broad reflection band that slides as the light moves -----------------
    float along = dot(p, L) / (0.5 * barSize.x);
    float streak = exp(-pow((along + 0.15) * 2.4, 2.0));
    streak += 0.45 * exp(-pow((along - 0.62) * 5.0, 2.0));
    col += vec3(streak * (dark > 0.5 ? 0.05 : 0.075)) * (0.55 + 0.45 * smoothstep(0.0, 1.0, 1.0 - vy));

    // ---- specular rim: sharp line on the lit edge, weaker on the opposite one ----------------
    float spec = rimStrength * (0.16 + 0.84 * lit + 0.55 * back);
    float rim = exp(-depth / 0.9) * spec + exp(-depth / 4.5) * spec * 0.24;
    col += vec3(rim);

    // ---- cursor hotspot: the glass lights up under the pointer ---------------------------------
    vec2 sp = p - spotPos;
    float sr = dot(sp, sp);
    float glow = exp(-sr / (2.0 * 62.0 * 62.0));
    float tight = exp(-sr / (2.0 * 16.0 * 16.0));
    float edgeBoost = 1.0 + 1.6 * exp(-depth / 6.0);     // the rim brightens most near the cursor
    col += vec3((glow * 0.10 + tight * 0.06) * edgeBoost * spot * (dark > 0.5 ? 1.0 : 1.2));

    // very thin dark inner edge on the unlit sides keeps the shape readable on light content
    col *= 1.0 - (1.0 - facing) * 0.07 * exp(-depth / 1.6) * (1.0 - dark * 0.5);

    col = clamp(col, 0.0, 1.0);

    float a = inside + shadow * (1.0 - inside);
    fragColor = vec4(col * inside, a) * qt_Opacity;   // shadow is black, so rgb stays col * inside
}
