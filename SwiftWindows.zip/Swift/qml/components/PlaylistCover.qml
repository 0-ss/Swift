import QtQuick
import QtQuick.Effects
import Swift

// Playlist artwork: a 2x2 collage once the playlist has four different covers, a single
// cover for one to three, and a neutral placeholder when empty. Children draw on top.
Item {
    id: c
    property var covers: []
    property real corner: Theme.rLg
    readonly property int n: covers ? covers.length : 0
    default property alias overlay: host.data

    // placeholder
    Rectangle {
        anchors.fill: parent
        visible: c.n === 0
        radius: c.corner
        color: Theme.fill
        Glyph {
            anchors.centerIn: parent
            name: "playlist"
            size: Math.max(10, c.width * 0.34)
            color: Theme.textTertiary
        }
        Rectangle {
            anchors.fill: parent
            radius: c.corner
            color: "transparent"
            border.width: 1
            border.color: Theme.dark ? "#1FFFFFFF" : "#1A000000"
        }
    }

    // one to three covers: the first one
    Artwork {
        anchors.fill: parent
        visible: c.n > 0 && c.n < 4
        source: c.n > 0 ? c.covers[0] : ""
        corner: c.corner
    }

    // four covers: collage, masked to the rounded outline
    Item {
        id: collage
        anchors.fill: parent
        visible: false
        Repeater {
            model: c.n >= 4 ? 4 : 0
            delegate: Image {
                x: (index % 2) * (collage.width / 2)
                y: Math.floor(index / 2) * (collage.height / 2)
                width: collage.width / 2
                height: collage.height / 2
                source: c.covers[index]
                asynchronous: true
                fillMode: Image.PreserveAspectCrop
                sourceSize.width: Math.ceil(width * 2)
                sourceSize.height: Math.ceil(height * 2)
            }
        }
    }
    Item {
        id: mask
        anchors.fill: parent
        visible: false
        layer.enabled: true
        Rectangle { anchors.fill: parent; radius: c.corner; color: "black" }
    }
    MultiEffect {
        anchors.fill: parent
        visible: c.n >= 4
        source: collage
        maskEnabled: true
        maskSource: mask
    }
    Rectangle {
        anchors.fill: parent
        visible: c.n >= 4
        radius: c.corner
        color: "transparent"
        border.width: 1
        border.color: Theme.dark ? "#1FFFFFFF" : "#1A000000"
    }

    Item { id: host; anchors.fill: parent }
}
