import QtQuick
import QtQuick.Controls
import Swift

MenuSeparator {
    topPadding: 4
    bottomPadding: 4
    height: visible ? implicitHeight : 0
    contentItem: Rectangle { implicitWidth: 190; implicitHeight: 1; color: Theme.separator }
}
