import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

// Sheet for real YouTube Music playlist creation/editing. Creation stays open
// until the service receives an acknowledged playlist ID from YouTube Music.
Popup {
    id: p
    property string playlistId: ""
    property var pendingTracks: []
    property bool submitting: false
    readonly property bool creating: playlistId === ""
    readonly property var covers: {
        if (!creating) return playlists.info(playlistId).covers || []
        const out = []
        for (const t of pendingTracks)
            if (t.artworkUrl && out.indexOf(t.artworkUrl) < 0 && out.length < 4) out.push(t.artworkUrl)
        return out
    }
    signal created(string id, bool withTracks)

    function openCreate(tracks) {
        playlistId = ""
        pendingTracks = tracks || []
        submitting = false
        nameField.text = ""
        descField.text = ""
        open()
    }
    function openEdit(id) {
        const info = playlists.info(id)
        playlistId = id
        pendingTracks = []
        submitting = false
        nameField.text = info.name
        descField.text = info.description
        open()
    }
    function completeCreate(id) {
        if (!creating || !submitting) return
        const had = pendingTracks.length > 0
        submitting = false
        close()
        created(id, had)
    }
    function commit() {
        const name = nameField.text.trim()
        const desc = descField.text.trim()
        if (creating) {
            submitting = true
            playlists.create(name, desc, pendingTracks)
        } else {
            if (name.length === 0) return
            playlists.edit(playlistId, name, desc)
            close()
        }
    }

    parent: Overlay.overlay
    anchors.centerIn: Overlay.overlay
    modal: true
    focus: true
    padding: 22
    width: Math.min(440, (parent ? parent.width : 440) - 48)
    onOpened: { nameField.forceActiveFocus(); nameField.selectAll() }
    onClosed: submitting = false

    enter: Transition {
        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.base }
        NumberAnimation { property: "scale"; from: 0.96; to: 1; duration: Theme.base; easing.type: Easing.OutCubic }
    }
    exit: Transition { NumberAnimation { property: "opacity"; from: 1; to: 0; duration: Theme.fast } }
    Overlay.modal: Rectangle { color: Theme.alpha("#000000", Theme.dark ? 0.5 : 0.28) }

    background: Rectangle { radius: Theme.rXl + 2; color: Theme.menu; border.width: 1; border.color: Theme.dark ? "#4A4A4C" : "#D4D4D7" }

    component FieldBox: Rectangle {
        property alias field: holder.data
        property bool focused: false
        radius: Theme.rSm + 1
        color: Theme.dark ? "#1E1E1E" : "#FFFFFF"
        border.width: focused ? 2 : 1
        border.color: focused ? Theme.accent : Theme.separator
        Item { id: holder; anchors.fill: parent }
    }

    contentItem: ColumnLayout {
        spacing: 16
        Text { Layout.fillWidth: true; text: p.creating ? "New Playlist" : "Edit Playlist"; color: Theme.text; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody + 4; font.weight: Font.Bold }
        RowLayout {
            Layout.fillWidth: true; spacing: 16
            PlaylistCover { Layout.preferredWidth: 96; Layout.preferredHeight: 96; Layout.alignment: Qt.AlignTop; covers: p.covers; corner: Theme.rMd }
            ColumnLayout {
                Layout.fillWidth: true; spacing: 6
                Text { text: "Name"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall + 1; font.weight: Font.DemiBold }
                FieldBox {
                    Layout.fillWidth: true; implicitHeight: 28; focused: nameField.activeFocus
                    field: TextField {
                        id: nameField; anchors.fill: parent; leftPadding: 8; rightPadding: 8; background: null
                        placeholderText: "Untitled Playlist"; placeholderTextColor: Theme.textTertiary; color: Theme.text
                        font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody; selectByMouse: true; maximumLength: 80
                        verticalAlignment: TextInput.AlignVCenter; enabled: !p.submitting; onAccepted: p.commit()
                    }
                }
                Text { text: "Description"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall + 1; font.weight: Font.DemiBold; Layout.topMargin: 4 }
                FieldBox {
                    Layout.fillWidth: true; implicitHeight: 62; focused: descField.activeFocus
                    field: TextArea {
                        id: descField; anchors.fill: parent; leftPadding: 8; rightPadding: 8; topPadding: 6; bottomPadding: 6; background: null
                        placeholderText: "Optional"; placeholderTextColor: Theme.textTertiary; color: Theme.text
                        font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody; wrapMode: TextEdit.Wrap; selectByMouse: true; enabled: !p.submitting
                    }
                }
            }
        }
        Text {
            visible: p.creating && p.pendingTracks.length > 0; Layout.fillWidth: true
            text: p.pendingTracks.length === 1 ? "1 song will be added to YouTube Music." : p.pendingTracks.length + " songs will be added to YouTube Music."
            color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody
        }
        Text {
            visible: p.submitting; Layout.fillWidth: true; text: "Creating the playlist in YouTube Music…"
            color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody
        }
        RowLayout {
            Layout.fillWidth: true; Layout.topMargin: 2; spacing: 10
            Item { Layout.fillWidth: true }
            PillButton { text: "Cancel"; enabled: !p.submitting; onClicked: p.close() }
            PillButton { text: p.creating ? "Create" : "Save"; prominent: true; enabled: !p.submitting && (p.creating || nameField.text.trim().length > 0); onClicked: p.commit() }
        }
    }
}
