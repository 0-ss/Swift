import QtQuick
import QtQuick.Layouts
import Swift

// Compact row for the Up Next panel.
Rectangle {
    id: q
    property string title
    property string artist
    property url artworkUrl
    property bool isCurrent: false
    property bool editable: true
    property bool canMoveUp: true
    property bool canMoveDown: true
    signal activated()
    signal moveUp()
    signal moveDown()
    signal removed()

    readonly property bool hovered: hover.hovered
    implicitHeight: 52
    radius: Theme.rSm
    color: hovered ? Theme.hover : "transparent"
    HoverHandler { id: hover }
    MouseArea { anchors.fill: parent; onDoubleClicked: q.activated() }
    Accessible.role: Accessible.ListItem
    Accessible.name: title + ", " + artist

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 8
        anchors.rightMargin: 6
        spacing: 10
        Artwork {
            Layout.preferredWidth: 38; Layout.preferredHeight: 38
            source: q.artworkUrl
            corner: Theme.rSm
            Rectangle {
                anchors.fill: parent
                radius: Theme.rSm
                color: Theme.alpha("#000000", 0.45)
                visible: q.hovered || q.isCurrent
                Glyph { visible: q.hovered; anchors.centerIn: parent; anchors.horizontalCenterOffset: 1; name: "play"; size: 14; color: "white" }
                Equalizer { visible: !q.hovered && q.isCurrent; anchors.centerIn: parent; color: "white"; running: player.playing }
            }
            MouseArea { anchors.fill: parent; enabled: q.hovered; onClicked: q.activated() }
        }
        ColumnLayout {
            Layout.fillWidth: true
            spacing: 1
            Text {
                Layout.fillWidth: true
                text: q.title
                elide: Text.ElideRight
                color: q.isCurrent ? Theme.accent : Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
            }
            Text {
                Layout.fillWidth: true
                text: q.artist
                elide: Text.ElideRight
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody - 1
            }
        }
        Row {
            visible: q.hovered && q.editable
            spacing: 0
            IconButton { glyph: "chevronUp"; size: 13; implicitWidth: 22; implicitHeight: 22; tip: "Move up"; color: Theme.textSecondary; enabled: q.canMoveUp; onClicked: q.moveUp() }
            IconButton { glyph: "chevronDown"; size: 13; implicitWidth: 22; implicitHeight: 22; tip: "Move down"; color: Theme.textSecondary; enabled: q.canMoveDown; onClicked: q.moveDown() }
            IconButton { glyph: "close"; size: 10; implicitWidth: 22; implicitHeight: 22; tip: "Remove from Up Next"; color: Theme.textSecondary; onClicked: q.removed() }
        }
    }
}
