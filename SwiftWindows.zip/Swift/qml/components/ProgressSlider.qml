import QtQuick
import Swift

// Thin neutral scrubber / volume slider. The knob only appears on hover or drag.
Item {
    id: s
    property real from: 0
    property real to: 1
    property real value: 0
    property bool dragging: ma.pressed
    property color fillColor: Theme.sliderFill
    property color trackColor: Theme.sliderTrack
    property color knobColor: "white"
    readonly property real shown: dragging ? dragValue : value
    property real dragValue: 0
    signal moved(real value)      // continuous while dragging
    signal committed(real value)  // on release

    implicitHeight: 16
    implicitWidth: 120
    activeFocusOnTab: true
    Accessible.role: Accessible.Slider

    readonly property real ratio: to > from ? Math.max(0, Math.min(1, (shown - from) / (to - from))) : 0
    function valueAt(x) { return from + Math.max(0, Math.min(1, x / width)) * (to - from) }

    Keys.onLeftPressed: s.committed(Math.max(from, value - (to - from) * 0.02))
    Keys.onRightPressed: s.committed(Math.min(to, value + (to - from) * 0.02))

    Rectangle {
        id: track
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width
        height: ma.containsMouse || s.dragging ? 5 : 3
        radius: height / 2
        color: s.trackColor
        Behavior on height { NumberAnimation { duration: Theme.fast } }
        Rectangle {
            width: parent.width * s.ratio
            height: parent.height
            radius: parent.radius
            color: s.fillColor
        }
    }
    Rectangle {
        width: 10; height: 10; radius: 5
        x: track.width * s.ratio - width / 2
        anchors.verticalCenter: parent.verticalCenter
        color: s.knobColor
        border.color: Theme.alpha("#000000", 0.25)
        border.width: 1
        opacity: ma.containsMouse || s.dragging || s.activeFocus ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Theme.fast } }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        onPressed: (m) => { s.dragValue = s.valueAt(m.x); s.moved(s.dragValue) }
        onPositionChanged: (m) => { if (pressed) { s.dragValue = s.valueAt(m.x); s.moved(s.dragValue) } }
        onReleased: s.committed(s.dragValue)
    }
}
