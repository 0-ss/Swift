import QtQuick
import QtQuick.Layouts
import Swift

// Titled horizontal shelf with paging arrows, like the rows on Music's Home page.
ColumnLayout {
    id: s
    property string title
    property alias model: list.model
    property alias delegate: list.delegate
    property real cardWidth: 176
    readonly property bool hasModel: list.count > 0
    // The row runs edge to edge: it starts under the glass sidebar and ends at the window edge,
    // while the first card still lines up with the page title.
    readonly property real bleedLeft: s.parent ? s.parent.x : 0
    readonly property real bleedRight: s.parent && s.parent.parent
                                       ? Math.max(0, s.parent.parent.width - s.parent.x - s.parent.width) : 0
    spacing: 10
    Layout.fillWidth: true

    RowLayout {
        Layout.fillWidth: true
        SectionHeader { Layout.fillWidth: true; text: s.title }
        IconButton {
            glyph: "chevronLeft"; size: 14; tip: "Scroll left"
            implicitWidth: 26; implicitHeight: 26
            color: Theme.textSecondary
            enabled: list.contentX > list.originX - list.leftMargin + 1
            onClicked: s.page(-1)
        }
        IconButton {
            glyph: "chevronRight"; size: 14; tip: "Scroll right"
            implicitWidth: 26; implicitHeight: 26
            color: Theme.textSecondary
            enabled: list.contentX < list.originX + list.contentWidth - list.width + list.rightMargin - 1
            onClicked: s.page(1)
        }
    }

    function page(dir) {
        const lo = list.originX - list.leftMargin
        const hi = list.originX + list.contentWidth - list.width + list.rightMargin
        const target = Math.max(lo, Math.min(Math.max(lo, hi),
                                             list.contentX + dir * Math.max(1, list.width - s.bleedLeft - s.cardWidth)))
        scroll.to = target
        scroll.restart()
    }
    NumberAnimation { id: scroll; target: list; property: "contentX"; duration: Theme.base * 1.5; easing.type: Easing.OutCubic }

    Item {
        Layout.fillWidth: true
        Layout.preferredHeight: s.cardWidth + 56

        ListView {
            id: list
            x: -s.bleedLeft
            width: parent.width + s.bleedLeft + s.bleedRight
            height: parent.height
            leftMargin: s.bleedLeft
            rightMargin: s.bleedRight
            // Keep the first card aligned with the page title while the margin settles
            // (sidebar sliding, window resized) if the row is still at its start.
            property real prevLeftMargin: 0
            onLeftMarginChanged: {
                if (!dragging && !moving && Math.abs(contentX - (originX - prevLeftMargin)) < 1.5)
                    contentX = originX - leftMargin
                prevLeftMargin = leftMargin
            }
            orientation: ListView.Horizontal
            spacing: 18
            clip: true
            boundsBehavior: Flickable.StopAtBounds
        }
    }
}
