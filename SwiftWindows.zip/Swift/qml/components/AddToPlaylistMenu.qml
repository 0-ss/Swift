import QtQuick
import QtQuick.Controls
import QtQml
import Swift

// "New Playlist…" followed by every playlist. Used as a submenu in song menus and
// as a stand-alone popup for "Add to Playlist" buttons.
StyledMenu {
    id: m
    title: "Add to Playlist"
    signal picked(string id)
    signal newRequested()

    MenuRow { text: "New Playlist…"; onTriggered: m.newRequested() }
    MenuDivider {}

    Instantiator {
        model: playlists.playlists
        delegate: MenuRow {
            text: model.name
            onTriggered: m.picked(model.playlistId)
        }
        onObjectAdded: (index, object) => m.insertItem(index + 2, object)
        onObjectRemoved: (index, object) => m.removeItem(object)
    }
}
