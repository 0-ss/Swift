import QtQuick
import QtQuick.Effects
import Swift

// Cover art with genuinely rounded corners (masked), a hairline outline and a
// placeholder glyph while loading. Children are placed in an overlay on top.
Item {
    id: a
    property url source
    property real corner: Theme.rMd
    property bool round: false
    property bool outline: true
    readonly property real radius: round ? Math.min(width, height) / 2 : corner
    default property alias overlay: overlayHost.data

    Rectangle {
        anchors.fill: parent
        radius: a.radius
        color: Theme.fill
        Glyph {
            anchors.centerIn: parent
            name: "note"
            size: Math.max(8, Math.min(a.width, a.height) * 0.36)
            color: Theme.textSecondary
            opacity: img.status === Image.Ready ? 0 : 0.6
        }
    }
    Image {
        id: img
        anchors.fill: parent
        source: a.source
        asynchronous: true
        fillMode: Image.PreserveAspectCrop
        sourceSize.width: Math.ceil(a.width * 2)
        sourceSize.height: Math.ceil(a.height * 2)
        visible: false
    }
    Item {
        id: maskItem
        anchors.fill: parent
        visible: false
        layer.enabled: true
        Rectangle { anchors.fill: parent; radius: a.radius; color: "black" }
    }
    MultiEffect {
        anchors.fill: parent
        source: img
        maskEnabled: true
        maskSource: maskItem
        opacity: img.status === Image.Ready ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: Theme.base } }
    }
    Rectangle {
        anchors.fill: parent
        radius: a.radius
        color: "transparent"
        visible: a.outline
        border.width: 1
        border.color: Theme.dark ? "#1FFFFFFF" : "#1A000000"
    }
    Item { id: overlayHost; anchors.fill: parent }
}
