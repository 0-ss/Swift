import QtQuick
import Swift

// macOS-style window controls: close, minimize, zoom. 12 pt discs on a 20 pt pitch.
// At rest they are plain coloured discs (gray while the window is inactive); when the
// pointer is over the group their glyphs fade in. `window` is the ApplicationWindow.
Item {
    id: tl
    required property var window

    readonly property bool groupHovered: groupHover.hovered
    readonly property bool windowActive: window.active
    readonly property bool zoomed: window.visibility === Window.Maximized
                                   || window.visibility === Window.FullScreen

    readonly property int diameter: 12
    readonly property int gap: 8

    implicitWidth: diameter * 3 + gap * 2
    implicitHeight: diameter
    width: implicitWidth
    height: implicitHeight

    function toggleZoom(altHeld) {
        if (altHeld) {                       // Option-click: true full screen, like macOS
            if (window.visibility === Window.FullScreen) window.showNormal()
            else window.showFullScreen()
        } else if (zoomed) {
            window.showNormal()              // Qt restores the previous normal geometry
        } else {
            window.showMaximized()
        }
    }

    // Hover is tracked for the whole group (gaps included), so the glyphs appear together.
    HoverHandler { id: groupHover; margin: 3 }

    component Light: Item {
        id: light
        required property Item group
        property color base            // fill colour when active
        property color rim             // hairline edge
        property color glyphColor      // colour of the symbol
        property string kind           // "close" | "minimize" | "zoom"
        property string label
        signal activated(bool altHeld)

        width: group.diameter
        height: group.diameter
        Accessible.role: Accessible.Button
        Accessible.name: label

        readonly property bool lit: group.windowActive || group.groupHovered
        readonly property color inactive: Theme.dark ? "#5A5A5C" : "#CFCFD1"
        readonly property color inactiveRim: Theme.dark ? "#6A6A6C" : "#B9B9BB"
        readonly property color fill: lit ? base : inactive
        readonly property color edge: lit ? rim : inactiveRim

        Rectangle {
            id: disc
            anchors.fill: parent
            radius: width / 2
            antialiasing: true
            // pressed: a touch darker; hover: slightly more present than at rest
            opacity: ma.pressed ? 1 : light.group.groupHovered ? 1 : 0.9
            color: ma.pressed ? Qt.darker(light.fill, 1.22) : light.fill
            border.width: 0.5
            border.color: ma.pressed ? Qt.darker(light.edge, 1.22) : light.edge
            Behavior on color { ColorAnimation { duration: 70 } }
            Behavior on opacity { NumberAnimation { duration: Theme.fast } }
        }

        Canvas {
            id: symbol
            anchors.centerIn: parent
            width: light.group.diameter
            height: light.group.diameter
            // render at device resolution so the 1 px strokes stay crisp on HiDPI screens
            readonly property real dpr: Screen.devicePixelRatio
            canvasSize: Qt.size(width * dpr, height * dpr)
            opacity: light.group.groupHovered ? (ma.pressed ? 0.8 : 1) : 0
            Behavior on opacity { NumberAnimation { duration: Theme.fast } }

            property bool restored: light.group.zoomed
            onRestoredChanged: requestPaint()
            onDprChanged: requestPaint()
            Connections { target: light; function onGlyphColorChanged() { symbol.requestPaint() } }

            onPaint: {
                const ctx = getContext("2d")
                ctx.reset()
                ctx.scale(dpr, dpr)
                ctx.strokeStyle = light.glyphColor
                ctx.fillStyle = light.glyphColor
                ctx.lineWidth = 1.2
                ctx.lineCap = "round"
                const line = (x1, y1, x2, y2) => {
                    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke()
                }
                const tri = (pts) => {
                    ctx.beginPath(); ctx.moveTo(pts[0], pts[1])
                    ctx.lineTo(pts[2], pts[3]); ctx.lineTo(pts[4], pts[5])
                    ctx.closePath(); ctx.fill()
                }
                if (light.kind === "close") {
                    line(3.9, 3.9, 8.1, 8.1)
                    line(8.1, 3.9, 3.9, 8.1)
                } else if (light.kind === "minimize") {
                    line(3.2, 6, 8.8, 6)
                } else {
                    // two triangles: pointing outward (expand) or inward (restore)
                    const ne = [8.6, 3.4, 5.6, 3.4, 8.6, 6.4]
                    const sw = [3.4, 8.6, 6.4, 8.6, 3.4, 5.6]
                    if (!light.group.zoomed) { tri(ne); tri(sw) }
                    else {
                        // point reflection through each triangle's centroid flips the arrows inward
                        const flip = (t) => {
                            const cx = (t[0] + t[2] + t[4]) / 3, cy = (t[1] + t[3] + t[5]) / 3
                            return [2*cx - t[0], 2*cy - t[1], 2*cx - t[2], 2*cy - t[3], 2*cx - t[4], 2*cy - t[5]]
                        }
                        tri(flip(ne)); tri(flip(sw))
                    }
                }
            }
        }

        MouseArea {
            id: ma
            anchors.fill: parent
            anchors.margins: -3          // forgiving hit area; still inside the group's hover margin
            hoverEnabled: true
            acceptedButtons: Qt.LeftButton
            onClicked: (mouse) => light.activated((mouse.modifiers & Qt.AltModifier) !== 0)
        }
    }

    Row {
        spacing: tl.gap
        Light {
            group: tl
            kind: "close"; label: "Close"
            base: "#FF5F57"; rim: "#E0443E"; glyphColor: "#4C0002"
            onActivated: tl.window.close()
        }
        Light {
            group: tl
            kind: "minimize"; label: "Minimize"
            base: "#FEBC2E"; rim: "#DEA123"; glyphColor: "#5A3A00"
            onActivated: tl.window.showMinimized()
        }
        Light {
            group: tl
            kind: "zoom"; label: tl.zoomed ? "Restore" : "Zoom"
            base: "#28C840"; rim: "#1AAB29"; glyphColor: "#06400F"
            onActivated: (altHeld) => tl.toggleZoom(altHeld)
        }
    }
}
