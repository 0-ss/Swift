import QtQuick
import QtQuick.Controls
import Swift

StyledMenu {
    id: m
    property bool empty: false
    signal play()
    signal shuffle()
    signal edit()
    signal remove()

    MenuRow { text: "Play"; enabled: !m.empty; onTriggered: m.play() }
    MenuRow { text: "Shuffle"; enabled: !m.empty; onTriggered: m.shuffle() }
    MenuDivider {}
    MenuRow { text: "Edit Playlist…"; onTriggered: m.edit() }
    MenuRow { text: "Delete Playlist"; onTriggered: m.remove() }
}
