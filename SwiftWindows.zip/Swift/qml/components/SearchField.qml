import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

// Sidebar search field. Searches as you type (debounced) and immediately on Return.
Rectangle {
    id: f
    property alias text: input.text
    property alias field: input
    signal submitted(string text)

    implicitHeight: 28
    implicitWidth: 200
    radius: Theme.rMd
    color: Theme.alpha(Theme.text, Theme.dark ? 0.12 : 0.07)
    border.width: input.activeFocus ? 2 : 0
    border.color: Theme.alpha(Theme.accent, 0.55)

    Timer {
        id: debounce
        interval: 450
        onTriggered: if (input.text.trim().length > 0) f.submitted(input.text.trim())
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 8
        anchors.rightMargin: 4
        spacing: 6
        Glyph { Layout.preferredWidth: 14; Layout.preferredHeight: 14; name: "search"; size: 14; color: Theme.textSecondary }
        TextField {
            id: input
            Layout.fillWidth: true
            Layout.fillHeight: true
            background: null
            padding: 0
            placeholderText: "Search"
            placeholderTextColor: Theme.textSecondary
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
            verticalAlignment: TextInput.AlignVCenter
            selectByMouse: true
            onTextEdited: debounce.restart()
            onAccepted: { debounce.stop(); if (text.trim().length > 0) f.submitted(text.trim()) }
            Keys.onEscapePressed: { text = ""; focus = false }
        }
        IconButton {
            visible: input.text.length > 0
            implicitWidth: 20; implicitHeight: 20
            glyph: "close"; size: 10; color: Theme.textSecondary; tip: "Clear search"
            onClicked: { input.text = ""; input.forceActiveFocus() }
        }
    }
}
