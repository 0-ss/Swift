import QtQuick
import QtQuick.Controls
import Swift

StyledMenu {
    id: m
    property bool liked: false
    property bool inPlaylist: false     // shown from a playlist page
    property bool canReorder: false     // ...and that playlist is in its own order
    signal playNow()
    signal playNext()
    signal addToQueue()
    signal toggleLike()
    signal addToPlaylist(string id)
    signal newPlaylist()
    signal removeFromPlaylist()
    signal moveRequested(string where)  // "top" | "up" | "down" | "bottom"

    MenuRow { text: "Play Now"; onTriggered: m.playNow() }
    MenuRow { text: "Play Next"; onTriggered: m.playNext() }
    MenuRow { text: "Add to Queue"; onTriggered: m.addToQueue() }
    MenuDivider {}
    AddToPlaylistMenu {
        onPicked: (id) => m.addToPlaylist(id)
        onNewRequested: m.newPlaylist()
    }
    MenuRow { visible: m.inPlaylist; text: "Remove from Playlist"; onTriggered: m.removeFromPlaylist() }
    MenuDivider { visible: m.canReorder }
    MenuRow { visible: m.canReorder; text: "Move to Top"; onTriggered: m.moveRequested("top") }
    MenuRow { visible: m.canReorder; text: "Move Up"; onTriggered: m.moveRequested("up") }
    MenuRow { visible: m.canReorder; text: "Move Down"; onTriggered: m.moveRequested("down") }
    MenuRow { visible: m.canReorder; text: "Move to Bottom"; onTriggered: m.moveRequested("bottom") }
    MenuDivider {}
    MenuRow { text: m.liked ? "Remove from Liked Songs" : "Add to Liked Songs"; onTriggered: m.toggleLike() }
}
