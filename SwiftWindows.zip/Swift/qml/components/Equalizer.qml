import QtQuick
import Swift

// The animated "now playing" bars shown in place of a track number.
Item {
    id: eq
    property bool running: true
    property color color: Theme.accent
    implicitWidth: 14
    implicitHeight: 12
    width: implicitWidth
    height: implicitHeight

    Repeater {
        model: [ 520, 380, 460, 600 ]
        delegate: Rectangle {
            required property int index
            required property int modelData
            x: index * 3.6
            width: 2.4
            radius: 1.2
            color: eq.color
            anchors.bottom: parent.bottom
            height: 4
            SequentialAnimation on height {
                loops: Animation.Infinite
                running: eq.running && eq.visible && !Theme.reduceMotion
                NumberAnimation { to: 12; duration: modelData; easing.type: Easing.InOutSine }
                NumberAnimation { to: 3; duration: modelData * 0.9; easing.type: Easing.InOutSine }
            }
        }
    }
}
