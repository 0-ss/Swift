import QtQuick
import QtQuick.Controls
import Swift

// Context-menu item: accent plate and white text when highlighted, like macOS menus.
// `gutter` reserves room on the left for a check mark (`marked`); a row that opens a
// submenu gets a chevron. Setting `visible: false` also collapses the row.
MenuItem {
    id: mi
    property bool gutter: false
    property bool marked: false
    implicitWidth: 200
    implicitHeight: 24
    height: visible ? implicitHeight : 0
    clip: true
    opacity: enabled ? 1 : 0.4
    leftPadding: gutter ? 24 : 10
    rightPadding: 10

    contentItem: Text {
        text: mi.text
        color: mi.highlighted ? Theme.accentForeground : Theme.text
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }
    indicator: Glyph {
        visible: mi.marked
        x: 6
        y: Math.round((mi.height - height) / 2)
        name: "check"; size: 12
        color: mi.highlighted ? Theme.accentForeground : Theme.text
    }
    arrow: Glyph {
        visible: mi.subMenu !== null
        x: mi.width - width - 6
        y: Math.round((mi.height - height) / 2)
        name: "chevronRight"; size: 11
        color: mi.highlighted ? Theme.accentForeground : Theme.textSecondary
    }
    background: Rectangle {
        radius: Theme.rSm
        color: mi.highlighted ? Theme.accent : "transparent"
    }
}
