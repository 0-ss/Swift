import QtQuick
import QtQuick.Layouts
import Swift

Rectangle {
    id: t
    property string message
    property real bottomInset: 0     // keeps the toast clear of the floating player bar
    signal dismissed()
    function show(msg) { message = msg; hide.restart() }

    width: Math.min(parent.width - 32, 460)
    height: row.implicitHeight + 20
    radius: Theme.rLg
    color: Theme.cardRaised
    border.width: 1
    border.color: Theme.dark ? "#4A4A4C" : "#D8D8DB"
    anchors.horizontalCenter: parent.horizontalCenter
    y: message.length > 0 ? parent.height - height - 24 - bottomInset : parent.height + 20
    opacity: message.length > 0 ? 1 : 0
    visible: opacity > 0
    z: 100
    Behavior on y { NumberAnimation { duration: Theme.base; easing.type: Easing.OutCubic } }
    Behavior on opacity { NumberAnimation { duration: Theme.base } }
    Timer { id: hide; interval: 6000; running: t.message.length > 0; onTriggered: t.dismissed() }
    Accessible.role: Accessible.AlertMessage
    Accessible.name: message

    RowLayout {
        id: row
        anchors.fill: parent
        anchors.margins: 10
        anchors.leftMargin: 14
        Text {
            Layout.fillWidth: true
            text: t.message
            wrapMode: Text.WordWrap
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }
        IconButton { glyph: "close"; size: 11; implicitWidth: 24; implicitHeight: 24; tip: "Dismiss"; onClicked: t.dismissed() }
    }
}
