import QtQuick
import QtQuick.Layouts
import Swift

Rectangle {
    id: c
    property string label
    property bool selected: false
    signal clicked()
    implicitHeight: 26
    implicitWidth: t.implicitWidth + 26
    radius: height / 2
    color: selected ? Theme.accent : ma.containsMouse ? Theme.fillHover : Theme.fill
    Behavior on color { ColorAnimation { duration: Theme.fast } }
    activeFocusOnTab: true
    border.width: activeFocus ? 2 : 0
    border.color: Theme.accent
    Keys.onReturnPressed: clicked()
    Text {
        id: t
        anchors.centerIn: parent
        text: c.label
        color: c.selected ? Theme.accentForeground : Theme.text
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody - 1
        font.weight: Font.Medium
    }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; onClicked: c.clicked() }
}
