import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

// Small confirmation sheet for destructive actions.
Popup {
    id: p
    property string heading
    property string body
    property string confirmText: "Delete"
    property var action: null

    function ask(title, message, confirmLabel, callback) {
        heading = title
        body = message
        confirmText = confirmLabel
        action = callback
        open()
    }

    parent: Overlay.overlay
    anchors.centerIn: Overlay.overlay
    modal: true
    focus: true
    padding: 22
    width: Math.min(340, (parent ? parent.width : 340) - 48)

    enter: Transition {
        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.base }
        NumberAnimation { property: "scale"; from: 0.96; to: 1; duration: Theme.base; easing.type: Easing.OutCubic }
    }
    exit: Transition { NumberAnimation { property: "opacity"; from: 1; to: 0; duration: Theme.fast } }
    Overlay.modal: Rectangle { color: Theme.alpha("#000000", Theme.dark ? 0.5 : 0.28) }
    background: Rectangle {
        radius: Theme.rXl + 2
        color: Theme.menu
        border.width: 1
        border.color: Theme.dark ? "#4A4A4C" : "#D4D4D7"
    }

    contentItem: ColumnLayout {
        spacing: 8
        Text {
            Layout.fillWidth: true
            text: p.heading
            wrapMode: Text.WordWrap
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody + 3
            font.weight: Font.Bold
        }
        Text {
            Layout.fillWidth: true
            text: p.body
            wrapMode: Text.WordWrap
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }
        RowLayout {
            Layout.fillWidth: true
            Layout.topMargin: 12
            spacing: 10
            Item { Layout.fillWidth: true }
            PillButton { text: "Cancel"; onClicked: p.close() }
            PillButton {
                text: p.confirmText
                prominent: true
                destructive: true
                onClicked: { const a = p.action; p.close(); if (a) a() }
            }
        }
    }
}
