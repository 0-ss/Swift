import QtQuick
import Swift

Text {
    color: Theme.text
    font.family: Theme.fontFamily
    font.pixelSize: Theme.sizeHeading
    font.weight: Font.Bold
    topPadding: 6
}
