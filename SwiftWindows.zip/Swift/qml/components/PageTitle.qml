import QtQuick
import Swift

// Large bold page title, as at the top of Home / Songs / Albums in Music.
Text {
    color: Theme.text
    font.family: Theme.fontFamily
    font.pixelSize: Theme.sizeTitle
    font.weight: Font.Bold
    elide: Text.ElideRight
}
