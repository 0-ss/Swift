import QtQuick
import Swift

// macOS switch (38 x 22).
Rectangle {
    id: t
    property bool checked: false
    signal toggled(bool checked)
    implicitWidth: 38
    implicitHeight: 22
    radius: height / 2
    color: checked ? Theme.accent : Theme.dark ? "#555558" : "#D9D9DC"
    Behavior on color { ColorAnimation { duration: Theme.base } }
    activeFocusOnTab: true
    border.width: activeFocus ? 2 : 0
    border.color: Theme.text
    Accessible.role: Accessible.CheckBox
    Accessible.checked: checked
    Keys.onSpacePressed: t.toggled(!checked)
    Rectangle {
        width: 18; height: 18; radius: 9
        y: 2
        x: t.checked ? t.width - width - 2 : 2
        color: "white"
        border.width: 1
        border.color: "#1A000000"
        Behavior on x { NumberAnimation { duration: Theme.base; easing.type: Easing.OutCubic } }
    }
    MouseArea { anchors.fill: parent; onClicked: t.toggled(!t.checked) }
}
