import QtQuick
import QtQuick.Layouts
import Swift

// Column titles for a TrackRow table. Geometry mirrors TrackRow exactly.
// With `sortable`, the titles become buttons (Title 1, Artist 2, Album 3, Time 4) and the
// leading cell resets to playlist order (key 0), with an arrow on the active column.
Item {
    id: h
    property bool numbered: false
    property bool sortable: false
    property int sortKey: 0
    property bool ascending: true
    signal sortClicked(int key)
    readonly property bool showArtist: width >= 560
    readonly property bool showAlbum: width >= 760 && !numbered
    implicitHeight: 26

    component HeaderLabel: Item {
        id: hl
        property string text
        property int key: -1
        readonly property bool active: h.sortable && h.sortKey === key
        implicitHeight: lbl.implicitHeight
        Layout.alignment: Qt.AlignVCenter
        Text {
            id: lbl
            width: Math.min(implicitWidth, hl.width - (hl.active ? 14 : 0))
            text: hl.text
            elide: Text.ElideRight
            color: hl.active ? Theme.text : Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeSmall + 1
            font.weight: Font.DemiBold
        }
        Glyph {
            visible: hl.active
            x: lbl.width + 3
            anchors.verticalCenter: lbl.verticalCenter
            name: h.ascending ? "chevronUp" : "chevronDown"
            size: 10
            color: Theme.textSecondary
        }
        MouseArea {
            anchors.fill: parent
            enabled: h.sortable && hl.key >= 0
            cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
            onClicked: h.sortClicked(hl.key)
        }
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 8
        spacing: 12
        Item {
            Layout.preferredWidth: h.numbered ? 26 : 40
            Layout.fillHeight: true
            Glyph {
                visible: h.sortable
                anchors.centerIn: parent
                name: "list"; size: 14
                color: h.sortKey === 0 ? Theme.accent : Theme.textSecondary
            }
            MouseArea {
                anchors.fill: parent
                enabled: h.sortable
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                onClicked: h.sortClicked(0)
            }
        }
        HeaderLabel { Layout.fillWidth: true; text: "Title"; key: 1 }
        HeaderLabel { Layout.preferredWidth: 46; text: "Time"; key: 4 }
        HeaderLabel { visible: h.showArtist; Layout.preferredWidth: Math.round(h.width * 0.22); text: "Artist"; key: 2 }
        HeaderLabel { visible: h.showAlbum; Layout.preferredWidth: Math.round(h.width * 0.22); text: "Album"; key: 3 }
        Item { Layout.preferredWidth: 64 }
    }
    Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.separator }
}
