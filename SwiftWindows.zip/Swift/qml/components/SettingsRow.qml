import QtQuick
import QtQuick.Layouts
import Swift

Item {
    id: r
    property string title
    property string subtitle
    property bool showDivider: true
    default property alias trailing: slot.data
    signal clicked()

    Layout.fillWidth: true
    implicitHeight: Math.max(44, textCol.implicitHeight + 20)

    Rectangle { anchors.fill: parent; color: ma.pressed ? Theme.fillPressed : "transparent"; visible: r.hasClick }
    property bool hasClick: false
    MouseArea { id: ma; anchors.fill: parent; enabled: r.hasClick; onClicked: r.clicked() }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 16
        anchors.rightMargin: 14
        spacing: 12
        ColumnLayout {
            id: textCol
            Layout.fillWidth: true
            Layout.alignment: Qt.AlignVCenter
            spacing: 2
            Text {
                Layout.fillWidth: true
                text: r.title
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
                wrapMode: Text.WordWrap
            }
            Text {
                Layout.fillWidth: true
                visible: r.subtitle.length > 0
                text: r.subtitle
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeSmall
                wrapMode: Text.WordWrap
            }
        }
        Row { id: slot; spacing: 8; Layout.alignment: Qt.AlignVCenter }
    }
    Rectangle {
        visible: r.showDivider
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.leftMargin: 16
        anchors.right: parent.right
        height: 1
        color: Theme.separator
        opacity: 0.7
    }
}
