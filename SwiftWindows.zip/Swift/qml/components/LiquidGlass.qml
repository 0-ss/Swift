import QtQuick
import QtQuick.Effects
import Swift

// Liquid Glass surface for the floating player bar. Fill the bar with it (anchors.fill: parent).
//
// Pipeline: the content behind the bar is captured (ShaderEffectSource), blurred lightly
// (MultiEffect), then a fragment shader (shaders/liquidglass.frag) bends it at the edges like a
// thick lens, splits the colours slightly, adds the tint, the lit specular rim and a soft drop
// shadow, a crisp mirrored reflection of the content beyond the top and bottom edges, a gloss streak and a cursor-driven
// hotspot. If the shader is unavailable (software renderer, missing .qsb) it falls back to a flat
// tinted rounded rectangle.
Item {
    id: root

    property Item glassSource                 // item whose pixels show through the glass
    property real sourceX: 0                  // this bar's position inside glassSource
    property real sourceY: 0
    property real cornerRadius: height / 2
    property real pointerX: -1000             // cursor, in this bar's coordinates
    property real pointerY: -1000
    property bool pointerActive: false

    // Material tuning. The defaults are the floating player bar's; the floating sidebar
    // uses a frostier, gentler variant.
    property real blurMax: 24
    property real blurAmount: 0.85
    property real refraction: 24
    property real bezel: 24
    property color tint: Theme.glassTint
    property real shadowBlur: 26
    property real shadowOffsetY: 8

    // The light follows the cursor: the highlights turn to face it, and a soft hotspot rides
    // under it while it is over the bar. With no cursor the light rests at the top left.
    readonly property real idleX: -0.55
    readonly property real idleY: -0.83
    readonly property real toX: pointerX - width / 2
    readonly property real toY: pointerY - height / 2
    readonly property real toLen: Math.sqrt(toX * toX + toY * toY)
    readonly property bool tracking: pointerActive && toLen > 2
    property real lightX: tracking ? toX / toLen : idleX
    property real lightY: tracking ? toY / toLen : idleY
    Behavior on lightX { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
    Behavior on lightY { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
    // 0..1: how strongly the hotspot shows (cursor near or over the bar)
    readonly property real nearness: pointerActive ? Math.max(0, 1 - Math.max(0, Math.sqrt(
        Math.pow(Math.max(Math.abs(toX) - width / 2, 0), 2) + Math.pow(Math.max(Math.abs(toY) - height / 2, 0), 2)) - 0) / 90) : 0
    property real spot: nearness
    Behavior on spot { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }

    readonly property bool blurAvailable: GraphicsInfo.api !== GraphicsInfo.Software
    readonly property bool useShader: blurAvailable && glassSource !== null && lens.status !== ShaderEffect.Error
    readonly property real pad: 64            // room for lens sampling beyond the edge and the shadow

    // ---- fallback: flat glass --------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: !root.useShader
        radius: root.cornerRadius
        color: Theme.toolbarGlass
        border.width: 1
        border.color: Theme.dark ? "#26FFFFFF" : "#1A000000"
    }

    // ---- 1. what is behind the bar ---------------------------------------------------------
    ShaderEffectSource {
        id: backdrop
        visible: false
        live: root.useShader && root.visible
        sourceItem: root.useShader ? root.glassSource : null
        sourceRect: Qt.rect(root.sourceX - root.pad, root.sourceY - root.pad,
                            root.width + 2 * root.pad, root.height + 2 * root.pad)
        x: -root.pad; y: -root.pad
        width: root.width + 2 * root.pad
        height: root.height + 2 * root.pad
    }

    // ---- 2. lightly blurred (Liquid Glass is clearer than the old frosted look) -----------
    Item {
        id: blurred
        visible: false
        layer.enabled: root.useShader
        x: -root.pad; y: -root.pad
        width: backdrop.width
        height: backdrop.height
        MultiEffect {
            anchors.fill: parent
            source: backdrop
            autoPaddingEnabled: false
            blurEnabled: true
            blurMax: root.blurMax
            blur: root.blurAmount
            saturation: 0.15
        }
    }

    // ---- 3. lens, tint, rim and shadow ------------------------------------------------------
    ShaderEffect {
        id: lens
        visible: root.useShader
        x: -root.pad; y: -root.pad
        width: root.width + 2 * root.pad
        height: root.height + 2 * root.pad

        property variant source: blurred
        property variant sharp: backdrop
        property vector2d barSize: Qt.vector2d(root.width, root.height)
        property vector2d lightDir: Qt.vector2d(root.lightX, root.lightY)
        property vector2d spotPos: Qt.vector2d(root.toX, root.toY)  // cursor, relative to the bar centre
        property real spot: root.spot
        property real radius: root.cornerRadius
        property real pad: root.pad
        property real dark: Theme.dark ? 1.0 : 0.0
        property real refraction: root.refraction
        property real bezel: root.bezel
        property real dispersion: 0.14
        property real rimStrength: Theme.dark ? 0.62 : 0.85
        property real shadowStrength: Theme.dark ? 0.50 : 0.20
        property real shadowBlur: root.shadowBlur
        property real shadowOffsetY: root.shadowOffsetY
        property vector4d tint: Qt.vector4d(root.tint.r, root.tint.g, root.tint.b, root.tint.a)
        property vector4d base: Qt.vector4d(Theme.window.r, Theme.window.g, Theme.window.b, 1.0)

        fragmentShader: "qrc:/shaders/liquidglass.frag.qsb"
    }
}
