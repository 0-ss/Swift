import QtQuick
import QtQuick.Layouts
import Swift

// Right-hand "Up Next / History" panel (replaces the old Queue page).
Rectangle {
    id: p
    property int tab: 0
    property real bottomInset: 0
    color: Theme.window

    Rectangle { anchors.left: parent.left; width: 1; height: parent.height; color: Theme.separator }
    MouseArea { anchors.fill: parent }   // don't let clicks fall through when overlaying content

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 14
        anchors.rightMargin: 10
        anchors.topMargin: 14
        anchors.bottomMargin: p.bottomInset
        spacing: 8

        RowLayout {
            Layout.fillWidth: true
            Layout.rightMargin: 4
            Segmented {
                Layout.fillWidth: true
                options: ["Up Next", "History"]
                segmentWidth: 80
                currentIndex: p.tab
                onPicked: (i) => p.tab = i
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.rightMargin: 4
            Layout.topMargin: 4
            Text {
                Layout.fillWidth: true
                text: p.tab === 0 ? "Playing Next" : "Recently Played"
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody + 2
                font.weight: Font.Bold
            }
            Text {
                visible: p.tab === 0 && player.queue.count > 0
                Layout.rightMargin: 10
                text: "Save"
                color: Theme.accent
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
                font.weight: Font.DemiBold
                MouseArea {
                    anchors.fill: parent
                    anchors.margins: -6
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        const tracks = []
                        for (let i = 0; i < player.queue.count; ++i) tracks.push(player.queue.get(i))
                        Window.window.newPlaylist(tracks)
                    }
                }
            }
            Text {
                visible: p.tab === 0 ? player.queue.count > 0 : library.recents.count > 0
                text: "Clear"
                color: Theme.accent
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
                font.weight: Font.DemiBold
                MouseArea {
                    anchors.fill: parent
                    anchors.margins: -6
                    cursorShape: Qt.PointingHandCursor
                    onClicked: p.tab === 0 ? player.clearQueue() : library.clearRecents()
                }
            }
        }

        Item {
            Layout.fillWidth: true
            Layout.fillHeight: true

            Text {
                visible: p.tab === 0 && player.queue.count === 0
                anchors.centerIn: parent
                width: parent.width - 24
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                text: "Nothing is queued. Use “Add to Queue” from a song’s … menu."
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
            }
            Text {
                visible: p.tab === 1 && library.recents.count === 0
                anchors.centerIn: parent
                text: "Songs you play appear here."
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
            }

            ListView {
                id: queueList
                visible: p.tab === 0
                anchors.fill: parent
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: player.queue
                delegate: QueueItem {
                    width: queueList.width - 4
                    title: model.title; artist: model.artist; artworkUrl: model.artworkUrl
                    isCurrent: model.isCurrent
                    canMoveUp: index > 0
                    canMoveDown: index < player.queue.count - 1
                    onActivated: player.playQueueIndex(index)
                    onMoveUp: player.moveInQueue(index, index - 1)
                    onMoveDown: player.moveInQueue(index, index + 1)
                    onRemoved: player.removeFromQueue(index)
                }
            }
            ListView {
                id: historyList
                visible: p.tab === 1
                anchors.fill: parent
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: library.recents
                delegate: QueueItem {
                    width: historyList.width - 4
                    title: model.title; artist: model.artist; artworkUrl: model.artworkUrl
                    editable: false
                    isCurrent: player.videoId === model.videoId
                    onActivated: player.playFrom(library.recents, index)
                }
            }
        }
    }
}
