import QtQuick
import QtQuick.Layouts
import Swift

// macOS-style action button. Default look is Music's "Play / Shuffle": gray plate,
// accent-coloured icon and label. `prominent` flips to a solid accent plate.
Rectangle {
    id: b
    property string text
    property string glyph
    property bool prominent: false
    property bool destructive: false      // red plate for irreversible actions
    readonly property color plate: destructive ? "#E5372E" : Theme.accent
    signal clicked()
    implicitHeight: 30
    implicitWidth: row.implicitWidth + 28
    radius: Theme.rMd
    opacity: enabled ? 1 : 0.4
    color: prominent ? (ma.pressed ? Qt.darker(plate, 1.15) : ma.containsMouse ? Qt.lighter(plate, 1.06) : plate)
                     : (ma.pressed ? Theme.fillPressed : ma.containsMouse ? Theme.fillHover : Theme.fill)
    Behavior on color { ColorAnimation { duration: Theme.fast } }
    activeFocusOnTab: true
    border.width: activeFocus ? 2 : 0
    border.color: Theme.accent
    Keys.onReturnPressed: clicked()
    Keys.onSpacePressed: clicked()
    Accessible.role: Accessible.Button
    Accessible.name: text
    Row {
        id: row
        anchors.centerIn: parent
        spacing: 6
        Glyph { visible: b.glyph.length > 0; name: b.glyph; size: 15; color: b.prominent ? Theme.accentForeground : Theme.accent; anchors.verticalCenter: parent.verticalCenter }
        Text {
            text: b.text
            color: b.prominent ? Theme.accentForeground : (b.glyph.length > 0 ? Theme.accent : Theme.text)
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
            font.weight: Font.DemiBold
            anchors.verticalCenter: parent.verticalCenter
        }
    }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; enabled: b.enabled; onClicked: b.clicked() }
}
