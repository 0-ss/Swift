import QtQuick
import QtQuick.Layouts
import Swift

ColumnLayout {
    id: g
    property string title
    property string footer
    default property alias rows: rowsCol.data
    spacing: 8
    Layout.fillWidth: true

    Text {
        visible: g.title.length > 0
        text: g.title
        Layout.leftMargin: 14
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeSmall + 1
        font.weight: Font.DemiBold
    }
    Rectangle {
        Layout.fillWidth: true
        implicitHeight: rowsCol.implicitHeight
        radius: Theme.rLg
        color: Theme.card
        border.width: 1
        border.color: Theme.dark ? Theme.separator : "transparent"
        clip: true
        ColumnLayout { id: rowsCol; width: parent.width; spacing: 0 }
    }
    Text {
        visible: g.footer.length > 0
        text: g.footer
        Layout.leftMargin: 14
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeSmall
    }
    // Hide the divider under the last row.
    Component.onCompleted: {
        const kids = rowsCol.children
        for (let i = kids.length - 1; i >= 0; --i)
            if (kids[i].hasOwnProperty("showDivider")) { kids[i].showDivider = false; break }
    }
}
