import QtQuick
import QtQuick.Layouts
import Swift

// macOS segmented control: gray track, raised selected segment.
Rectangle {
    id: s
    property var options: []
    property int currentIndex: 0
    property real segmentWidth: 72
    signal picked(int index)
    implicitHeight: 24
    implicitWidth: options.length * segmentWidth + 4
    radius: Theme.rMd - 1
    color: Theme.fill

    Rectangle {
        y: 2; height: parent.height - 4
        width: (s.width - 4) / Math.max(1, s.options.length)
        x: 2 + s.currentIndex * width
        radius: Theme.rSm
        color: Theme.dark ? "#636366" : "#FFFFFF"
        border.width: Theme.dark ? 0 : 1
        border.color: "#14000000"
        Behavior on x { NumberAnimation { duration: Theme.base; easing.type: Easing.OutCubic } }
    }
    Row {
        x: 2; y: 2
        width: s.width - 4; height: s.height - 4
        Repeater {
            model: s.options
            delegate: Item {
                required property int index
                required property string modelData
                width: parent.width / s.options.length
                height: parent.height
                Text {
                    anchors.centerIn: parent
                    text: modelData
                    color: Theme.text
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.sizeBody - 1
                    font.weight: index === s.currentIndex ? Font.DemiBold : Font.Normal
                }
                MouseArea { anchors.fill: parent; onClicked: s.picked(index) }
            }
        }
    }
}
