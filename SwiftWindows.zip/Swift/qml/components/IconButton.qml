import QtQuick
import Swift

// Flat glyph button with a rounded-square hover plate, like macOS toolbar buttons.
Item {
    id: b
    property string glyph
    property real size: 18
    property color color: Theme.text
    property bool active: false
    property color activeColor: Theme.accent
    property color hoverColor: Theme.hover
    property color pressedColor: Theme.pressed
    property string tip
    readonly property bool hovered: ma.containsMouse
    signal clicked()

    implicitWidth: 30
    implicitHeight: 30
    activeFocusOnTab: true
    Accessible.role: Accessible.Button
    Accessible.name: tip || glyph
    Keys.onSpacePressed: clicked()
    Keys.onReturnPressed: clicked()

    Rectangle {
        anchors.fill: parent
        radius: Theme.rMd
        color: !b.enabled ? "transparent"
             : ma.pressed ? b.pressedColor
             : b.active ? Theme.alpha(b.activeColor, 0.14)
             : ma.containsMouse ? b.hoverColor : "transparent"
        border.width: b.activeFocus ? 2 : 0
        border.color: Theme.accent
        Behavior on color { ColorAnimation { duration: Theme.fast } }
    }
    Glyph {
        // snapped to whole pixels: a 19px glyph in a 30px button would otherwise sit on a half pixel
        x: Math.round((b.width - width) / 2)
        y: Math.round((b.height - height) / 2)
        name: b.glyph
        size: b.size
        color: b.active ? b.activeColor : b.color
        opacity: b.enabled ? 1 : 0.3
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        onClicked: b.clicked()
    }
}
