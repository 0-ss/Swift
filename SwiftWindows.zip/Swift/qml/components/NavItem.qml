import QtQuick
import QtQuick.Layouts
import Swift

// Sidebar row: accent-coloured icon, primary label, gray rounded selection plate.
Rectangle {
    id: n
    property string glyph
    property string label
    property url logo           // optional image shown at the far right, opposite the label
    property bool selected: false
    signal clicked()
    signal rightClicked()

    implicitHeight: 28
    radius: Theme.rMd - 1
    color: selected ? Theme.alpha(Theme.text, Theme.dark ? 0.14 : 0.09)
         : ma.pressed ? Theme.pressed : ma.containsMouse ? Theme.hover : "transparent"
    Behavior on color { ColorAnimation { duration: Theme.fast } }
    activeFocusOnTab: true
    border.width: activeFocus ? 2 : 0
    border.color: Theme.accent
    Keys.onReturnPressed: clicked()
    Keys.onSpacePressed: clicked()
    Accessible.role: Accessible.Button
    Accessible.name: label

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 9
        anchors.rightMargin: 8
        spacing: 9
        Glyph { Layout.preferredWidth: 17; Layout.preferredHeight: 17; name: n.glyph; size: 17; color: Theme.accent }
        Text {
            Layout.fillWidth: true
            text: n.label
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
            elide: Text.ElideRight
        }
        Image {
            visible: n.logo.toString().length > 0
            Layout.preferredWidth: 18
            Layout.preferredHeight: 18
            source: n.logo
            sourceSize: Qt.size(36, 36)
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
        }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onClicked: (m) => m.button === Qt.RightButton ? n.rightClicked() : n.clicked()
    }
}
