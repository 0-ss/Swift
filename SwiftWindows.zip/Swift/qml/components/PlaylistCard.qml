import QtQuick
import QtQuick.Layouts
import Swift

// Playlists-page card. Like ArtCard: cover, title, "N songs". Hover dims the cover and shows
// play (bottom-left) and "…" (bottom-right); right-click opens the same menu.
Item {
    id: c
    property string title
    property string subtitle
    property var covers: []
    property bool empty: false
    property real cardWidth: 176
    signal clicked()
    signal playRequested()
    signal shuffleRequested()
    signal editRequested()
    signal removeRequested()

    implicitWidth: cardWidth
    implicitHeight: art.height + col.implicitHeight + 8
    activeFocusOnTab: true
    Keys.onReturnPressed: clicked()
    Keys.onSpacePressed: clicked()
    Accessible.role: Accessible.Button
    Accessible.name: title

    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onClicked: (m) => { if (m.button === Qt.RightButton) menu.popup(); else c.clicked() }
    }

    PlaylistCover {
        id: art
        width: c.cardWidth
        height: c.cardWidth
        covers: c.covers
        corner: Theme.rMd

        readonly property bool lit: ma.containsMouse || playMa.containsMouse || moreMa.containsMouse
                                    || c.activeFocus || menu.visible
        Rectangle {
            anchors.fill: parent
            radius: art.corner
            border.width: c.activeFocus ? 2 : 0
            border.color: Theme.accent
            gradient: Gradient {
                GradientStop { position: 0.0; color: "transparent" }
                GradientStop { position: 1.0; color: Theme.alpha("#000000", 0.38) }
            }
            opacity: art.lit ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Theme.fast } }
        }
        Rectangle {
            visible: !c.empty
            x: 10; y: parent.height - height - 10
            width: 32; height: 32; radius: 16
            color: playMa.pressed ? Theme.alpha("#000000", 0.75) : Theme.alpha("#000000", 0.55)
            opacity: art.lit ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Theme.fast } }
            Glyph { anchors.centerIn: parent; anchors.horizontalCenterOffset: 1; name: "play"; size: 15; color: "white" }
            MouseArea { id: playMa; anchors.fill: parent; hoverEnabled: true; onClicked: c.playRequested() }
            Accessible.role: Accessible.Button
            Accessible.name: "Play " + c.title
        }
        Rectangle {
            x: parent.width - width - 10; y: parent.height - height - 10
            width: 32; height: 32; radius: 16
            color: moreMa.pressed ? Theme.alpha("#000000", 0.75) : Theme.alpha("#000000", 0.55)
            opacity: art.lit ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Theme.fast } }
            Glyph { anchors.centerIn: parent; name: "ellipsis"; size: 16; color: "white" }
            MouseArea { id: moreMa; anchors.fill: parent; hoverEnabled: true; onClicked: menu.popup() }
            Accessible.role: Accessible.Button
            Accessible.name: "More options for " + c.title
        }
    }

    ColumnLayout {
        id: col
        anchors.top: art.bottom
        anchors.topMargin: 8
        width: c.cardWidth
        spacing: 1
        Text {
            Layout.fillWidth: true
            text: c.title
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
            font.weight: Font.Medium
        }
        Text {
            Layout.fillWidth: true
            text: c.subtitle
            elide: Text.ElideRight
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody - 1
            visible: text.length > 0
        }
    }

    PlaylistMenu {
        id: menu
        empty: c.empty
        onPlay: c.playRequested()
        onShuffle: c.shuffleRequested()
        onEdit: c.editRequested()
        onRemove: c.removeRequested()
    }
}
