import QtQuick
import QtQuick.Controls
import Swift

// Base for every Swift menu: rounded plate, hairline border, accent-highlight rows.
// Submenus declared inside get the same row style through `delegate`.
Menu {
    padding: 5
    delegate: MenuRow {}
    background: Rectangle {
        implicitWidth: 210
        radius: Theme.rLg - 1
        color: Theme.menu
        border.width: 1
        border.color: Theme.dark ? "#4A4A4C" : "#D4D4D7"
    }
}
