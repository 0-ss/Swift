import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

PageScaffold {
    id: page
    property real cacheBytes: 0
    function refreshCache() { cacheBytes = cache.sizeBytes() }
    Component.onCompleted: refreshCache()

    readonly property var accents: ["#FA233B", "#FF9500", "#FFCC00", "#30D158", "#0A84FF", "#BF5AF2"]

    component FieldBox: TextField {
        implicitWidth: 220
        implicitHeight: 26
        color: Theme.text
        placeholderTextColor: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
        selectByMouse: true
        leftPadding: 10
        rightPadding: 10
        background: Rectangle {
            radius: Theme.rSm
            color: Theme.fill
            border.width: parent.activeFocus ? 2 : 0
            border.color: Theme.accent
        }
    }

    PageTitle { Layout.fillWidth: true; text: "Settings" }

    SettingsGroup {
        title: "Appearance"
        footer: "Top keeps the player controls in the toolbar. Floating moves them into a blurred glass bar that hovers at the bottom of the window. The glass style applies to every floating panel."
        SettingsRow {
            title: "Theme"
            Segmented { options: ["System", "Light", "Dark"]; currentIndex: settings.values.themeMode; onPicked: (i) => settings.values.themeMode = i }
        }
        SettingsRow {
            title: "Accent color"
            Row {
                spacing: 8
                Repeater {
                    model: page.accents
                    delegate: Rectangle {
                        required property string modelData
                        width: 26; height: 26; radius: 13; color: modelData
                        border.width: settings.values.accentColor === modelData ? 3 : 0
                        border.color: Theme.window
                        Rectangle { anchors.centerIn: parent; width: 32; height: 32; radius: 16; color: "transparent"; border.width: settings.values.accentColor === modelData ? 2 : 0; border.color: modelData }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: settings.values.accentColor = modelData }
                    }
                }
            }
        }
        SettingsRow {
            title: "Player bar"
            subtitle: "Where the playback controls live."
            Segmented { options: ["Top", "Floating"]; currentIndex: settings.values.floatingPlayerBar ? 1 : 0; onPicked: (i) => settings.values.floatingPlayerBar = (i === 1) }
        }
        SettingsRow {
            title: "Sidebar"
            subtitle: "Floating hovers over the content as a rounded glass panel, and cards slide behind it. Normal is the full-height column."
            Segmented { options: ["Floating", "Normal"]; currentIndex: settings.values.floatingSidebar ? 0 : 1; onPicked: (i) => settings.values.floatingSidebar = (i === 0) }
        }
        SettingsRow {
            title: "Glass style"
            subtitle: "Liquid Glass refracts and reflects what is behind it. Classic blur is the original frosted look."
            Segmented { options: ["Liquid Glass", "Classic blur"]; currentIndex: settings.values.liquidGlass ? 0 : 1; onPicked: (i) => settings.values.liquidGlass = (i === 0) }
        }
        SettingsRow { title: "Reduce motion"; subtitle: "Turns off most animations."; Toggle { checked: settings.values.reduceMotion; onToggled: (c) => settings.values.reduceMotion = c } }
    }

    SettingsGroup {
        title: "Window Controls"
        footer: "Replaces the system title bar with red, yellow and green buttons in the top-left corner. Turn it off to use the system title bar."
        SettingsRow { title: "Show macOS window buttons"; Toggle { checked: settings.values.showWindowButtons; onToggled: (c) => settings.values.showWindowButtons = c } }
        SettingsRow {
            title: "Keep running in system tray"
            subtitle: systemTray.available ? "Closing the window keeps Swift available from the tray." : "No system tray is available on this desktop."
            Toggle { checked: settings.values.systemTray; enabled: systemTray.available; onToggled: (c) => settings.values.systemTray = c }
        }
    }

    SettingsGroup {
        title: "Playback"
        SettingsRow { title: "Resume where you left off"; subtitle: "Restores your queue and position when Swift opens."; Toggle { checked: settings.values.restoreSession; onToggled: (c) => settings.values.restoreSession = c } }
        SettingsRow { title: "Shuffle"; Toggle { checked: player.shuffle; onToggled: (c) => player.shuffle = c } }
        SettingsRow { title: "Repeat"; Segmented { options: ["Off", "All", "One"]; currentIndex: player.repeatMode; onPicked: (i) => player.repeatMode = i } }
        SettingsRow { title: "Show lyrics"; subtitle: "Looks up lyrics for the playing song on lrclib.net (sends title, artist and album). NOT WORKING RIGHT NOW, WORKING ON IT!"; Toggle { checked: settings.values.lyricsEnabled; onToggled: (c) => settings.values.lyricsEnabled = c } }
    }

    SettingsGroup {
        title: "Audio"
        SettingsRow { title: "Volume"; ProgressSlider { width: 200; value: player.volume; onMoved: (v) => player.volume = v; onCommitted: (v) => player.volume = v } }
    }

    SettingsGroup {
        title: "Network"
        footer: "Many tracks need a helper to turn a YouTube page into an audio stream. Swift runs this command and reads the URL it prints. yt-dlp must be installed separately."
        SettingsRow { title: "Stream resolver command"; FieldBox { text: settings.values.resolverCommand; onEditingFinished: settings.values.resolverCommand = text } }
        SettingsRow { title: "Content language"; subtitle: "Two-letter code, like en or de."; FieldBox { implicitWidth: 80; text: settings.values.language; onEditingFinished: settings.values.language = text.trim() || "en" } }
    }

    SettingsGroup {
        title: "Downloads and cache"
        footer: "Artwork is cached on disk so covers load instantly. A new size limit applies the next time Swift starts."
        SettingsRow { title: "Artwork cache"; subtitle: (page.cacheBytes / 1048576).toFixed(1) + " MB used"; PillButton { text: "Clear cache"; prominent: false; onClicked: { cache.clear(); page.refreshCache() } } }
        SettingsRow {
            title: "Cache size limit"
            Segmented { options: ["128 MB", "256 MB", "512 MB"]; currentIndex: settings.values.cacheLimitMb === 128 ? 0 : settings.values.cacheLimitMb === 512 ? 2 : 1; onPicked: (i) => settings.values.cacheLimitMb = [128, 256, 512][i] }
        }
    }

    SettingsGroup {
        title: "YouTube Music Account"
        footer: account.persistentStorageAvailable
              ? "Your session is stored only in your operating system’s credential vault, never in Swift settings. Playlist changes are sent to and confirmed by YouTube Music."
              : "This development build has no QtKeychain and will forget the session when closed. Install QtKeychain and rebuild for persistent secure storage."
        SettingsRow {
            title: account.connected ? "Connected account" : "Account status"
            subtitle: account.statusMessage
            Row {
                PillButton { text: "Refresh"; prominent: false; enabled: !account.busy && account.state !== "disconnected"; onClicked: account.refresh() }
                PillButton { text: account.connected ? "Reconnect" : "Connect"; prominent: true; enabled: !account.busy; onClicked: account.reconnect() }
            }
        }
        SettingsRow {
            visible: !account.embeddedLoginAvailable
            title: "Embedded sign-in unavailable"
            subtitle: "Use Import Session below in this build. Adding Qt WebEngine enables a private in-app Google sign-in window."
        }
        SettingsRow {
            title: "Import session"
            subtitle: "Fallback only: import a complete Cookie header or copied authenticated request headers. The value is never shown again."
            PillButton { text: "Import Session…"; prominent: false; enabled: !account.busy; onClicked: importer.open() }
        }
        SettingsRow {
            title: "Sign out"
            subtitle: "Removes the connected session from Swift and the system keychain."
            PillButton { text: "Sign out"; prominent: false; enabled: account.state !== "disconnected" && !account.busy; onClicked: account.signOut() }
        }
    }

    SettingsGroup {
        title: "Notifications"
        footer: "The preference is saved. System notifications aren't delivered yet."
        SettingsRow { title: "Show track changes"; subtitle: "Notify when a new song starts while Swift is in the background."; Toggle { checked: settings.values.notifyOnTrackChange; onToggled: (c) => settings.values.notifyOnTrackChange = c } }
    }

    SettingsGroup {
        title: "Keyboard shortcuts"
        SettingsRow { title: "Play or pause"; Text { text: "Space, Media Play/Pause"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody } }
        SettingsRow { title: "Next track"; Text { text: Theme.mod + "→, Media Next"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody } }
        SettingsRow { title: "Previous track"; Text { text: Theme.mod + "←, Media Previous"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody } }
        SettingsRow { title: "Volume up or down"; Text { text: Theme.mod + "↑ / ↓"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody } }
        SettingsRow { title: "Search"; Text { text: Theme.mod + "F"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody } }
        SettingsRow { title: "Open settings"; Text { text: Theme.mod + ","; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody } }
    }

    SettingsGroup {
        title: "About"
        SettingsRow { title: "Swift"; Text { text: "Version " + Qt.application.version; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody } }
        SettingsRow { title: "Reset settings"; subtitle: "Restores app preferences. Your YouTube Music account is kept separately."; PillButton { text: "Reset"; prominent: false; onClicked: settings.resetToDefaults() } }
    }

    Popup {
        id: importer
        parent: Overlay.overlay
        anchors.centerIn: Overlay.overlay
        width: Math.min(560, (parent ? parent.width : 560) - 40)
        modal: true
        focus: true
        padding: 22
        background: Rectangle { radius: Theme.rXl + 2; color: Theme.menu; border.width: 1; border.color: Theme.separator }
        onOpened: sessionText.forceActiveFocus()
        onClosed: sessionText.text = ""
        contentItem: ColumnLayout {
            spacing: 14
            Text { Layout.fillWidth: true; text: "Import YouTube Music Session"; color: Theme.text; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody + 4; font.weight: Font.Bold }
            Text {
                Layout.fillWidth: true
                text: "Paste a complete Cookie header or copied authenticated request headers from music.youtube.com. Swift extracts only the Cookie and account selector, then stores the session in the system credential vault when available."
                color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody; wrapMode: Text.WordWrap
            }
            TextArea {
                id: sessionText
                Layout.fillWidth: true
                Layout.preferredHeight: 150
                placeholderText: "Cookie: SID=…; SAPISID=…; __Secure-3PAPISID=…"
                placeholderTextColor: Theme.textTertiary
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeSmall
                selectByMouse: true
                wrapMode: TextEdit.WrapAnywhere
                background: Rectangle { radius: Theme.rSm; color: Theme.fill; border.width: sessionText.activeFocus ? 2 : 1; border.color: sessionText.activeFocus ? Theme.accent : Theme.separator }
            }
            RowLayout {
                Layout.fillWidth: true
                Item { Layout.fillWidth: true }
                PillButton { text: "Cancel"; onClicked: importer.close() }
                PillButton { text: "Import & Connect"; prominent: true; enabled: sessionText.text.trim().length > 0; onClicked: { account.importSession(sessionText.text); importer.close() } }
            }
        }
    }
}
