import QtQuick
import QtQuick.Layouts
import Swift

PageScaffold {
    id: page
    // -1 shows filter chips; 2..4 pins the page to albums, artists or playlists.
    property int fixedFilter: -1
    property string heading: "Search"
    readonly property int activeFilter: fixedFilter >= 0 ? fixedFilter : app.filter
    readonly property bool hasResults: app.searchTracks.count > 0 || app.searchCollections.count > 0

    Component {
        id: cardDelegate
        ArtCard {
            title: model.title; subtitle: model.subtitle; artworkUrl: model.artworkUrl
            round: model.kind === "artist"
            onClicked: { app.openCollection(app.searchCollections.get(index)); Window.window.openDetail() }
        }
    }

    PageTitle { Layout.fillWidth: true; text: page.heading }

    Flow {
        visible: page.fixedFilter < 0
        Layout.fillWidth: true
        spacing: 8
        Repeater {
            model: ["All", "Songs", "Albums", "Artists", "Playlists"]
            delegate: Chip {
                required property string modelData
                label: modelData
                selected: page.activeFilter === index
                onClicked: if (app.lastQuery.length) app.search(app.lastQuery, index)
            }
        }
    }

    Text {
        visible: !page.hasResults && !app.searchLoading
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
        text: app.lastQuery.length
              ? "No results for “" + app.lastQuery + "”. Try different words or another filter."
              : "Use the search field in the sidebar to find songs, albums and artists."
    }
    Text {
        visible: app.searchLoading
        text: "Searching…"
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
    }

    // pinned pages (Albums / Artists / Playlists) show a grid; mixed results show a shelf
    Flow {
        Layout.fillWidth: true
        spacing: 22
        visible: page.fixedFilter >= 0 && app.searchCollections.count > 0
        Repeater { model: page.fixedFilter >= 0 ? app.searchCollections : null; delegate: cardDelegate }
    }
    Shelf {
        visible: page.fixedFilter < 0 && app.searchCollections.count > 0
        title: "Albums, Artists & Playlists"
        model: page.fixedFilter < 0 ? app.searchCollections : null
        delegate: cardDelegate
    }

    ColumnLayout {
        Layout.fillWidth: true
        spacing: 0
        visible: app.searchTracks.count > 0
        SectionHeader { text: "Songs"; Layout.bottomMargin: 8 }
        TrackHeader { Layout.fillWidth: true }
        Repeater {
            model: app.searchTracks
            delegate: TrackRow {
                Layout.fillWidth: true
                striped: index % 2 === 0
                videoId: model.videoId; title: model.title; artist: model.artist; album: model.album
                artworkUrl: model.artworkUrl; durationMs: model.durationMs
                isCurrent: player.videoId === model.videoId
                onActivated: player.playFrom(app.searchTracks, index)
                onPlayNowRequested: player.playFrom(app.searchTracks, index)
                onFavoriteToggled: library.toggleFavorite(app.searchTracks.get(index))
                onEnqueueRequested: player.enqueue(app.searchTracks.get(index))
                onPlayNextRequested: player.playNext(app.searchTracks.get(index))
            }
        }
    }
}
