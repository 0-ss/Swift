import QtQuick
import QtQuick.Layouts
import Swift

PageScaffold {
    id: page
    Component.onCompleted: if (app.homeTracks.count === 0 && app.homeCollections.count === 0) app.loadHome()

    PageTitle { Layout.fillWidth: true; text: "Home" }

    Shelf {
        visible: library.recents.count > 0
        title: "Recently Played"
        model: library.recents
        delegate: ArtCard {
            id: recentCard
            title: model.title; subtitle: model.artist; artworkUrl: model.artworkUrl
            videoId: model.videoId; album: model.album; durationMs: model.durationMs
            showPlay: true
            onClicked: player.playFrom(library.recents, index)
            onPlayRequested: player.playFrom(library.recents, index)

            TrackMenu {
                id: recentMenu
                liked: library.favoriteIds.indexOf(recentCard.videoId) >= 0
                onPlayNow: player.playFrom(library.recents, index)
                onPlayNext: player.playNext(recentCard.trackMap())
                onAddToQueue: player.enqueue(recentCard.trackMap())
                onToggleLike: library.toggleFavorite(recentCard.trackMap())
                onAddToPlaylist: (id) => playlists.addTrack(id, recentCard.trackMap())
                onNewPlaylist: Window.window.newPlaylist([recentCard.trackMap()])
            }
            onContextMenuRequested: (x, y) => recentMenu.popup(recentCard, x, y)
        }
    }

    Text {
        visible: app.homeLoading
        text: "Loading recommendations…"
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
    }
    ColumnLayout {
        visible: app.homeFailed && !app.homeLoading
        spacing: 10
        Text {
            text: "Recommendations didn't load. Check your connection, then try again."
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
        }
        PillButton { text: "Try Again"; onClicked: app.loadHome() }
    }

    Shelf {
        visible: app.homeCollections.count > 0
        title: "Recommended"
        model: app.homeCollections
        delegate: ArtCard {
            title: model.title; subtitle: model.subtitle; artworkUrl: model.artworkUrl
            round: model.kind === "artist"
            onClicked: { app.openCollection(app.homeCollections.get(index)); Window.window.openDetail() }
        }
    }

    ColumnLayout {
        Layout.fillWidth: true
        visible: app.homeTracks.count > 0
        spacing: 0
        SectionHeader { text: "Songs"; Layout.bottomMargin: 8 }
        TrackHeader { Layout.fillWidth: true }
        Repeater {
            model: app.homeTracks
            delegate: TrackRow {
                Layout.fillWidth: true
                striped: index % 2 === 0
                videoId: model.videoId; title: model.title; artist: model.artist; album: model.album
                artworkUrl: model.artworkUrl; durationMs: model.durationMs
                isCurrent: player.videoId === model.videoId
                onActivated: player.playFrom(app.homeTracks, index)
                onPlayNowRequested: player.playFrom(app.homeTracks, index)
                onFavoriteToggled: library.toggleFavorite(app.homeTracks.get(index))
                onEnqueueRequested: player.enqueue(app.homeTracks.get(index))
                onPlayNextRequested: player.playNext(app.homeTracks.get(index))
            }
        }
    }
}
