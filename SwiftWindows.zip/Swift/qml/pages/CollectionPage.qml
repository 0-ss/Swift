import QtQuick
import QtQuick.Layouts
import Swift

// Album / playlist / artist page: large cover on the left, title and Play / Shuffle
// buttons on the right, numbered track table underneath.
PageScaffold {
    id: page
    readonly property var info: app.detail
    readonly property bool isArtist: info.kind === "artist"
    readonly property real coverSize: page.availableWidth < 640 ? 140 : 232

    function newPlaylistFromAll() {
        const tracks = []
        for (let i = 0; i < app.detailTracks.count; ++i) tracks.push(app.detailTracks.get(i))
        Window.window.newPlaylist(tracks)
    }

    AddToPlaylistMenu {
        id: addAllMenu
        onPicked: (id) => playlists.addModel(id, app.detailTracks)
        onNewRequested: page.newPlaylistFromAll()
    }

    Component {
        id: cardDelegate
        ArtCard {
            title: model.title; subtitle: model.subtitle; artworkUrl: model.artworkUrl
            round: model.kind === "artist"
            onClicked: { app.openCollection(app.detailCollections.get(index)); Window.window.openDetail() }
        }
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 24
        Artwork {
            Layout.preferredWidth: page.coverSize
            Layout.preferredHeight: page.coverSize
            Layout.alignment: Qt.AlignTop
            source: info.artworkUrl || ""
            round: page.isArtist
            corner: Theme.rLg
        }
        ColumnLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: page.coverSize
            spacing: 4
            Text {
                Layout.fillWidth: true
                text: info.title || ""
                wrapMode: Text.WordWrap
                maximumLineCount: 3
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: page.availableWidth < 640 ? 22 : 26
                font.weight: Font.Bold
            }
            Text {
                Layout.fillWidth: true
                text: info.subtitle || ""
                wrapMode: Text.WordWrap
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody + 1
            }
            Item { Layout.fillHeight: true }
            RowLayout {
                spacing: 10
                PillButton {
                    text: "Play"; glyph: "play"
                    enabled: app.detailTracks.count > 0
                    onClicked: { player.shuffle = false; player.playFrom(app.detailTracks, 0) }
                }
                PillButton {
                    text: "Shuffle"; glyph: "shuffle"
                    enabled: app.detailTracks.count > 0
                    onClicked: { player.shuffle = true; player.playFrom(app.detailTracks, Math.floor(Math.random() * app.detailTracks.count)) }
                }
                PillButton {
                    id: addAllBtn
                    text: "Add to Playlist"; glyph: "plus"
                    enabled: app.detailTracks.count > 0
                    onClicked: addAllMenu.popup(addAllBtn, 0, addAllBtn.height + 4)
                }
            }
        }
    }

    Text {
        visible: app.detailLoading
        text: "Loading…"
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
    }
    Text {
        visible: !app.detailLoading && app.detailTracks.count === 0 && app.detailCollections.count === 0
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        text: "Nothing to show here. This page may need a signed-in session, or it may have moved."
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
    }

    ColumnLayout {
        Layout.fillWidth: true
        Layout.topMargin: 6
        spacing: 0
        visible: app.detailTracks.count > 0
        TrackHeader { Layout.fillWidth: true; numbered: true }
        Repeater {
            model: app.detailTracks
            delegate: TrackRow {
                Layout.fillWidth: true
                numbered: true; trackNumber: index + 1
                striped: index % 2 === 0
                videoId: model.videoId; title: model.title; artist: model.artist; album: ""
                artworkUrl: model.artworkUrl; durationMs: model.durationMs
                isCurrent: player.videoId === model.videoId
                onActivated: player.playFrom(app.detailTracks, index)
                onPlayNowRequested: player.playFrom(app.detailTracks, index)
                onFavoriteToggled: library.toggleFavorite(app.detailTracks.get(index))
                onEnqueueRequested: player.enqueue(app.detailTracks.get(index))
                onPlayNextRequested: player.playNext(app.detailTracks.get(index))
            }
        }
    }

    Shelf {
        visible: app.detailCollections.count > 0
        title: page.isArtist ? "Albums and More" : "Related"
        model: app.detailCollections
        delegate: cardDelegate
    }
}
