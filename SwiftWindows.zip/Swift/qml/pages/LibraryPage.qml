import QtQuick
import QtQuick.Layouts
import Swift

PageScaffold {
    id: page
    property string mode: "liked"   // "liked" | "recent"
    readonly property var songs: mode === "liked" ? library.favorites : library.recents

    PageTitle {
        Layout.fillWidth: true
        text: page.mode === "liked" ? "Liked Songs" : "Recently Played"
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 10
        Text {
            Layout.fillWidth: true
            visible: page.songs.count > 0
            text: page.songs.count + (page.songs.count === 1 ? " song" : " songs")
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }
        Item { Layout.fillWidth: true; visible: page.songs.count === 0 }
        PillButton {
            visible: page.songs.count > 0
            text: "Play"; glyph: "play"
            onClicked: { player.shuffle = false; player.playFrom(page.songs, 0) }
        }
        PillButton {
            visible: page.songs.count > 0
            text: "Shuffle"; glyph: "shuffle"
            onClicked: { player.shuffle = true; player.playFrom(page.songs, Math.floor(Math.random() * page.songs.count)) }
        }
        PillButton {
            visible: page.mode === "recent" && library.recents.count > 0
            text: "Clear"
            onClicked: library.clearRecents()
        }
    }

    Text {
        visible: page.songs.count === 0
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
        text: page.mode === "liked"
              ? "Songs you like appear here. Click the heart on any song to add it."
              : "Songs you play appear here."
    }

    ColumnLayout {
        Layout.fillWidth: true
        spacing: 0
        visible: page.songs.count > 0
        TrackHeader { Layout.fillWidth: true }
        Repeater {
            model: page.songs
            delegate: TrackRow {
                Layout.fillWidth: true
                striped: index % 2 === 0
                videoId: model.videoId; title: model.title; artist: model.artist; album: model.album
                artworkUrl: model.artworkUrl; durationMs: model.durationMs
                isCurrent: player.videoId === model.videoId
                onActivated: player.playFrom(page.songs, index)
                onPlayNowRequested: player.playFrom(page.songs, index)
                onFavoriteToggled: library.toggleFavorite(page.songs.get(index))
                onEnqueueRequested: player.enqueue(page.songs.get(index))
                onPlayNextRequested: player.playNext(page.songs.get(index))
            }
        }
    }
}
