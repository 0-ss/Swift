import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

// Library > Playlists: this page always renders the account-backed playlist model.
PageScaffold {
    id: page
    readonly property int count: playlists.playlists.count

    Component.onCompleted: if (account.connected) playlists.refresh()

    RowLayout {
        Layout.fillWidth: true
        spacing: 10
        PageTitle { Layout.fillWidth: true; text: "Playlists" }
        PillButton {
            text: "Refresh"; glyph: "repeat"
            enabled: account.connected && !playlists.loading && !playlists.syncing
            onClicked: playlists.refresh()
        }
        PillButton {
            text: "New Playlist"; glyph: "plus"; prominent: true
            enabled: account.connected && !playlists.syncing
            onClicked: Window.window.newPlaylist([])
        }
    }

    Text {
        visible: page.count > 0
        text: playlists.loading ? "Refreshing " + page.count + (page.count === 1 ? " playlist…" : " playlists…")
                                : page.count + (page.count === 1 ? " playlist" : " playlists")
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
    }

    Rectangle {
        visible: playlists.loading
        Layout.fillWidth: true
        implicitHeight: 38
        radius: Theme.rMd
        color: Theme.card
        RowLayout {
            anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 14; spacing: 10
            BusyIndicator { running: true; implicitWidth: 18; implicitHeight: 18 }
            Text { Layout.fillWidth: true; text: "Loading playlists from YouTube Music…"; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody }
        }
    }

    Rectangle {
        visible: playlists.syncing
        Layout.fillWidth: true
        implicitHeight: 38
        radius: Theme.rMd
        color: Theme.alpha(Theme.accent, Theme.dark ? 0.18 : 0.11)
        RowLayout {
            anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 14; spacing: 10
            BusyIndicator { running: true; implicitWidth: 18; implicitHeight: 18 }
            Text { Layout.fillWidth: true; text: "Syncing change with YouTube Music. The playlist updates after confirmation."; color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody; wrapMode: Text.WordWrap }
        }
    }

    Flow {
        Layout.fillWidth: true
        visible: page.count > 0
        spacing: 22
        Repeater {
            model: playlists.playlists
            delegate: PlaylistCard {
                title: model.name
                subtitle: model.trackCount + (model.trackCount === 1 ? " song" : " songs")
                covers: model.covers
                empty: model.trackCount === 0
                onClicked: Window.window.openPlaylist(model.playlistId)
                onPlayRequested: playlists.play(model.playlistId, false)
                onShuffleRequested: playlists.play(model.playlistId, true)
                onEditRequested: Window.window.editPlaylist(model.playlistId)
                onRemoveRequested: Window.window.deletePlaylist(model.playlistId)
            }
        }
    }

    ColumnLayout {
        visible: !playlists.loading && page.count === 0
        Layout.fillWidth: true
        Layout.topMargin: 56
        spacing: 10
        Glyph { Layout.alignment: Qt.AlignHCenter; name: "playlist"; size: 44; color: Theme.textTertiary }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: account.state === "expired" || playlists.state === "auth-error" ? "Reconnect YouTube Music"
                 : account.connected ? "No YouTube Music Playlists" : "Connect YouTube Music"
            color: Theme.text; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeHeading; font.weight: Font.Bold
        }
        Text {
            Layout.alignment: Qt.AlignHCenter; Layout.maximumWidth: 390; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
            text: account.state === "expired" || playlists.state === "auth-error" ? "Your session needs reconnecting before Swift can read your playlists."
                 : account.connected ? "This account has no playlists available in YouTube Music yet."
                 : "Connect your account to see and edit the playlists that already exist in YouTube Music."
            color: Theme.textSecondary; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody
        }
        PillButton {
            Layout.alignment: Qt.AlignHCenter; Layout.topMargin: 8
            text: account.connected ? "Refresh" : account.state === "expired" ? "Reconnect" : "Open Account Settings"
            glyph: account.connected ? "refresh" : "sliders"; prominent: true
            onClicked: account.connected ? playlists.refresh() : Window.window.go("settings")
        }
    }

    Text {
        visible: playlists.state === "error" && !playlists.loading
        Layout.fillWidth: true
        text: playlists.errorMessage
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
        wrapMode: Text.WordWrap
    }
}
