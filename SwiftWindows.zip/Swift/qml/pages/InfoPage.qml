import QtQuick
import QtQuick.Layouts
import Swift

// App info: name, version, feature overview and credits.
PageScaffold {
    id: page
    readonly property string repoUrl: "https://github.com/0-ss"

    component Body: Text {
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
        wrapMode: Text.WordWrap
    }

    PageTitle { Layout.fillWidth: true; text: "Info" }

    // ---- identity ------------------------------------------------------------------------
    ColumnLayout {
        Layout.fillWidth: true
        Layout.topMargin: 6
        Layout.bottomMargin: 6
        spacing: 6

        Image {
            Layout.alignment: Qt.AlignHCenter
            Layout.preferredWidth: 96
            Layout.preferredHeight: 96
            source: Theme.logo
            sourceSize: Qt.size(192, 192)
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
            Accessible.role: Accessible.Graphic
            Accessible.name: "Swift logo"
        }
        Text {
            Layout.fillWidth: true
            Layout.topMargin: 8
            horizontalAlignment: Text.AlignHCenter
            text: Qt.application.name.length ? Qt.application.name : "Swift"
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeTitle
            font.weight: Font.Bold
        }
        Body {
            Layout.fillWidth: true
            horizontalAlignment: Text.AlignHCenter
            text: "Version " + Qt.application.version
        }
        Body {
            Layout.fillWidth: true
            Layout.topMargin: 4
            horizontalAlignment: Text.AlignHCenter
            text: "A desktop music client built with Qt 6, Qt Quick and C++20."
        }
    }

    // ---- features ------------------------------------------------------------------------
    SettingsGroup {
        title: "Features"
        SettingsRow { title: "Search and browse"; subtitle: "Songs, albums, artists and playlists, plus a personalised home feed." }
        SettingsRow { title: "Player bar your way"; subtitle: "Dock it in the toolbar, or float it as a blurred glass bar at the bottom." }
        SettingsRow { title: "Full-screen player"; subtitle: "Large cover art on a blurred artwork backdrop." }
        SettingsRow { title: "Up Next and History"; subtitle: "Edit the queue, reorder songs and revisit what you played." }
        SettingsRow { title: "Likes and recents"; subtitle: "Heart a song to keep it in Liked Songs; recent plays are remembered." }
        SettingsRow { title: "Themes and accent colors"; subtitle: "Light, dark or system, with six accent colors." }
        SettingsRow { title: "Resume where you left off"; subtitle: "Your queue and position come back when Swift opens." }
        SettingsRow { title: "Keyboard shortcuts and media keys"; subtitle: "Play, skip, volume, search and more without touching the mouse." }
    }

    // ---- under the hood --------------------------------------------------------------------
    SettingsGroup {
        title: "Details"
        footer: "Music data comes from the unofficial YouTube Music API. Playback of most tracks needs yt-dlp installed separately."
        SettingsRow { title: "Version"; Body { text: Qt.application.version } }
        SettingsRow { title: "Interface"; Body { text: "Qt Quick (QML)" } }
        SettingsRow { title: "Core"; Body { text: "C++20" } }
        SettingsRow { title: "Music source"; Body { text: "YouTube Music" } }
    }

    // ---- credits ---------------------------------------------------------------------------
    ColumnLayout {
        Layout.fillWidth: true
        Layout.topMargin: 14
        spacing: 3

        Text {
            Layout.fillWidth: true
            horizontalAlignment: Text.AlignHCenter
            text: "Made by Lachowski"
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody + 1
            font.weight: Font.DemiBold
        }
        Text {
            id: link
            Layout.alignment: Qt.AlignHCenter
            text: "github.com/0-ss"
            color: Theme.accent
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
            font.underline: linkMa.containsMouse || activeFocus
            activeFocusOnTab: true
            Keys.onReturnPressed: Qt.openUrlExternally(page.repoUrl)
            Keys.onSpacePressed: Qt.openUrlExternally(page.repoUrl)
            Accessible.role: Accessible.Link
            Accessible.name: "Open github.com/0-ss"
            MouseArea {
                id: linkMa
                anchors.fill: parent
                anchors.margins: -4
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: Qt.openUrlExternally(page.repoUrl)
            }
        }
    }
}
