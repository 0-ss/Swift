import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import Swift

// Full-screen player.
//  - a slowly drifting, colour-rich wash built from the cover art (cross-fades between tracks)
//  - a large cover with a soft shadow that relaxes when playback is paused
//  - one calm column: title / artist / like, scrubber, transport, volume
//  - on wide windows a side pane slides in beside the player: Lyrics (time-synced when available)
//    or Up Next. Both are toggled from the buttons in the top-right corner
// Always rendered on a dark scheme (white text), like Music's full-screen view.
Item {
    id: np
    signal close()
    signal openQueue()      // used on narrow windows, where there is no room for the inline pane

    readonly property color fg: "white"
    readonly property color fgDim: Theme.alpha("#FFFFFF", 0.62)

    // ---- layout state ---------------------------------------------------------
    // Which side pane is showing: "lyrics", "queue" or "none". Remembered between launches.
    readonly property string paneMode: settings.values.fullscreenPane
    readonly property bool lyricsOn: settings.values.lyricsEnabled
    readonly property bool wide: width >= 720
    readonly property bool split: wide && paneMode !== "none"
    readonly property bool lyricsShown: split && paneMode === "lyrics" && lyricsOn
    readonly property real paneW: Math.max(300, Math.min(440, width * 0.4))
    readonly property real colMax: height >= 900 ? 520 : 440
    readonly property real artSize: Math.max(140, Math.min(col.width, height - 350, colMax))
    // 0 while the page is parked below the window, 1 when fully slid in (Main animates `y`)
    readonly property real reveal: height > 0 ? Math.max(0, Math.min(1, 1 - y / height)) : 0

    function togglePane(name) { settings.values.fullscreenPane = (paneMode === name) ? "none" : name }

    // lyrics are only looked up while they are actually on screen
    Binding { target: lyrics; property: "wanted"; value: np.visible && np.lyricsShown }

    // ---- inline building blocks ----------------------------------------------

    // Blurred, slowly rotating artwork. The blur is rendered into a cached layer, so the
    // rotation only moves a texture and costs next to nothing per frame.
    component Wash: Item {
        id: w
        property url src
        property real size: 800
        property bool drifting: false
        property real startAngle: 0
        readonly property bool ready: artA.status === Image.Ready

        anchors.centerIn: parent
        width: size; height: size
        rotation: startAngle
        layer.enabled: true
        layer.textureSize: Qt.size(512, 512)
        layer.smooth: true
        opacity: ready ? 1 : 0
        Behavior on opacity { enabled: w.ready; NumberAnimation { duration: 900; easing.type: Easing.InOutQuad } }

        NumberAnimation on rotation {
            from: w.startAngle; to: w.startAngle + 360
            duration: 140000
            loops: Animation.Infinite
            running: w.visible && !Theme.reduceMotion
            paused: !w.drifting
        }

        Item {
            id: srcItem
            anchors.fill: parent
            visible: false
            layer.enabled: true
            Image {
                id: artA
                anchors.fill: parent
                source: w.src
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                sourceSize.width: 160; sourceSize.height: 160
            }
            // a second, offset copy gives the wash several colour centres instead of one
            Image {
                width: parent.width * 0.7; height: width
                x: parent.width * 0.34; y: -parent.height * 0.1
                rotation: 160
                mirror: true
                opacity: 0.8
                source: w.src
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                sourceSize.width: 160; sourceSize.height: 160
            }
        }
        MultiEffect {
            anchors.fill: parent
            source: srcItem
            blurEnabled: true
            blur: 1.0
            blurMax: 64
            saturation: 0.5
            contrast: 0.05
        }
    }

    // Translucent round button for the corners of the page.
    component RoundBtn: Item {
        id: r
        property string glyph
        property bool active: false
        property string tip
        property real dia: 36
        signal clicked()
        implicitWidth: dia; implicitHeight: dia
        width: dia; height: dia
        activeFocusOnTab: true
        Accessible.role: Accessible.Button
        Accessible.name: tip || glyph
        Keys.onReturnPressed: clicked()

        scale: ma.pressed ? 0.92 : 1
        Behavior on scale { NumberAnimation { duration: Theme.fast; easing.type: Easing.OutCubic } }
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: ma.pressed ? "#4DFFFFFF" : r.active ? "#40FFFFFF" : ma.containsMouse ? "#33FFFFFF" : "#1FFFFFFF"
            border.width: r.activeFocus ? 2 : 0
            border.color: "white"
            Behavior on color { ColorAnimation { duration: Theme.fast } }
        }
        Glyph {
            x: Math.round((r.width - width) / 2)
            y: Math.round((r.height - height) / 2)
            name: r.glyph
            size: Math.round(r.dia * 0.46)
            color: "white"
        }
        MouseArea {
            id: ma
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: r.clicked()
        }
    }

    // Transport glyph. Plain glyphs shrink slightly when pressed; toggles (shuffle, repeat)
    // get a soft round plate when on, as in Music.
    component Ctl: Item {
        id: c
        property string glyph
        property real size: 24
        property real hit: 52
        property bool toggle: false
        property bool active: false
        property string tip
        signal clicked()
        implicitWidth: hit; implicitHeight: hit
        width: hit; height: hit
        activeFocusOnTab: true
        Accessible.role: Accessible.Button
        Accessible.name: tip || glyph
        Keys.onReturnPressed: clicked()

        scale: cma.pressed ? 0.86 : (cma.containsMouse && !toggle ? 1.05 : 1)
        Behavior on scale { NumberAnimation { duration: Theme.fast; easing.type: Easing.OutCubic } }
        Rectangle {
            anchors.centerIn: parent
            width: 40; height: 40; radius: 20
            visible: c.toggle
            color: c.active ? "#33FFFFFF" : cma.containsMouse ? "#1FFFFFFF" : "transparent"
            border.width: c.activeFocus ? 2 : 0
            border.color: "white"
            Behavior on color { ColorAnimation { duration: Theme.fast } }
        }
        Glyph {
            x: Math.round((c.width - width) / 2)
            y: Math.round((c.height - height) / 2)
            name: c.glyph
            size: c.size
            color: "white"
            opacity: c.toggle ? (c.active ? 1 : 0.6) : 1
        }
        MouseArea {
            id: cma
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: c.clicked()
        }
    }

    // ---- background -------------------------------------------------------------
    Rectangle { anchors.fill: parent; color: "#141416" }

    Item {
        id: washHost
        anchors.fill: parent
        clip: true

        // Two layers: a new cover loads into the one underneath-to-be, then fades in on top.
        property bool frontA: true
        property int zTop: 1
        readonly property real span: Math.hypot(np.width, np.height) * 1.02

        function show(url) {
            const target = frontA ? washB : washA
            target.src = url
            target.z = ++zTop
            frontA = !frontA
        }

        Wash { id: washA; size: washHost.span; drifting: np.visible && player.playing; startAngle: 0 }
        Wash { id: washB; size: washHost.span; drifting: np.visible && player.playing; startAngle: 90 }
    }
    property url art: player.artworkUrl
    onArtChanged: washHost.show(art)
    Component.onCompleted: { if (art.toString().length) washHost.show(art) }

    // scrim: keeps white text legible on bright covers, deeper toward the controls
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#38000000" }
            GradientStop { position: 0.55; color: "#4A000000" }
            GradientStop { position: 1.0; color: "#80000000" }
        }
    }

    MouseArea { anchors.fill: parent }   // swallow clicks to the page behind

    // ---- keyboard ---------------------------------------------------------------
    Shortcut { sequence: "Left"; enabled: np.visible; onActivated: player.seek(Math.max(0, player.position - 5000)) }
    Shortcut { sequence: "Right"; enabled: np.visible; onActivated: player.seek(Math.min(player.duration, player.position + 5000)) }

    // ---- content (fades and settles in as the page slides up) ------------------
    Item {
        id: content
        anchors.fill: parent
        opacity: Math.min(1, np.reveal * 1.6)
        scale: 0.97 + 0.03 * np.reveal

        // Close: centred over the cover, away from the window buttons on the left
        RoundBtn {
            x: Math.round(stage.width / 2 - width / 2)
            y: 16
            dia: 32
            glyph: "chevronDown"
            tip: "Close full screen player"
            onClicked: np.close()
        }

        // top-right: side pane toggles
        RoundBtn {
            id: queueBtn
            x: np.width - width - 20
            y: 20
            glyph: "upnext"
            active: np.split && np.paneMode === "queue"
            tip: "Up Next"
            onClicked: np.wide ? np.togglePane("queue") : np.openQueue()
        }
        RoundBtn {
            x: queueBtn.x - width - 10
            y: 20
            visible: np.wide
            glyph: "lyrics"
            active: np.split && np.paneMode === "lyrics"
            tip: np.paneMode === "lyrics" ? "Hide Lyrics" : "Show Lyrics"
            onClicked: np.togglePane("lyrics")
        }

        // ---- player column ----
        Item {
            id: stage
            anchors.left: parent.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            width: np.split ? np.width - np.paneW - 36 : np.width
            Behavior on width { NumberAnimation { duration: Theme.base * 1.8; easing.type: Easing.OutQuint } }

            ColumnLayout {
                id: col
                anchors.centerIn: parent
                width: Math.min(np.colMax, stage.width - 72)
                spacing: 0

                // cover + shadow; relaxes to a smaller size while paused
                Item {
                    id: artHost
                    Layout.alignment: Qt.AlignHCenter
                    Layout.preferredWidth: np.artSize
                    Layout.preferredHeight: np.artSize
                    Layout.bottomMargin: 26
                    scale: player.playing ? 1 : 0.84
                    transformOrigin: Item.Center
                    Behavior on scale { NumberAnimation { duration: Theme.base * 2.2; easing.type: Easing.OutBack; easing.overshoot: 0.9 } }

                    Rectangle {
                        id: shadowSrc
                        anchors.fill: parent
                        radius: 16
                        color: "black"
                        visible: false
                        layer.enabled: true
                    }
                    MultiEffect {
                        anchors.fill: shadowSrc
                        source: shadowSrc
                        autoPaddingEnabled: true
                        shadowEnabled: true
                        shadowColor: "black"
                        shadowOpacity: player.playing ? 0.55 : 0.3
                        shadowBlur: 1.0
                        shadowScale: 0.96
                        shadowVerticalOffset: 22
                        Behavior on shadowOpacity { NumberAnimation { duration: Theme.base * 2 } }
                    }
                    Artwork {
                        anchors.fill: parent
                        source: player.artworkUrl
                        corner: 16
                        outline: false
                        // hairline so light covers keep a defined edge on the wash
                        Rectangle {
                            anchors.fill: parent
                            radius: 16
                            color: "transparent"
                            border.width: 1
                            border.color: "#1FFFFFFF"
                        }
                    }
                }

                // title / artist / like
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2
                        Text {
                            Layout.fillWidth: true
                            text: player.title
                            elide: Text.ElideRight
                            color: np.fg
                            font.family: Theme.fontFamily
                            font.pixelSize: 22
                            font.weight: Font.DemiBold
                        }
                        Text {
                            Layout.fillWidth: true
                            text: player.artist
                            elide: Text.ElideRight
                            color: np.fgDim
                            font.family: Theme.fontFamily
                            font.pixelSize: 17
                        }
                    }
                    RoundBtn {
                        readonly property bool liked: library.favoriteIds.indexOf(player.videoId) >= 0
                        glyph: liked ? "heartFill" : "heart"
                        active: liked
                        tip: liked ? "Remove from Liked Songs" : "Add to Liked Songs"
                        onClicked: library.toggleFavorite({videoId: player.videoId, title: player.title, artist: player.artist,
                                                           album: player.album, artworkUrl: player.artworkUrl, durationMs: player.duration})
                    }
                }

                // scrubber
                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.topMargin: 18
                    spacing: 0
                    ProgressSlider {
                        Layout.fillWidth: true
                        fillColor: Theme.alpha("#FFFFFF", 0.9)
                        trackColor: Theme.alpha("#FFFFFF", 0.24)
                        to: Math.max(1, player.duration)
                        value: player.position
                        onCommitted: (v) => player.seek(v)
                    }
                    RowLayout {
                        Layout.fillWidth: true
                        Text { text: Theme.fmt(player.position); color: np.fgDim; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall }
                        Item { Layout.fillWidth: true }
                        Text { visible: player.loading; text: "Loading…"; color: np.fgDim; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall }
                        Item { Layout.fillWidth: true }
                        Text { text: Theme.fmtRemaining(player.position, player.duration); color: np.fgDim; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall }
                    }
                }

                // transport
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    Layout.topMargin: 8
                    spacing: 18
                    Ctl { glyph: "shuffle"; size: 18; toggle: true; active: player.shuffle; tip: "Shuffle"
                          onClicked: player.shuffle = !player.shuffle }
                    Ctl { glyph: "prev"; size: 30; tip: "Previous"; onClicked: player.previous() }
                    Ctl { glyph: player.playing ? "pause" : "play"; size: 46; hit: 68
                          tip: player.playing ? "Pause" : "Play"; onClicked: player.togglePlayback() }
                    Ctl { glyph: "next"; size: 30; tip: "Next"; onClicked: player.next() }
                    Ctl { glyph: player.repeatMode === 2 ? "repeatOne" : "repeat"; size: 18; toggle: true
                          active: player.repeatMode > 0; tip: "Repeat"; onClicked: player.cycleRepeat() }
                }

                // volume
                RowLayout {
                    Layout.fillWidth: true
                    Layout.topMargin: 14
                    spacing: 10
                    Glyph { Layout.preferredWidth: 14; Layout.preferredHeight: 14; name: "speakerMute"; size: 14; color: np.fgDim }
                    ProgressSlider {
                        Layout.fillWidth: true
                        fillColor: Theme.alpha("#FFFFFF", 0.75)
                        trackColor: Theme.alpha("#FFFFFF", 0.24)
                        value: player.volume
                        onMoved: (v) => player.volume = v
                        onCommitted: (v) => player.volume = v
                    }
                    Glyph { Layout.preferredWidth: 18; Layout.preferredHeight: 16; name: "speakerWave"; size: 16; color: np.fgDim }
                }
            }
        }

        // ---- side pane (wide windows): Lyrics or Up Next ----
        Item {
            id: pane
            width: np.paneW
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            x: np.split ? np.width - width - 20 : np.width
            opacity: np.split ? 1 : 0
            visible: opacity > 0.01
            Behavior on x { NumberAnimation { duration: Theme.base * 1.8; easing.type: Easing.OutQuint } }
            Behavior on opacity { NumberAnimation { duration: Theme.base * 1.4 } }

            // ======== Lyrics ========
            Item {
                id: lyricsView
                anchors.fill: parent
                anchors.topMargin: 64
                anchors.bottomMargin: 4
                visible: np.paneMode === "lyrics"

                // lyrics: 0 idle, 1 loading, 2 ready, 3 not found, 4 instrumental, 5 failed
                readonly property int st: lyrics.status
                readonly property int fontPx: Math.round(Math.max(22, Math.min(32, np.paneW * 0.074)))

                // message states
                ColumnLayout {
                    anchors.centerIn: parent
                    width: parent.width - 40
                    spacing: 10
                    visible: !np.lyricsOn || lyricsView.st !== 2
                    Glyph {
                        Layout.alignment: Qt.AlignHCenter
                        Layout.preferredWidth: 30; Layout.preferredHeight: 30
                        name: "lyrics"; size: 30; color: np.fgDim
                        opacity: 0.7
                        visible: !np.lyricsOn || !player.hasTrack || lyricsView.st === 3 || lyricsView.st === 4 || lyricsView.st === 5
                    }
                    Text {
                        id: msgText
                        Layout.fillWidth: true
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.WordWrap
                        color: np.fgDim
                        font.family: Theme.fontFamily
                        font.pixelSize: 15
                        font.weight: Font.Medium
                        // "Loading" is only shown while a lookup is really in flight (st 1); idle is not loading
                        text: !np.lyricsOn ? "Lyrics are turned off in Settings."
                            : !player.hasTrack ? "Play a song to see its lyrics"
                            : lyricsView.st === 1 ? "Loading lyrics…"
                            : lyricsView.st === 3 ? "No lyrics available"
                            : lyricsView.st === 4 ? "Instrumental"
                            : lyricsView.st === 5 ? "Couldn’t reach lrclib.net"
                            : ""
                        // soft pulse while loading
                        SequentialAnimation on opacity {
                            loops: Animation.Infinite
                            running: np.lyricsOn && lyricsView.st === 1 && pane.visible && !Theme.reduceMotion
                            onRunningChanged: if (!running) msgText.opacity = 1.0
                            NumberAnimation { to: 0.45; duration: 800; easing.type: Easing.InOutSine }
                            NumberAnimation { to: 1.0; duration: 800; easing.type: Easing.InOutSine }
                        }
                    }
                    Rectangle {
                        Layout.alignment: Qt.AlignHCenter
                        visible: np.lyricsOn && lyricsView.st === 5
                        implicitWidth: retryText.implicitWidth + 28; implicitHeight: 30; radius: 15
                        color: retryMa.pressed ? "#4DFFFFFF" : retryMa.containsMouse ? "#33FFFFFF" : "#26FFFFFF"
                        Text { id: retryText; anchors.centerIn: parent; text: "Try Again"; color: np.fg
                               font.family: Theme.fontFamily; font.pixelSize: Theme.sizeBody; font.weight: Font.DemiBold }
                        MouseArea { id: retryMa; anchors.fill: parent; hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor; onClicked: lyrics.retry() }
                    }
                }

                // soft fade at the top and bottom edge
                Item {
                    id: lyricsFade
                    anchors.fill: lyricList
                    visible: false
                    layer.enabled: true
                    Rectangle {
                        anchors.fill: parent
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: "transparent" }
                            GradientStop { position: 0.1; color: "black" }
                            GradientStop { position: 0.84; color: "black" }
                            GradientStop { position: 1.0; color: "transparent" }
                        }
                    }
                }

                ListView {
                    id: lyricList
                    anchors.fill: parent
                    visible: np.lyricsOn && lyricsView.st === 2
                    clip: true
                    model: lyrics.lines
                    boundsBehavior: Flickable.StopAtBounds
                    cacheBuffer: 200000          // lyrics are short: keep every line alive so positions are exact
                    reuseItems: false
                    topMargin: lyrics.synced ? Math.round(height * 0.30) : 6
                    bottomMargin: lyrics.synced ? Math.round(height * 0.55) : 40
                    layer.enabled: true
                    layer.effect: MultiEffect { maskEnabled: true; maskSource: lyricsFade }

                    // Scrolling that follows the song, until the user scrolls by hand
                    property bool userScrolling: false
                    function resetScroll() {
                        scrollAnim.stop()
                        contentY = -topMargin
                        userScrolling = false
                        follow()
                    }
                    function follow() {
                        if (userScrolling || !lyrics.synced || lyrics.status !== 2) return
                        const idx = lyrics.currentIndex
                        if (idx < 0) { scrollAnim.stop(); contentY = -topMargin; return }
                        const it = itemAtIndex(idx)
                        if (!it) { positionViewAtIndex(idx, ListView.Beginning); contentY -= topMargin; return }
                        scrollAnim.stop()
                        scrollAnim.to = it.y - topMargin
                        scrollAnim.restart()
                    }
                    NumberAnimation {
                        id: scrollAnim
                        target: lyricList
                        property: "contentY"
                        duration: Theme.base * 2.6
                        easing.type: Easing.OutCubic
                    }
                    Timer { id: resume; interval: 3500; onTriggered: { lyricList.userScrolling = false; lyricList.follow() } }
                    onMovementStarted: { userScrolling = true; resume.stop(); scrollAnim.stop() }
                    onMovementEnded: resume.restart()

                    Connections {
                        target: lyrics
                        function onCurrentIndexChanged() { lyricList.follow() }
                        function onStatusChanged() { if (lyrics.status === 2) Qt.callLater(lyricList.resetScroll) }
                    }
                    Connections { target: np; function onSplitChanged() { if (np.lyricsShown) Qt.callLater(lyricList.resetScroll) } }
                    Component.onCompleted: Qt.callLater(resetScroll)

                    delegate: Item {
                        id: ln
                        readonly property bool synced: lyrics.synced
                        readonly property bool gap: model.text === ""
                        readonly property bool cur: synced && index === lyrics.currentIndex
                        readonly property int dist: Math.abs(index - lyrics.currentIndex)
                        readonly property real px: synced ? lyricsView.fontPx : Math.round(lyricsView.fontPx * 0.68)

                        width: lyricList.width
                        height: gap ? (synced ? 56 : 16) : txt.implicitHeight + (synced ? 24 : 10)
                        opacity: !synced ? 0.92
                               : cur ? 1
                               : ma.containsMouse ? 0.8
                               : dist === 1 ? 0.5 : 0.32
                        scale: synced && !cur ? 0.95 : 1
                        transformOrigin: Item.Left
                        Behavior on opacity { NumberAnimation { duration: Theme.base * 1.6; easing.type: Easing.OutCubic } }
                        Behavior on scale { NumberAnimation { duration: Theme.base * 1.6; easing.type: Easing.OutCubic } }

                        Text {
                            id: txt
                            visible: !ln.gap
                            x: 6
                            y: ln.synced ? 12 : 5
                            width: parent.width - 18
                            text: model.text
                            wrapMode: Text.WordWrap
                            color: np.fg
                            font.family: Theme.fontFamily
                            font.pixelSize: ln.px
                            font.weight: ln.synced ? Font.Bold : Font.Medium
                            lineHeight: 1.06
                        }
                        // instrumental gap in synced lyrics: three dots that breathe while it is current
                        Row {
                            id: dots
                            visible: ln.gap && ln.synced
                            x: 6
                            y: Math.round((ln.height - 10) / 2)
                            spacing: 8
                            transformOrigin: Item.Left
                            Repeater {
                                model: 3
                                Rectangle { width: 10; height: 10; radius: 5; color: np.fg }
                            }
                            SequentialAnimation on scale {
                                loops: Animation.Infinite
                                running: ln.cur && player.playing && dots.visible && !Theme.reduceMotion
                                NumberAnimation { to: 1.22; duration: 900; easing.type: Easing.InOutSine }
                                NumberAnimation { to: 1.0; duration: 900; easing.type: Easing.InOutSine }
                            }
                        }
                        MouseArea {
                            id: ma
                            anchors.fill: parent
                            enabled: ln.synced && !ln.gap
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: { lyricList.userScrolling = false; player.seek(model.timeMs) }
                        }
                    }
                }
            }

            // ======== Up Next ========
            ColumnLayout {
                id: queueView
                anchors.fill: parent
                anchors.topMargin: 76
                anchors.bottomMargin: 36
                spacing: 10
                visible: np.paneMode === "queue"

                function centerCurrent() {
                    if (player.queue.currentIndex >= 0)
                        queueList.positionViewAtIndex(player.queue.currentIndex, ListView.Center)
                }
                Connections {
                    target: np
                    function onSplitChanged() { if (np.split && np.paneMode === "queue") Qt.callLater(queueView.centerCurrent) }
                    function onPaneModeChanged() { if (np.split && np.paneMode === "queue") Qt.callLater(queueView.centerCurrent) }
                }
                Connections {
                    target: player.queue
                    function onCurrentIndexChanged() { if (np.split && np.paneMode === "queue") Qt.callLater(queueView.centerCurrent) }
                }

                RowLayout {
                    Layout.fillWidth: true
                    Layout.leftMargin: 10
                    Text {
                        text: "Up Next"
                        color: np.fg
                        font.family: Theme.fontFamily
                        font.pixelSize: 20
                        font.weight: Font.DemiBold
                    }
                    Item { Layout.fillWidth: true }
                    Text {
                        visible: player.queue.count > 0
                        text: player.queue.count === 1 ? "1 song" : player.queue.count + " songs"
                        color: np.fgDim
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.sizeBody
                    }
                }

                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    Text {
                        visible: player.queue.count === 0
                        anchors.centerIn: parent
                        width: parent.width - 40
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.WordWrap
                        text: "Nothing is queued. Use “Add to Queue” from a song’s … menu."
                        color: np.fgDim
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.sizeBody
                    }

                    Item {
                        id: fadeMask
                        anchors.fill: queueList
                        visible: false
                        layer.enabled: true
                        Rectangle {
                            anchors.fill: parent
                            gradient: Gradient {
                                GradientStop { position: 0.0; color: "transparent" }
                                GradientStop { position: 0.06; color: "black" }
                                GradientStop { position: 0.92; color: "black" }
                                GradientStop { position: 1.0; color: "transparent" }
                            }
                        }
                    }

                    ListView {
                        id: queueList
                        anchors.fill: parent
                        clip: true
                        boundsBehavior: Flickable.StopAtBounds
                        model: player.queue
                        layer.enabled: true
                        layer.effect: MultiEffect { maskEnabled: true; maskSource: fadeMask }

                        delegate: Item {
                            id: row
                            width: queueList.width
                            height: 62
                            readonly property bool cur: model.isCurrent
                            HoverHandler { id: rowHover }

                            Rectangle {
                                anchors.fill: parent
                                anchors.topMargin: 1; anchors.bottomMargin: 1
                                radius: 10
                                color: row.cur ? "#29FFFFFF" : rowHover.hovered ? "#17FFFFFF" : "transparent"
                                Behavior on color { ColorAnimation { duration: Theme.fast } }
                            }
                            RowLayout {
                                anchors.fill: parent
                                anchors.leftMargin: 8
                                anchors.rightMargin: 12
                                spacing: 12
                                Artwork {
                                    Layout.preferredWidth: 46; Layout.preferredHeight: 46
                                    source: model.artworkUrl
                                    corner: 7
                                    outline: false
                                    Rectangle {
                                        anchors.fill: parent
                                        radius: 7
                                        color: "#73000000"
                                        visible: rowHover.hovered || row.cur
                                        Glyph { visible: rowHover.hovered; anchors.centerIn: parent; anchors.horizontalCenterOffset: 1; name: "play"; size: 16; color: "white" }
                                        Equalizer { visible: !rowHover.hovered && row.cur; anchors.centerIn: parent; color: "white"; running: player.playing }
                                    }
                                }
                                ColumnLayout {
                                    Layout.fillWidth: true
                                    spacing: 1
                                    Text {
                                        Layout.fillWidth: true
                                        text: model.title
                                        elide: Text.ElideRight
                                        color: np.fg
                                        font.family: Theme.fontFamily
                                        font.pixelSize: 14
                                        font.weight: row.cur ? Font.DemiBold : Font.Normal
                                    }
                                    Text {
                                        Layout.fillWidth: true
                                        text: model.artist
                                        elide: Text.ElideRight
                                        color: np.fgDim
                                        font.family: Theme.fontFamily
                                        font.pixelSize: Theme.sizeBody
                                    }
                                }
                            }
                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: player.playQueueIndex(index)
                            }
                        }
                    }
                }
            }
        }
    }
}
