#include "AppController.h"

AppController::AppController(MusicProvider *provider, SettingsService *settings, QObject *parent)
    : QObject(parent), m_provider(provider), m_settings(settings)
{
    connect(m_provider, &MusicProvider::searchFinished, this,
            [this](quint64 token, const hm::SearchResults &r) {
        if (token != m_searchToken) return;
        m_cache.insert(QString::number(int(m_filter)) + ':' + m_query.toLower(), r);
        m_searchLoading = false;
        applySearch(r);
    });
    connect(m_provider, &MusicProvider::collectionLoaded, this,
            [this](quint64 token, const hm::SearchResults &r) {
        if (token == m_detailToken) {
            m_detailLoading = false;
            m_detailTracks.setTracks(r.tracks);
            m_detailCollections.setItems(r.collections);
            emit detailChanged();
        } else if (token == m_homeToken) {
            m_homeLoading = false;
            m_homeFailed = r.tracks.isEmpty() && r.collections.isEmpty();
            m_homeTracks.setTracks(r.tracks.mid(0, 20));
            m_homeCollections.setItems(r.collections);
            emit homeStateChanged();
        }
    });
    connect(m_provider, &MusicProvider::failed, this, [this](quint64 token, const hm::ApiError &e) {
        if (token == m_searchToken) {
            m_searchLoading = false;
            emit searchStateChanged();
            setError(e);
        } else if (token == m_detailToken) {
            m_detailLoading = false;
            emit detailChanged();
            setError(e);
        } else if (token == m_homeToken) {
            m_homeLoading = false;
            m_homeFailed = true;
            emit homeStateChanged();
            // Home is best-effort; stay quiet unless the cause needs the person to act.
            if (e.kind == hm::ApiError::AuthRequired) setError(e);
        }
    });
}

void AppController::search(const QString &query, int filter)
{
    const QString q = query.trimmed();
    if (q.isEmpty()) return;
    m_query = q;
    m_filter = hm::SearchFilter(qBound(0, filter, 4));

    const QString key = QString::number(int(m_filter)) + ':' + q.toLower();
    if (m_cache.contains(key)) {
        m_searchToken = 0;
        m_searchLoading = false;
        applySearch(m_cache.value(key));
        return;
    }
    m_searchLoading = true;
    m_searchTracks.clear();
    m_searchCollections.setItems({});
    emit searchStateChanged();
    m_searchToken = m_provider->search(q, m_filter);
}

void AppController::applySearch(const hm::SearchResults &r)
{
    m_searchTracks.setTracks(r.tracks);
    m_searchCollections.setItems(r.collections);
    emit searchStateChanged();
}

void AppController::openCollection(const QVariantMap &collection)
{
    const hm::Collection c = hm::collectionFromVariant(collection);
    if (c.browseId.isEmpty()) return;
    m_detail = collection;
    m_detailLoading = true;
    m_detailTracks.clear();
    m_detailCollections.setItems({});
    emit detailChanged();
    m_detailToken = m_provider->loadCollection(c);
}

void AppController::loadHome()
{
    if (m_homeLoading) return;
    m_homeLoading = true;
    m_homeFailed = false;
    emit homeStateChanged();
    hm::Collection home;
    home.browseId = "FEmusic_home";
    m_homeToken = m_provider->loadCollection(home);
}

void AppController::setError(const hm::ApiError &e)
{
    m_error = hm::userMessage(e);
    emit errorChanged();
}

void AppController::clearError()
{
    if (m_error.isEmpty()) return;
    m_error.clear();
    emit errorChanged();
}
