#pragma once
#include "api/MusicProvider.h"
#include "models/QueueModel.h"
#include <QAudioOutput>
#include <QMediaPlayer>
#include <QHash>
#include <QTimer>

class SettingsService;

class MusicPlayer : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool playing READ playing NOTIFY playingChanged)
    Q_PROPERTY(bool loading READ loading NOTIFY loadingChanged)
    Q_PROPERTY(bool hasTrack READ hasTrack NOTIFY trackChanged)
    Q_PROPERTY(qint64 position READ position NOTIFY positionChanged)
    Q_PROPERTY(qint64 duration READ duration NOTIFY durationChanged)
    Q_PROPERTY(float volume READ volume WRITE setVolume NOTIFY volumeChanged)
    Q_PROPERTY(QString videoId READ videoId NOTIFY trackChanged)
    Q_PROPERTY(QString title READ title NOTIFY trackChanged)
    Q_PROPERTY(QString artist READ artist NOTIFY trackChanged)
    Q_PROPERTY(QString album READ album NOTIFY trackChanged)
    Q_PROPERTY(QString artworkUrl READ artworkUrl NOTIFY trackChanged)
    Q_PROPERTY(bool shuffle READ shuffle WRITE setShuffle NOTIFY shuffleChanged)
    Q_PROPERTY(int repeatMode READ repeatMode WRITE setRepeatMode NOTIFY repeatModeChanged) // 0 off, 1 all, 2 one
    Q_PROPERTY(QString errorMessage READ errorMessage NOTIFY errorChanged)
    Q_PROPERTY(QueueModel *queue READ queue CONSTANT)
public:
    MusicPlayer(MusicProvider *provider, SettingsService *settings, QObject *parent = nullptr);

    bool playing() const { return m_player.playbackState() == QMediaPlayer::PlayingState; }
    bool loading() const { return m_loading; }
    bool hasTrack() const { return m_queue->currentTrack().isValid(); }
    qint64 position() const;
    qint64 duration() const;
    float volume() const { return m_volume; }
    QString videoId() const { return m_queue->currentTrack().videoId; }
    QString title() const { return m_queue->currentTrack().title; }
    QString artist() const { return m_queue->currentTrack().artist; }
    QString album() const { return m_queue->currentTrack().album; }
    QString artworkUrl() const { return m_queue->currentTrack().artworkUrl; }
    bool shuffle() const { return m_shuffle; }
    int repeatMode() const { return m_repeat; }
    QString errorMessage() const { return m_error; }
    QueueModel *queue() { return m_queue; }

    void setVolume(float v);
    void setShuffle(bool on);
    void setRepeatMode(int mode);

    Q_INVOKABLE void play();
    Q_INVOKABLE void pause();
    Q_INVOKABLE void togglePlayback();
    Q_INVOKABLE void next();
    Q_INVOKABLE void previous();
    Q_INVOKABLE void seek(qint64 position);
    Q_INVOKABLE void cycleRepeat() { setRepeatMode((m_repeat + 1) % 3); }

    // Replace the queue with the contents of `model` and start at `index`.
    Q_INVOKABLE void playFrom(QObject *model, int index);
    Q_INVOKABLE void playQueueIndex(int index);
    // Replace the queue with `tracks` (list of track maps) and start playing.
    Q_INVOKABLE void playTracks(const QVariantList &tracks, int index = 0, bool shuffle = false);
    Q_INVOKABLE void enqueue(const QVariantMap &track);
    Q_INVOKABLE void playNext(const QVariantMap &track);
    Q_INVOKABLE void removeFromQueue(int index);
    Q_INVOKABLE void moveInQueue(int from, int to);
    Q_INVOKABLE void clearQueue();

public slots:
    void saveState();

signals:
    void playingChanged();
    void loadingChanged();
    void positionChanged();
    void durationChanged();
    void volumeChanged();
    void trackChanged();
    void shuffleChanged();
    void repeatModeChanged();
    void errorChanged();
    void trackStarted(const hm::Track &track);

private:
    void setCurrent(int index, bool autoplay);
    void loadCurrent(bool autoplay, qint64 seekTo = 0);
    // Stream-drop recovery: resume the current track where it stopped (see MusicPlayer.cpp).
    void recover();
    void startSource(const QUrl &url);
    void applyPendingSeek();
    void verifySeek();
    void cancelRecovery();
    qint64 streamDuration() const;
    static qint64 urlExpiry(const QUrl &url);
    bool advance();
    void setLoading(bool on);
    void setError(const QString &msg);
    void restoreState();
    void onStreamResolved(quint64 token, const QString &videoId, const QUrl &url);
    void onProviderFailed(quint64 token, const hm::ApiError &err);
    void onMediaStatus(QMediaPlayer::MediaStatus status);
    void onPlayerError(QMediaPlayer::Error error, const QString &text);

    MusicProvider *m_provider;
    SettingsService *m_settings;
    QAudioOutput m_audio;
    QMediaPlayer m_player;
    QueueModel *m_queue;
    QTimer m_saveTimer;

	quint64 m_token = 0;
	qint64 m_pendingSeek = 0;
	qint64 m_lastKnownPosition = 0;
	QVector<int> m_history;
    float m_volume = 0.8f;
    int m_repeat = 0;
    int m_failStreak = 0;
    bool m_shuffle = false;
    bool m_loading = false;
    bool m_autoplay = false;
    bool m_startedLogged = false;
    int m_retryCount = 0;          // consecutive recoveries without stable playback in between
    bool m_wantPlaying = false;    // the user wants audio (not paused): recovery resumes playback
    bool m_recoveryPending = false;     // a recovery is scheduled / resolving; errors are ignored meanwhile
    bool m_resolvingForRecovery = false;
    quint64 m_generation = 0;      // bumped whenever a load or recovery is superseded
    qint64 m_recoverBase = 0;      // position a recovery resumed from
    qint64 m_seekTarget = 0;       // resume position being verified after a seek
    int m_seekTries = 0;
    QTimer m_seekVerify;
    struct CachedUrl { QUrl url; qint64 expiresMs = 0; };
    QHash<QString, CachedUrl> m_urls;   // last resolved stream per track, reused to resume cheaply
    QString m_error;
};
