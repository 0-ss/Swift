#pragma once
#include <QJsonObject>
#include <QString>
#include <QVariantMap>
#include <QVector>

namespace hm {

struct Track {
    QString videoId;
    // A unique playlist-item identifier supplied by YouTube Music. It is required
    // for safe removal and positioning when a playlist contains duplicate videos.
    QString setVideoId;
    QString title, artist, album, artworkUrl;
    qint64 durationMs = 0;

    bool isValid() const { return !videoId.isEmpty(); }
    QJsonObject toJson() const;
    static Track fromJson(const QJsonObject &o);
};

enum class CollectionKind { Unknown, Album, Artist, Playlist };
QString toString(CollectionKind k);
CollectionKind collectionKindFromString(const QString &s);

struct Collection {
    QString browseId, title, subtitle, artworkUrl;
    CollectionKind kind = CollectionKind::Unknown;
};

struct RemotePlaylist {
    QString id, name, description;
    int trackCount = 0;
    qint64 durationMs = 0;
    QStringList covers;
    bool owned = true;
    QVector<Track> tracks;
};

struct AccountInfo {
    QString name, channelHandle, photoUrl;
};

enum class SearchFilter { All = 0, Songs, Albums, Artists, Playlists };

struct SearchResults {
    QVector<Track> tracks;
    QVector<Collection> collections;
};

struct ApiError {
    enum Kind { None, Network, RateLimited, InvalidResponse, AuthRequired, Unavailable, Unknown };
    Kind kind = None;
    QString message;
    int retryAfterSec = 0;
    explicit operator bool() const { return kind != None; }
};

QString userMessage(const ApiError &e);

QVariantMap toVariant(const Track &t);
Track trackFromVariant(const QVariantMap &m);
QVariantMap toVariant(const Collection &c);
Collection collectionFromVariant(const QVariantMap &m);

} // namespace hm
