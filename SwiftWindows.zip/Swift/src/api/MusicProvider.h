#pragma once
#include "Types.h"
#include <QObject>
#include <QUrl>

// Everything the app needs from a music backend. Every call returns a token;
// callers use it to ignore stale results and to associate a remote mutation with
// its confirmation response.
class MusicProvider : public QObject
{
    Q_OBJECT
public:
    using QObject::QObject;

    virtual quint64 search(const QString &query, hm::SearchFilter filter) = 0;
    virtual quint64 loadCollection(const hm::Collection &collection) = 0;
    virtual quint64 resolveStream(const QString &videoId) = 0;

    virtual quint64 fetchAccountInfo() = 0;
    virtual quint64 loadLibraryPlaylists() = 0;
    virtual quint64 loadPlaylist(const QString &playlistId) = 0;
    virtual quint64 createPlaylist(const QString &name, const QString &description,
                                   const QVector<hm::Track> &initialTracks) = 0;
    virtual quint64 updatePlaylist(const QString &playlistId, const QString &name,
                                   const QString &description) = 0;
    virtual quint64 deletePlaylist(const QString &playlistId) = 0;
    virtual quint64 addPlaylistItems(const QString &playlistId, const QVector<hm::Track> &tracks) = 0;
    virtual quint64 removePlaylistItems(const QString &playlistId, const QVector<hm::Track> &tracks) = 0;
    virtual quint64 reorderPlaylist(const QString &playlistId, const QVector<hm::Track> &orderedTracks) = 0;

signals:
    void searchFinished(quint64 token, const hm::SearchResults &results);
    void collectionLoaded(quint64 token, const hm::SearchResults &results);
    void streamResolved(quint64 token, const QString &videoId, const QUrl &url);
    void accountInfoLoaded(quint64 token, const hm::AccountInfo &account);
    void libraryPlaylistsLoaded(quint64 token, const QVector<hm::RemotePlaylist> &playlists);
    void remotePlaylistLoaded(quint64 token, const hm::RemotePlaylist &playlist);
    // createdPlaylistId is non-empty only for a successful creation request.
    void playlistMutationFinished(quint64 token, const QString &playlistId, const QString &createdPlaylistId);
    void failed(quint64 token, const hm::ApiError &error);

protected:
    quint64 newToken() { return ++m_token; }

private:
    quint64 m_token = 0;
};
