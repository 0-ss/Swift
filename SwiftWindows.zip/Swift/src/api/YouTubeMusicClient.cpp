#include "YouTubeMusicClient.h"

#include "services/AccountService.h"
#include "services/SettingsService.h"
#include <QCryptographicHash>
#include <QDate>
#include <QDateTime>
#include <QJsonArray>
#include <QProcess>
#include <QRegularExpression>
#include <QSet>
#include <QTimer>
#include <QUrlQuery>
#include <utility>

using namespace hm;

namespace {

const QByteArray kOrigin = "https://music.youtube.com";
// This is the public WEB_REMIX client key used by the web app. It identifies the
// client, not a user; account authorization is always the user's SAPISIDHASH.
const QString kWebRemixApiKey = QStringLiteral("AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30");

template<typename... K>
QJsonValue dig(const QJsonValue &start, K... keys)
{
    QJsonValue value = start;
    ((value = value.toObject().value(QLatin1String(keys))), ...);
    return value;
}

QString textFromRuns(const QJsonArray &runs)
{
    QString text;
    for (const QJsonValue &run : runs) text += run.toObject().value("text").toString();
    return text;
}

QString filterParams(SearchFilter filter)
{
    switch (filter) {
    case SearchFilter::Songs: return "EgWKAQIIAWoKEAkQBRAKEAMQBA==";
    case SearchFilter::Albums: return "EgWKAQIYAWoKEAkQChAFEAMQBA==";
    case SearchFilter::Artists: return "EgWKAQIgAWoKEAkQChAFEAMQBA==";
    case SearchFilter::Playlists: return "Eg-KAQwIABAAGAAgACgBMABqChAEEAMQCRAFEAo=";
    default: return {};
    }
}

QString bestThumb(const QJsonArray &thumbs)
{
    if (thumbs.isEmpty()) return {};
    QString url = thumbs.last().toObject().value("url").toString();
    static const QRegularExpression sizeSuffix("=w\\d+-h\\d+.*$");
    return url.replace(sizeSuffix, "=w544-h544-l90-rj");
}

QStringList splitRuns(const QJsonArray &runs)
{
    QStringList parts;
    QString current;
    for (const QJsonValue &run : runs) {
        const QString text = run.toObject().value("text").toString();
        if (text.trimmed() == QStringLiteral("•")) {
            if (!current.isEmpty()) parts << current;
            current.clear();
        } else {
            current += text;
        }
    }
    if (!current.isEmpty()) parts << current;
    return parts;
}

bool isDuration(const QString &value)
{
    static const QRegularExpression re("^\\d{1,2}(:\\d{2}){1,2}$");
    return re.match(value).hasMatch();
}

qint64 parseDuration(const QString &value)
{
    qint64 seconds = 0;
    for (const QString &part : value.split(':')) seconds = seconds * 60 + part.toInt();
    return seconds * 1000;
}

CollectionKind kindFromPageType(const QString &pageType)
{
    if (pageType.contains("ALBUM")) return CollectionKind::Album;
    if (pageType.contains("ARTIST") || pageType.contains("USER_CHANNEL")) return CollectionKind::Artist;
    if (pageType.contains("PLAYLIST")) return CollectionKind::Playlist;
    return CollectionKind::Unknown;
}

QString pageTypeOf(const QJsonValue &navEndpoint)
{
    return dig(navEndpoint, "browseEndpoint", "browseEndpointContextSupportedConfigs",
               "browseEndpointContextMusicConfig", "pageType").toString();
}

QJsonObject firstObjectWithKey(const QJsonValue &value, const QString &key)
{
    if (value.isArray()) {
        for (const QJsonValue &entry : value.toArray()) {
            const QJsonObject found = firstObjectWithKey(entry, key);
            if (!found.isEmpty()) return found;
        }
    } else if (value.isObject()) {
        const QJsonObject object = value.toObject();
        if (object.value(key).isObject()) return object.value(key).toObject();
        for (auto it = object.constBegin(); it != object.constEnd(); ++it) {
            const QJsonObject found = firstObjectWithKey(it.value(), key);
            if (!found.isEmpty()) return found;
        }
    }
    return {};
}

QString findSetVideoId(const QJsonValue &value)
{
    if (value.isArray()) {
        for (const QJsonValue &entry : value.toArray()) {
            const QString id = findSetVideoId(entry);
            if (!id.isEmpty()) return id;
        }
    } else if (value.isObject()) {
        const QJsonObject object = value.toObject();
        const QJsonObject endpoint = object.value("playlistEditEndpoint").toObject();
        for (const QJsonValue &actionValue : endpoint.value("actions").toArray()) {
            const QJsonObject action = actionValue.toObject();
            if (action.value("action").toString() == "ACTION_REMOVE_VIDEO"
                    && !action.value("setVideoId").toString().isEmpty())
                return action.value("setVideoId").toString();
        }
        for (auto it = object.constBegin(); it != object.constEnd(); ++it) {
            const QString id = findSetVideoId(it.value());
            if (!id.isEmpty()) return id;
        }
    }
    return {};
}

void parseListItem(const QJsonObject &object, SearchResults &out)
{
    const QJsonArray flex = object.value("flexColumns").toArray();
    auto runsAt = [&](int index) -> QJsonArray {
        return index < flex.size()
            ? dig(QJsonValue(flex[index]), "musicResponsiveListItemFlexColumnRenderer", "text", "runs").toArray()
            : QJsonArray{};
    };
    const QJsonArray titleRuns = runsAt(0);
    if (titleRuns.isEmpty()) return;

    const QString title = textFromRuns(titleRuns);
    QString videoId = dig(object, "playlistItemData", "videoId").toString();
    if (videoId.isEmpty())
        videoId = dig(QJsonValue(titleRuns.first()), "navigationEndpoint", "watchEndpoint", "videoId").toString();

    const QStringList partsOriginal = splitRuns(runsAt(1));
    QStringList parts = partsOriginal;
    const QString artwork = bestThumb(dig(object, "thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails").toArray());

    if (!videoId.isEmpty()) {
        Track track;
        track.videoId = videoId;
        track.setVideoId = findSetVideoId(object.value("menu"));
        track.title = title;
        track.artworkUrl = artwork;
        bool isVideo = false;
        if (!parts.isEmpty() && (parts.first() == "Song" || parts.first() == "Video")) {
            isVideo = parts.first() == "Video";
            parts.removeFirst();
        }
        if (!parts.isEmpty() && isDuration(parts.last())) track.durationMs = parseDuration(parts.takeLast());
        if (!parts.isEmpty()) track.artist = parts.first();
        if (parts.size() > 1 && !isVideo) track.album = parts[1];
        if (track.album.isEmpty() && !isVideo) {
            const QJsonArray albumRuns = runsAt(2);
            if (!albumRuns.isEmpty()) track.album = textFromRuns(albumRuns);
        }
        if (track.durationMs == 0) {
            const QJsonArray fixed = object.value("fixedColumns").toArray();
            if (!fixed.isEmpty()) {
                const QJsonArray durationRuns = dig(QJsonValue(fixed.first()),
                                                    "musicResponsiveListItemFixedColumnRenderer", "text", "runs").toArray();
                if (!durationRuns.isEmpty()) {
                    const QString duration = textFromRuns(durationRuns);
                    if (isDuration(duration)) track.durationMs = parseDuration(duration);
                }
            }
        }
        out.tracks << track;
        return;
    }

    const QString browseId = dig(object, "navigationEndpoint", "browseEndpoint", "browseId").toString();
    const CollectionKind kind = kindFromPageType(pageTypeOf(object.value("navigationEndpoint")));
    if (browseId.isEmpty() || kind == CollectionKind::Unknown) return;
    out.collections.push_back({browseId, title, partsOriginal.join(" • "), artwork, kind});
}

void parseTwoRowItem(const QJsonObject &object, SearchResults &out)
{
    const QString title = textFromRuns(object.value("title").toObject().value("runs").toArray());
    if (title.isEmpty()) return;
    const QString subtitle = splitRuns(object.value("subtitle").toObject().value("runs").toArray()).join(" • ");
    const QString artwork = bestThumb(dig(object, "thumbnailRenderer", "musicThumbnailRenderer", "thumbnail", "thumbnails").toArray());
    const QString videoId = dig(object, "navigationEndpoint", "watchEndpoint", "videoId").toString();
    if (!videoId.isEmpty()) {
        out.tracks.push_back({videoId, {}, title, subtitle, {}, artwork, 0});
        return;
    }
    const QString browseId = dig(object, "navigationEndpoint", "browseEndpoint", "browseId").toString();
    const CollectionKind kind = kindFromPageType(pageTypeOf(object.value("navigationEndpoint")));
    if (browseId.isEmpty() || kind == CollectionKind::Unknown) return;
    out.collections.push_back({browseId, title, subtitle, artwork, kind});
}

void walkResults(const QJsonValue &value, SearchResults &out)
{
    if (value.isArray()) {
        for (const QJsonValue &entry : value.toArray()) walkResults(entry, out);
    } else if (value.isObject()) {
        const QJsonObject object = value.toObject();
        if (object.contains("musicResponsiveListItemRenderer")) {
            parseListItem(object.value("musicResponsiveListItemRenderer").toObject(), out);
            return;
        }
        if (object.contains("musicTwoRowItemRenderer")) {
            parseTwoRowItem(object.value("musicTwoRowItemRenderer").toObject(), out);
            return;
        }
        for (auto it = object.constBegin(); it != object.constEnd(); ++it) walkResults(it.value(), out);
    }
}

SearchResults parseResults(const QJsonObject &root)
{
    SearchResults result;
    walkResults(root, result);
    QSet<QString> seenTracks, seenCollections;
    QVector<Track> tracks;
    for (const Track &track : std::as_const(result.tracks)) {
        if (!seenTracks.contains(track.videoId)) {
            seenTracks.insert(track.videoId);
            tracks << track;
        }
    }
    QVector<Collection> collections;
    for (const Collection &collection : std::as_const(result.collections)) {
        if (!seenCollections.contains(collection.browseId)) {
            seenCollections.insert(collection.browseId);
            collections << collection;
        }
    }
    return {tracks, collections};
}

void walkPlaylistRows(const QJsonValue &value, SearchResults &out)
{
    if (value.isArray()) {
        for (const QJsonValue &entry : value.toArray()) walkPlaylistRows(entry, out);
    } else if (value.isObject()) {
        const QJsonObject object = value.toObject();
        if (object.contains("musicResponsiveListItemRenderer")) {
            parseListItem(object.value("musicResponsiveListItemRenderer").toObject(), out);
            return;
        }
        for (auto it = object.constBegin(); it != object.constEnd(); ++it) walkPlaylistRows(it.value(), out);
    }
}

RemotePlaylist parseRemotePlaylist(const QJsonObject &root, const QString &playlistId)
{
    RemotePlaylist playlist;
    playlist.id = playlistId.startsWith("VL") ? playlistId.mid(2) : playlistId;

    const QJsonObject editableHeader = firstObjectWithKey(root, "musicEditablePlaylistDetailHeaderRenderer");
    QJsonObject responsiveHeader = firstObjectWithKey(editableHeader, "musicResponsiveHeaderRenderer");
    if (responsiveHeader.isEmpty()) responsiveHeader = firstObjectWithKey(root, "musicResponsiveHeaderRenderer");
    playlist.name = textFromRuns(responsiveHeader.value("title").toObject().value("runs").toArray());
    playlist.description = textFromRuns(dig(responsiveHeader, "description", "musicDescriptionShelfRenderer", "description", "runs").toArray());
    if (playlist.description.isEmpty())
        playlist.description = textFromRuns(dig(responsiveHeader, "description", "runs").toArray());
    playlist.owned = !editableHeader.isEmpty();
    const QString headerCover = bestThumb(dig(responsiveHeader, "thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails").toArray());
    if (!headerCover.isEmpty()) playlist.covers << headerCover;

    const QJsonObject shelf = firstObjectWithKey(root, "musicPlaylistShelfRenderer");
    SearchResults rows;
    if (!shelf.isEmpty()) walkPlaylistRows(shelf.value("contents"), rows);
    else walkPlaylistRows(root, rows);
    playlist.tracks = rows.tracks; // Do not de-duplicate: duplicate videos are valid playlist rows.
    playlist.trackCount = playlist.tracks.size();
    QSet<QString> seenCover;
    for (const Track &track : std::as_const(playlist.tracks)) {
        playlist.durationMs += track.durationMs;
        if (!track.artworkUrl.isEmpty() && !seenCover.contains(track.artworkUrl) && playlist.covers.size() < 4) {
            seenCover.insert(track.artworkUrl);
            playlist.covers << track.artworkUrl;
        }
    }
    return playlist;
}

QString browseIdFromItem(const QJsonObject &item)
{
    QString id = dig(item, "navigationEndpoint", "browseEndpoint", "browseId").toString();
    if (!id.isEmpty()) return id;

    const QJsonArray titleRuns = item.value("title").toObject().value("runs").toArray();
    for (const QJsonValue &run : titleRuns) {
        id = dig(run, "navigationEndpoint", "browseEndpoint", "browseId").toString();
        if (!id.isEmpty()) return id;
    }
    // Library responses vary between two-row and responsive-list renderers. In
    // the latter the playlist browse endpoint can be attached to the first flex
    // column rather than the renderer itself.
    for (const QJsonValue &column : item.value("flexColumns").toArray()) {
        const QJsonArray runs = dig(column, "musicResponsiveListItemFlexColumnRenderer", "text", "runs").toArray();
        for (const QJsonValue &run : runs) {
            id = dig(run, "navigationEndpoint", "browseEndpoint", "browseId").toString();
            if (!id.isEmpty()) return id;
        }
    }
    return {};
}

RemotePlaylist playlistSummaryFromRenderer(const QJsonObject &object)
{
    RemotePlaylist playlist;
    const bool responsive = object.contains("musicResponsiveListItemRenderer");
    const QJsonObject item = responsive ? object.value("musicResponsiveListItemRenderer").toObject()
                                        : object.value("musicTwoRowItemRenderer").toObject();
    if (item.isEmpty()) return playlist;

    QString rawBrowseId = browseIdFromItem(item);
    if (rawBrowseId.startsWith("VL")) rawBrowseId = rawBrowseId.mid(2);
    if (rawBrowseId.isEmpty() || rawBrowseId.startsWith("FEmusic")) return playlist;
    playlist.id = rawBrowseId;
    if (responsive) {
        const QJsonArray flex = item.value("flexColumns").toArray();
        if (!flex.isEmpty())
            playlist.name = textFromRuns(dig(QJsonValue(flex.first()), "musicResponsiveListItemFlexColumnRenderer", "text", "runs").toArray());
        if (flex.size() > 1)
            playlist.description = splitRuns(dig(QJsonValue(flex[1]), "musicResponsiveListItemFlexColumnRenderer", "text", "runs").toArray()).join(" • ");
        const QString cover = bestThumb(dig(item, "thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails").toArray());
        if (!cover.isEmpty()) playlist.covers << cover;
    } else {
        playlist.name = textFromRuns(item.value("title").toObject().value("runs").toArray());
        playlist.description = splitRuns(item.value("subtitle").toObject().value("runs").toArray()).join(" • ");
        const QString cover = bestThumb(dig(item, "thumbnailRenderer", "musicThumbnailRenderer", "thumbnail", "thumbnails").toArray());
        if (!cover.isEmpty()) playlist.covers << cover;
    }
    static const QRegularExpression countRe("(?:^|\\D)(\\d[\\d,]*)\\s+(?:songs?|tracks?)", QRegularExpression::CaseInsensitiveOption);
    const QRegularExpressionMatch match = countRe.match(playlist.description);
    if (match.hasMatch()) playlist.trackCount = match.captured(1).remove(',').toInt();
    playlist.owned = !firstObjectWithKey(item, "playlistEditorEndpoint").isEmpty();
    return playlist;
}

QVector<RemotePlaylist> parseLibraryPlaylists(const QJsonObject &root)
{
    QVector<RemotePlaylist> playlists;
    QSet<QString> seen;
    std::function<void(const QJsonValue &)> walk = [&](const QJsonValue &value) {
        if (value.isArray()) {
            for (const QJsonValue &entry : value.toArray()) walk(entry);
            return;
        }
        if (!value.isObject()) return;
        const QJsonObject object = value.toObject();
        if (object.contains("musicResponsiveListItemRenderer") || object.contains("musicTwoRowItemRenderer")) {
            const RemotePlaylist playlist = playlistSummaryFromRenderer(object);
            if (!playlist.id.isEmpty() && !playlist.name.isEmpty() && !seen.contains(playlist.id)) {
                seen.insert(playlist.id);
                playlists << playlist;
            }
            return;
        }
        for (auto it = object.constBegin(); it != object.constEnd(); ++it) walk(it.value());
    };
    walk(root);
    return playlists;
}

QString nextContinuationToken(const QJsonValue &value)
{
    if (value.isArray()) {
        for (const QJsonValue &entry : value.toArray()) {
            const QString token = nextContinuationToken(entry);
            if (!token.isEmpty()) return token;
        }
        return {};
    }
    if (!value.isObject()) return {};

    const QJsonObject object = value.toObject();
    for (const QJsonValue &continuation : object.value("continuations").toArray()) {
        const QString token = dig(continuation, "nextContinuationData", "continuation").toString();
        if (!token.isEmpty()) return token;
    }
    const QString itemToken = dig(object, "continuationItemRenderer", "continuationEndpoint",
                                  "continuationCommand", "token").toString();
    if (!itemToken.isEmpty()) return itemToken;
    for (auto it = object.constBegin(); it != object.constEnd(); ++it) {
        const QString token = nextContinuationToken(it.value());
        if (!token.isEmpty()) return token;
    }
    return {};
}

void appendUniquePlaylists(QVector<RemotePlaylist> &destination, const QVector<RemotePlaylist> &page)
{
    QSet<QString> known;
    for (const RemotePlaylist &playlist : std::as_const(destination)) known.insert(playlist.id);
    for (const RemotePlaylist &playlist : page) {
        if (!playlist.id.isEmpty() && !known.contains(playlist.id)) {
            known.insert(playlist.id);
            destination << playlist;
        }
    }
}

bool mutationSucceeded(const QJsonObject &root)
{
    const QString status = root.value("status").toString();
    return status.contains("SUCCEEDED") || !root.value("playlistId").toString().isEmpty();
}
}

YouTubeMusicClient::YouTubeMusicClient(QNetworkAccessManager *nam, SettingsService *settings,
                                       AccountService *account, QObject *parent)
    : MusicProvider(parent), m_http(nam, this), m_settings(settings), m_account(account)
{
}

QUrl YouTubeMusicClient::endpoint(const QString &name) const
{
    QUrl url(QStringLiteral("https://music.youtube.com/youtubei/v1/%1").arg(name));
    QUrlQuery query;
    query.addQueryItem("alt", "json");
    query.addQueryItem("key", kWebRemixApiKey);
    url.setQuery(query);
    return url;
}

QJsonObject YouTubeMusicClient::context() const
{
    const QString version = "1." + QDate::currentDate().toString("yyyyMMdd") + ".01.00";
    return {{"client", QJsonObject{{"clientName", "WEB_REMIX"},
                                    {"clientVersion", version},
                                    {"hl", m_settings->get("language").toString()}}},
            {"user", QJsonObject{}}};
}

ApiRequest::Headers YouTubeMusicClient::headers() const
{
    ApiRequest::Headers headers = {
        {"Origin", kOrigin},
        {"X-Origin", kOrigin},
        {"User-Agent", "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"},
        {"Accept", "*/*"},
        {"Accept-Language", m_settings->get("language").toString().toUtf8()},
    };
    const QString cookie = m_account ? m_account->sessionCookie().trimmed() : QString{};
    if (cookie.isEmpty()) return headers;

    headers.append({"Cookie", cookie.toUtf8()});
    headers.append({"X-Goog-AuthUser", (m_account ? m_account->authUser() : QStringLiteral("0")).toUtf8()});
    QString sapisid;
    for (const QString &part : cookie.split(';')) {
        const QString value = part.trimmed();
        if (value.startsWith("SAPISID=")) sapisid = value.mid(8);
        else if (sapisid.isEmpty() && value.startsWith("__Secure-3PAPISID=")) sapisid = value.mid(18);
    }
    if (!sapisid.isEmpty()) {
        const qint64 timestamp = QDateTime::currentSecsSinceEpoch();
        const QByteArray digest = QCryptographicHash::hash(
            QByteArray::number(timestamp) + ' ' + sapisid.toUtf8() + ' ' + kOrigin,
            QCryptographicHash::Sha1).toHex();
        headers.append({"Authorization", "SAPISIDHASH " + QByteArray::number(timestamp) + '_' + digest});
    }
    return headers;
}

bool YouTubeMusicClient::hasAuthenticatedSession() const
{
    return m_account && !m_account->sessionCookie().trimmed().isEmpty();
}

void YouTubeMusicClient::failUnauthenticated(quint64 token) const
{
    auto *self = const_cast<YouTubeMusicClient *>(this);
    QTimer::singleShot(0, self, [self, token] {
        emit self->failed(token, {ApiError::AuthRequired, "No connected YouTube Music session", 0});
    });
}

quint64 YouTubeMusicClient::search(const QString &query, SearchFilter filter)
{
    const quint64 token = newToken();
    QJsonObject body{{"context", context()}, {"query", query}};
    if (const QString params = filterParams(filter); !params.isEmpty()) body["params"] = params;
    m_http.post(endpoint("search"), body, headers(), [this, token](QJsonObject root, ApiError error) {
        if (error) return emit failed(token, error);
        const SearchResults results = parseResults(root);
        if (results.tracks.isEmpty() && results.collections.isEmpty() && !root.contains("contents"))
            return emit failed(token, {ApiError::InvalidResponse, "Unexpected search response", 0});
        emit searchFinished(token, results);
    });
    return token;
}

quint64 YouTubeMusicClient::loadCollection(const Collection &collection)
{
    const quint64 token = newToken();
    const QJsonObject body{{"context", context()}, {"browseId", collection.browseId}};
    m_http.post(endpoint("browse"), body, headers(), [this, token, collection](QJsonObject root, ApiError error) {
        if (error) return emit failed(token, error);
        SearchResults results = parseResults(root);
        for (Track &track : results.tracks) {
            if (track.artworkUrl.isEmpty()) track.artworkUrl = collection.artworkUrl;
            if (track.album.isEmpty() && collection.kind == CollectionKind::Album) track.album = collection.title;
        }
        emit collectionLoaded(token, results);
    });
    return token;
}

quint64 YouTubeMusicClient::resolveStream(const QString &videoId)
{
    const quint64 token = newToken();
    const QJsonObject body{{"context", context()}, {"videoId", videoId},
                           {"contentCheckOk", true}, {"racyCheckOk", true}};
    m_http.post(endpoint("player"), body, headers(), [this, token, videoId](QJsonObject root, ApiError error) {
        const bool hasResolver = !m_settings->get("resolverCommand").toString().trimmed().isEmpty();
        if (error) {
            if (hasResolver && error.kind != ApiError::Network) return resolveExternally(token, videoId);
            return emit failed(token, error);
        }
        const QString status = dig(root, "playabilityStatus", "status").toString();
        if (status != "OK") {
            if (hasResolver) return resolveExternally(token, videoId);
            if (status == "LOGIN_REQUIRED") return emit failed(token, {ApiError::AuthRequired, {}, 0});
            const QString reason = dig(root, "playabilityStatus", "reason").toString();
            return emit failed(token, {ApiError::Unavailable, reason.isEmpty() ? "This track isn't available." : reason, 0});
        }
        QUrl best;
        int bestRate = -1;
        for (const QJsonValue &format : dig(root, "streamingData", "adaptiveFormats").toArray()) {
            const QJsonObject candidate = format.toObject();
            if (!candidate.value("mimeType").toString().startsWith("audio/") || !candidate.contains("url")) continue;
            const int bitrate = candidate.value("bitrate").toInt();
            if (bitrate > bestRate) { bestRate = bitrate; best = QUrl(candidate.value("url").toString()); }
        }
        if (best.isValid()) return emit streamResolved(token, videoId, best);
        resolveExternally(token, videoId);
    });
    return token;
}

quint64 YouTubeMusicClient::fetchAccountInfo()
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    m_http.post(endpoint("account/account_menu"), QJsonObject{{"context", context()}}, headers(),
                [this, token](QJsonObject root, ApiError error) {
        if (error) return emit failed(token, error);
        const QJsonArray actions = dig(root, "actions").toArray();
        const QJsonObject firstAction = actions.isEmpty() ? QJsonObject{} : actions.at(0).toObject();
        const QJsonObject header = firstAction.value("openPopupAction").toObject().value("popup").toObject()
                                     .value("multiPageMenuRenderer").toObject().value("header").toObject()
                                     .value("activeAccountHeaderRenderer").toObject();
        const QString name = textFromRuns(header.value("accountName").toObject().value("runs").toArray());
        if (name.isEmpty()) return emit failed(token, {ApiError::AuthRequired, "No active account", 0});
        const QString handle = textFromRuns(header.value("channelHandle").toObject().value("runs").toArray());
        const QString photo = bestThumb(header.value("accountPhoto").toObject().value("thumbnails").toArray());
        emit accountInfoLoaded(token, {name, handle, photo});
    });
    return token;
}

quint64 YouTubeMusicClient::loadLibraryPlaylists()
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    loadLibraryPage(token, {}, {}, 0);
    return token;
}

void YouTubeMusicClient::loadLibraryPage(quint64 token, QVector<RemotePlaylist> collected,
                                         const QString &continuation, int page)
{
    QUrl url = endpoint("browse");
    if (!continuation.isEmpty()) {
        QUrlQuery query(url);
        // InnerTube expects the continuation in both parameters; this matches
        // the web client and ytmusicapi's get_continuation_string helper.
        query.addQueryItem("ctoken", continuation);
        query.addQueryItem("continuation", continuation);
        url.setQuery(query);
    }
    const QJsonObject body{{"context", context()}, {"browseId", "FEmusic_liked_playlists"}};
    m_http.post(url, body, headers(), [this, token, collected = std::move(collected), page](QJsonObject root, ApiError error) mutable {
        if (error) return emit failed(token, error);
        appendUniquePlaylists(collected, parseLibraryPlaylists(root));
        const QString next = nextContinuationToken(root);
        // A bounded chain prevents a malformed recursive continuation response
        // from keeping the UI in a permanent loading state.
        if (!next.isEmpty() && page < 100) {
            loadLibraryPage(token, std::move(collected), next, page + 1);
            return;
        }
        emit libraryPlaylistsLoaded(token, collected);
    });
}

quint64 YouTubeMusicClient::loadPlaylist(const QString &playlistId)
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    const QString id = playlistId.startsWith("VL") ? playlistId.mid(2) : playlistId;
    const QJsonObject body{{"context", context()}, {"browseId", "VL" + id}};
    m_http.post(endpoint("browse"), body, headers(), [this, token, id](QJsonObject root, ApiError error) {
        if (error) return emit failed(token, error);
        RemotePlaylist playlist = parseRemotePlaylist(root, id);
        if (playlist.name.isEmpty() && !root.contains("contents"))
            return emit failed(token, {ApiError::InvalidResponse, "Unexpected playlist response", 0});
        emit remotePlaylistLoaded(token, playlist);
    });
    return token;
}

void YouTubeMusicClient::postMutation(quint64 token, const QString &playlistId, const QJsonObject &body,
                                      const QString &createdPlaylistIdField)
{
    m_http.post(endpoint("browse/edit_playlist"), body, headers(),
                [this, token, playlistId, createdPlaylistIdField](QJsonObject root, ApiError error) {
        if (error) return emit failed(token, error);
        const QString created = createdPlaylistIdField.isEmpty() ? QString{}
                                : root.value(createdPlaylistIdField).toString();
        if (!mutationSucceeded(root))
            return emit failed(token, {ApiError::Unknown, "YouTube Music did not confirm this playlist change.", 0});
        emit playlistMutationFinished(token, playlistId, created);
    }, ApiRequest::DoNotRetry);
}

quint64 YouTubeMusicClient::createPlaylist(const QString &name, const QString &description,
                                           const QVector<Track> &initialTracks)
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    QJsonArray videoIds;
    QSet<QString> seen;
    for (const Track &track : initialTracks) {
        if (track.isValid() && !seen.contains(track.videoId)) { seen.insert(track.videoId); videoIds << track.videoId; }
    }
    QJsonObject body{{"context", context()}, {"title", name}, {"description", description},
                     {"privacyStatus", "PRIVATE"}};
    if (!videoIds.isEmpty()) body["videoIds"] = videoIds;
    // The create endpoint has a different path but shares the same one-shot policy.
    m_http.post(endpoint("playlist/create"), body, headers(), [this, token](QJsonObject root, ApiError error) {
        if (error) return emit failed(token, error);
        const QString id = root.value("playlistId").toString();
        if (id.isEmpty()) return emit failed(token, {ApiError::Unknown, "YouTube Music did not return the new playlist ID.", 0});
        emit playlistMutationFinished(token, id, id);
    }, ApiRequest::DoNotRetry);
    return token;
}

quint64 YouTubeMusicClient::updatePlaylist(const QString &playlistId, const QString &name, const QString &description)
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    const QString id = playlistId.startsWith("VL") ? playlistId.mid(2) : playlistId;
    const QJsonArray actions = {
        QJsonObject{{"action", "ACTION_SET_PLAYLIST_NAME"}, {"playlistName", name}},
        QJsonObject{{"action", "ACTION_SET_PLAYLIST_DESCRIPTION"}, {"playlistDescription", description}}
    };
    postMutation(token, id, QJsonObject{{"context", context()}, {"playlistId", id}, {"actions", actions}});
    return token;
}

quint64 YouTubeMusicClient::deletePlaylist(const QString &playlistId)
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    const QString id = playlistId.startsWith("VL") ? playlistId.mid(2) : playlistId;
    m_http.post(endpoint("playlist/delete"), QJsonObject{{"context", context()}, {"playlistId", id}}, headers(),
                [this, token, id](QJsonObject root, ApiError error) {
        if (error) return emit failed(token, error);
        if (!mutationSucceeded(root))
            return emit failed(token, {ApiError::Unknown, "YouTube Music did not confirm deletion.", 0});
        emit playlistMutationFinished(token, id, {});
    }, ApiRequest::DoNotRetry);
    return token;
}

quint64 YouTubeMusicClient::addPlaylistItems(const QString &playlistId, const QVector<Track> &tracks)
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    const QString id = playlistId.startsWith("VL") ? playlistId.mid(2) : playlistId;
    QJsonArray actions;
    QSet<QString> seen;
    for (const Track &track : tracks) {
        if (track.isValid() && !seen.contains(track.videoId)) {
            seen.insert(track.videoId);
            actions << QJsonObject{{"action", "ACTION_ADD_VIDEO"}, {"addedVideoId", track.videoId}};
        }
    }
    if (actions.isEmpty()) {
        QTimer::singleShot(0, this, [this, token] { emit failed(token, {ApiError::InvalidResponse, "No valid songs to add.", 0}); });
        return token;
    }
    postMutation(token, id, QJsonObject{{"context", context()}, {"playlistId", id}, {"actions", actions}});
    return token;
}

quint64 YouTubeMusicClient::removePlaylistItems(const QString &playlistId, const QVector<Track> &tracks)
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    const QString id = playlistId.startsWith("VL") ? playlistId.mid(2) : playlistId;
    QJsonArray actions;
    for (const Track &track : tracks) {
        if (!track.videoId.isEmpty() && !track.setVideoId.isEmpty()) {
            actions << QJsonObject{{"action", "ACTION_REMOVE_VIDEO"}, {"removedVideoId", track.videoId},
                                   {"setVideoId", track.setVideoId}};
        }
    }
    if (actions.isEmpty()) {
        QTimer::singleShot(0, this, [this, token] {
            emit failed(token, {ApiError::InvalidResponse, "Refresh the playlist before removing this song.", 0});
        });
        return token;
    }
    postMutation(token, id, QJsonObject{{"context", context()}, {"playlistId", id}, {"actions", actions}});
    return token;
}

quint64 YouTubeMusicClient::reorderPlaylist(const QString &playlistId, const QVector<Track> &orderedTracks)
{
    const quint64 token = newToken();
    if (!hasAuthenticatedSession()) { failUnauthenticated(token); return token; }
    const QString id = playlistId.startsWith("VL") ? playlistId.mid(2) : playlistId;
    if (orderedTracks.size() < 2) {
        QTimer::singleShot(0, this, [this, token, id] { emit playlistMutationFinished(token, id, {}); });
        return token;
    }
    QJsonArray actions;
    // Building moves from the tail makes every earlier item point to a stable
    // successor, including moves to the final position (where no successor is sent).
    for (int index = orderedTracks.size() - 1; index >= 0; --index) {
        const Track &track = orderedTracks[index];
        if (track.setVideoId.isEmpty()) {
            QTimer::singleShot(0, this, [this, token] {
                emit failed(token, {ApiError::InvalidResponse, "Refresh the playlist before changing its order.", 0});
            });
            return token;
        }
        QJsonObject action{{"action", "ACTION_MOVE_VIDEO_BEFORE"}, {"setVideoId", track.setVideoId}};
        if (index + 1 < orderedTracks.size()) {
            const QString successor = orderedTracks[index + 1].setVideoId;
            if (successor.isEmpty()) {
                QTimer::singleShot(0, this, [this, token] {
                    emit failed(token, {ApiError::InvalidResponse, "Refresh the playlist before changing its order.", 0});
                });
                return token;
            }
            action["movedSetVideoIdSuccessor"] = successor;
        }
        actions << action;
    }
    postMutation(token, id, QJsonObject{{"context", context()}, {"playlistId", id}, {"actions", actions}});
    return token;
}

void YouTubeMusicClient::resolveExternally(quint64 token, const QString &videoId)
{
    QStringList arguments = QProcess::splitCommand(m_settings->get("resolverCommand").toString().trimmed());
    if (arguments.isEmpty()) {
        emit failed(token, {ApiError::Unavailable, "Playback needs a stream resolver. Set one in Settings > Network.", 0});
        return;
    }
    const QString program = arguments.takeFirst();
    arguments << "-f" << "bestaudio" << "-g" << "--no-playlist"
              << QStringLiteral("https://music.youtube.com/watch?v=%1").arg(videoId);
    auto *process = new QProcess(this);
    auto *timeout = new QTimer(process);
    timeout->setSingleShot(true);
    connect(timeout, &QTimer::timeout, process, [process] { process->kill(); });
    connect(process, &QProcess::errorOccurred, this, [=, this](QProcess::ProcessError error) {
        if (error != QProcess::FailedToStart) return;
        emit failed(token, {ApiError::Unavailable,
                            QStringLiteral("Couldn't start \"%1\". Check the resolver command in Settings > Network.").arg(program), 0});
        process->deleteLater();
    });
    connect(process, &QProcess::finished, this, [=, this](int code, QProcess::ExitStatus) {
        const QByteArray output = process->readAllStandardOutput().trimmed();
        const QUrl url(QString::fromUtf8(output.split('\n').value(0)));
        if (code == 0 && url.isValid() && url.scheme().startsWith("http")) emit streamResolved(token, videoId, url);
        else emit failed(token, {ApiError::Unavailable, "The stream resolver couldn't find audio for this track.", 0});
        process->deleteLater();
    });
    process->start(program, arguments);
    timeout->start(25000);
}
