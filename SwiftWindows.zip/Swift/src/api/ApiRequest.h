#pragma once
#include "Types.h"
#include <QList>
#include <QNetworkAccessManager>
#include <QObject>
#include <QPair>
#include <functional>

// Asynchronous JSON POST with timeout and mapped failures. Only read operations
// may retry automatically: retrying a mutation after a lost response could add a
// song twice or apply a move twice on the real YouTube Music account.
class ApiRequest : public QObject
{
    Q_OBJECT
public:
    using Headers = QList<QPair<QByteArray, QByteArray>>;
    using Callback = std::function<void(QJsonObject, hm::ApiError)>;
    enum RetryPolicy { SafeToRetry, DoNotRetry };

    explicit ApiRequest(QNetworkAccessManager *nam, QObject *parent = nullptr);

    void post(const QUrl &url, const QJsonObject &body, const Headers &headers,
              Callback callback, RetryPolicy retryPolicy = SafeToRetry, int attempt = 0);

private:
    QNetworkAccessManager *m_nam;
};
