#pragma once
#include "ApiRequest.h"
#include "MusicProvider.h"

class SettingsService;
class AccountService;

// Provider backed by the undocumented InnerTube endpoints used by music.youtube.com.
// Authentication is supplied by AccountService; all playlist writes are one-shot and
// are verified by a follow-up read in PlaylistService.
class YouTubeMusicClient : public MusicProvider
{
    Q_OBJECT
public:
    YouTubeMusicClient(QNetworkAccessManager *nam, SettingsService *settings,
                       AccountService *account, QObject *parent = nullptr);

    quint64 search(const QString &query, hm::SearchFilter filter) override;
    quint64 loadCollection(const hm::Collection &collection) override;
    quint64 resolveStream(const QString &videoId) override;
    quint64 fetchAccountInfo() override;
    quint64 loadLibraryPlaylists() override;
    quint64 loadPlaylist(const QString &playlistId) override;
    quint64 createPlaylist(const QString &name, const QString &description,
                           const QVector<hm::Track> &initialTracks) override;
    quint64 updatePlaylist(const QString &playlistId, const QString &name,
                           const QString &description) override;
    quint64 deletePlaylist(const QString &playlistId) override;
    quint64 addPlaylistItems(const QString &playlistId, const QVector<hm::Track> &tracks) override;
    quint64 removePlaylistItems(const QString &playlistId, const QVector<hm::Track> &tracks) override;
    quint64 reorderPlaylist(const QString &playlistId, const QVector<hm::Track> &orderedTracks) override;

private:
    QJsonObject context() const;
    ApiRequest::Headers headers() const;
    QUrl endpoint(const QString &name) const;
    bool hasAuthenticatedSession() const;
    void failUnauthenticated(quint64 token) const;
    void loadLibraryPage(quint64 token, QVector<hm::RemotePlaylist> collected,
                         const QString &continuation = {}, int page = 0);
    void postMutation(quint64 token, const QString &playlistId, const QJsonObject &body,
                      const QString &createdPlaylistIdField = {});
    void resolveExternally(quint64 token, const QString &videoId);

    ApiRequest m_http;
    SettingsService *m_settings;
    AccountService *m_account;
};
