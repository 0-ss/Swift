#include "AppController.h"
#include "api/YouTubeMusicClient.h"
#include "playback/MusicPlayer.h"
#include "services/AccountService.h"
#include "services/CacheService.h"
#include "services/LibraryService.h"
#include "services/LyricsService.h"
#include "services/PlaylistService.h"
#include "services/SettingsService.h"
#include "services/SystemTrayService.h"
#include <QApplication>
#include <QIcon>
#include <QNetworkAccessManager>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QQuickWindow>
#include <QSGRendererInterface>

int main(int argc, char *argv[])
{
    // Force the Vulkan backend for Qt Quick. Must run before the first QQuickWindow is created.
    QQuickWindow::setGraphicsApi(QSGRendererInterface::Vulkan);

    QApplication app(argc, argv);
    QGuiApplication::setOrganizationName("Swift");
    QGuiApplication::setApplicationName("Swift");
    QGuiApplication::setApplicationVersion("0.1.0");
    QQuickStyle::setStyle("Basic"); // every control is custom drawn; Basic avoids native-style overrides

    SettingsService settings;
    AccountService account(&settings);
    CacheService cache(&settings);
    LibraryService library;
    SystemTrayService systemTray;
    systemTray.setEnabled(settings.get("systemTray").toBool());
    QObject::connect(&settings, &SettingsService::changed, &systemTray,
                     [&systemTray](const QString &key, const QVariant &value) {
        if (key == "systemTray") systemTray.setEnabled(value.toBool());
    });
    app.setWindowIcon(QIcon(":/qt/qml/Swift/qml/assets/image.png"));

    QNetworkAccessManager apiNetwork;
    YouTubeMusicClient provider(&apiNetwork, &settings, &account);
    account.setProvider(&provider);
    PlaylistService playlists(&provider, &account);

    MusicPlayer player(&provider, &settings);
    AppController controller(&provider, &settings);
    LyricsService lyrics(&player, &settings);

    QObject::connect(&player, &MusicPlayer::trackStarted, &library, &LibraryService::addRecent);
    QObject::connect(&app, &QGuiApplication::aboutToQuit, &player, &MusicPlayer::saveState);

    QQmlApplicationEngine engine; // declared last so it is destroyed first
    engine.setNetworkAccessManagerFactory(&cache);
    QQmlContext *ctx = engine.rootContext();
    ctx->setContextProperty("app", &controller);
    ctx->setContextProperty("player", &player);
    ctx->setContextProperty("library", &library);
    ctx->setContextProperty("lyrics", &lyrics);
    ctx->setContextProperty("playlists", &playlists);
    ctx->setContextProperty("settings", &settings);
    ctx->setContextProperty("account", &account);
    ctx->setContextProperty("cache", &cache);
    ctx->setContextProperty("systemTray", &systemTray);

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app,
                     [] { QCoreApplication::exit(-1); }, Qt::QueuedConnection);
    engine.loadFromModule("Swift", "Main");
    return app.exec();
}
