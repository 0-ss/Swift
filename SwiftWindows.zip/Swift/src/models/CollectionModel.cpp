#include "CollectionModel.h"

CollectionModel::CollectionModel(QObject *parent) : QAbstractListModel(parent) {}

int CollectionModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : count();
}

QVariant CollectionModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= count()) return {};
    const hm::Collection &c = m_items[index.row()];
    switch (role) {
    case BrowseIdRole: return c.browseId;
    case TitleRole: return c.title;
    case SubtitleRole: return c.subtitle;
    case ArtworkRole: return c.artworkUrl;
    case KindRole: return hm::toString(c.kind);
    default: return {};
    }
}

QHash<int, QByteArray> CollectionModel::roleNames() const
{
    return {{BrowseIdRole, "browseId"}, {TitleRole, "title"}, {SubtitleRole, "subtitle"},
            {ArtworkRole, "artworkUrl"}, {KindRole, "kind"}};
}

void CollectionModel::setItems(QVector<hm::Collection> items)
{
    beginResetModel();
    m_items = std::move(items);
    endResetModel();
    emit countChanged();
}

QVariantMap CollectionModel::get(int row) const
{
    return (row >= 0 && row < count()) ? hm::toVariant(m_items[row]) : QVariantMap{};
}
