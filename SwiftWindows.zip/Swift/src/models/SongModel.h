#pragma once
#include "api/Types.h"
#include <QAbstractListModel>

class SongModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(int count READ count NOTIFY countChanged)
public:
    enum Role { VideoIdRole = Qt::UserRole + 1, TitleRole, ArtistRole, AlbumRole, ArtworkRole, DurationRole };

    explicit SongModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    int count() const { return int(m_tracks.size()); }
    const QVector<hm::Track> &tracks() const { return m_tracks; }
    hm::Track trackAt(int row) const;

    void setTracks(QVector<hm::Track> tracks);
    void insertTrack(int row, const hm::Track &t);
    void appendTrack(const hm::Track &t) { insertTrack(count(), t); }
    void removeTrackAt(int row);
    bool moveTrack(int from, int to);
    void clear();

    Q_INVOKABLE QVariantMap get(int row) const;

signals:
    void countChanged();

protected:
    QVector<hm::Track> m_tracks;
};
