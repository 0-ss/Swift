#pragma once
#include "api/Types.h"
#include <QAbstractListModel>

// Albums, artists and playlists.
class CollectionModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(int count READ count NOTIFY countChanged)
public:
    enum Role { BrowseIdRole = Qt::UserRole + 1, TitleRole, SubtitleRole, ArtworkRole, KindRole };

    explicit CollectionModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    int count() const { return int(m_items.size()); }
    void setItems(QVector<hm::Collection> items);
    Q_INVOKABLE QVariantMap get(int row) const;

signals:
    void countChanged();

private:
    QVector<hm::Collection> m_items;
};
