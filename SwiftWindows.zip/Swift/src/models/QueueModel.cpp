#include "QueueModel.h"

QVariant QueueModel::data(const QModelIndex &index, int role) const
{
    if (role == IsCurrentRole) return index.isValid() && index.row() == m_current;
    return SongModel::data(index, role);
}

QHash<int, QByteArray> QueueModel::roleNames() const
{
    auto r = SongModel::roleNames();
    r.insert(IsCurrentRole, "isCurrent");
    return r;
}

void QueueModel::setCurrentIndex(int row)
{
    if (row == m_current) return;
    const int old = m_current;
    m_current = row;
    if (old >= 0 && old < count()) emit dataChanged(index(old), index(old), {IsCurrentRole});
    if (row >= 0 && row < count()) emit dataChanged(index(row), index(row), {IsCurrentRole});
    emit currentIndexChanged();
}

bool QueueModel::removeTracked(int row)
{
    if (row < 0 || row >= count()) return false;
    const bool wasCurrent = row == m_current;
    removeTrackAt(row);
    if (row < m_current) {
        --m_current;
        emit currentIndexChanged();
    } else if (wasCurrent) {
        if (m_current >= count()) m_current = count() - 1;
        emit currentIndexChanged();
    }
    return wasCurrent;
}

bool QueueModel::moveTracked(int from, int to)
{
    if (!moveTrack(from, to)) return false;
    int cur = m_current;
    if (from == cur) cur = to;
    else if (from < cur && to >= cur) --cur;
    else if (from > cur && to <= cur) ++cur;
    if (cur != m_current) {
        m_current = cur;
        emit currentIndexChanged();
    }
    return true;
}

void QueueModel::reset(QVector<hm::Track> tracks)
{
    setTracks(std::move(tracks));
    if (m_current != -1) {
        m_current = -1;
        emit currentIndexChanged();
    }
}
