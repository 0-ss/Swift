#include "SongModel.h"

SongModel::SongModel(QObject *parent) : QAbstractListModel(parent) {}

int SongModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : count();
}

QVariant SongModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= count()) return {};
    const hm::Track &t = m_tracks[index.row()];
    switch (role) {
    case VideoIdRole: return t.videoId;
    case TitleRole: return t.title;
    case ArtistRole: return t.artist;
    case AlbumRole: return t.album;
    case ArtworkRole: return t.artworkUrl;
    case DurationRole: return t.durationMs;
    default: return {};
    }
}

QHash<int, QByteArray> SongModel::roleNames() const
{
    return {{VideoIdRole, "videoId"}, {TitleRole, "title"}, {ArtistRole, "artist"},
            {AlbumRole, "album"}, {ArtworkRole, "artworkUrl"}, {DurationRole, "durationMs"}};
}

hm::Track SongModel::trackAt(int row) const
{
    return (row >= 0 && row < count()) ? m_tracks[row] : hm::Track{};
}

void SongModel::setTracks(QVector<hm::Track> tracks)
{
    beginResetModel();
    m_tracks = std::move(tracks);
    endResetModel();
    emit countChanged();
}

void SongModel::insertTrack(int row, const hm::Track &t)
{
    row = qBound(0, row, count());
    beginInsertRows({}, row, row);
    m_tracks.insert(row, t);
    endInsertRows();
    emit countChanged();
}

void SongModel::removeTrackAt(int row)
{
    if (row < 0 || row >= count()) return;
    beginRemoveRows({}, row, row);
    m_tracks.removeAt(row);
    endRemoveRows();
    emit countChanged();
}

bool SongModel::moveTrack(int from, int to)
{
    if (from == to || from < 0 || to < 0 || from >= count() || to >= count()) return false;
    const int dest = to > from ? to + 1 : to;
    if (!beginMoveRows({}, from, from, {}, dest)) return false;
    m_tracks.move(from, to);
    endMoveRows();
    return true;
}

void SongModel::clear()
{
    setTracks({});
}

QVariantMap SongModel::get(int row) const
{
    return hm::toVariant(trackAt(row));
}
