#pragma once
#include "SongModel.h"

// Song list that also knows which row is playing.
class QueueModel : public SongModel
{
    Q_OBJECT
    Q_PROPERTY(int currentIndex READ currentIndex NOTIFY currentIndexChanged)
public:
    enum { IsCurrentRole = Qt::UserRole + 100 };

    using SongModel::SongModel;

    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    int currentIndex() const { return m_current; }
    void setCurrentIndex(int row);
    hm::Track currentTrack() const { return trackAt(m_current); }

    // Keep currentIndex consistent while editing. Returns true if the playing row was removed.
    bool removeTracked(int row);
    bool moveTracked(int from, int to);
    void reset(QVector<hm::Track> tracks);

signals:
    void currentIndexChanged();

private:
    int m_current = -1;
};
