#pragma once
#include "api/MusicProvider.h"
#include "models/CollectionModel.h"
#include "models/SongModel.h"
#include <QHash>
#include <QObject>

class SettingsService;
class LibraryService;

// QML-facing facade for browsing: search, home feed and album/artist/playlist pages.
class AppController : public QObject
{
    Q_OBJECT
    Q_PROPERTY(SongModel *searchTracks READ searchTracks CONSTANT)
    Q_PROPERTY(CollectionModel *searchCollections READ searchCollections CONSTANT)
    Q_PROPERTY(SongModel *detailTracks READ detailTracks CONSTANT)
    Q_PROPERTY(CollectionModel *detailCollections READ detailCollections CONSTANT)
    Q_PROPERTY(SongModel *homeTracks READ homeTracks CONSTANT)
    Q_PROPERTY(CollectionModel *homeCollections READ homeCollections CONSTANT)
    Q_PROPERTY(QVariantMap detail READ detail NOTIFY detailChanged)
    Q_PROPERTY(QString lastQuery READ lastQuery NOTIFY searchStateChanged)
    Q_PROPERTY(int filter READ filter NOTIFY searchStateChanged)
    Q_PROPERTY(bool searchLoading READ searchLoading NOTIFY searchStateChanged)
    Q_PROPERTY(bool detailLoading READ detailLoading NOTIFY detailChanged)
    Q_PROPERTY(bool homeLoading READ homeLoading NOTIFY homeStateChanged)
    Q_PROPERTY(bool homeFailed READ homeFailed NOTIFY homeStateChanged)
    Q_PROPERTY(QString errorMessage READ errorMessage NOTIFY errorChanged)
public:
    AppController(MusicProvider *provider, SettingsService *settings, QObject *parent = nullptr);

    SongModel *searchTracks() { return &m_searchTracks; }
    CollectionModel *searchCollections() { return &m_searchCollections; }
    SongModel *detailTracks() { return &m_detailTracks; }
    CollectionModel *detailCollections() { return &m_detailCollections; }
    SongModel *homeTracks() { return &m_homeTracks; }
    CollectionModel *homeCollections() { return &m_homeCollections; }
    QVariantMap detail() const { return m_detail; }
    QString lastQuery() const { return m_query; }
    int filter() const { return int(m_filter); }
    bool searchLoading() const { return m_searchLoading; }
    bool detailLoading() const { return m_detailLoading; }
    bool homeLoading() const { return m_homeLoading; }
    bool homeFailed() const { return m_homeFailed; }
    QString errorMessage() const { return m_error; }

    Q_INVOKABLE void search(const QString &query, int filter);
    Q_INVOKABLE void openCollection(const QVariantMap &collection);
    Q_INVOKABLE void loadHome();
    Q_INVOKABLE void clearError();

signals:
    void detailChanged();
    void searchStateChanged();
    void homeStateChanged();
    void errorChanged();

private:
    void setError(const hm::ApiError &e);
    void applySearch(const hm::SearchResults &r);

    MusicProvider *m_provider;
    SettingsService *m_settings;

    SongModel m_searchTracks, m_detailTracks, m_homeTracks;
    CollectionModel m_searchCollections, m_detailCollections, m_homeCollections;
    QVariantMap m_detail;
    QString m_query, m_error;
    hm::SearchFilter m_filter = hm::SearchFilter::All;
    quint64 m_searchToken = 0, m_detailToken = 0, m_homeToken = 0;
    bool m_searchLoading = false, m_detailLoading = false, m_homeLoading = false, m_homeFailed = false;
    QHash<QString, hm::SearchResults> m_cache; // simple in-memory result cache
};
