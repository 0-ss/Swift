#include "AccountService.h"

#include "SettingsService.h"
#include "api/MusicProvider.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QRegularExpression>
#include <QTimer>

#ifdef SWIFT_HAS_QTKEYCHAIN
#include <qt6keychain/keychain.h>
#endif

#ifdef SWIFT_HAS_WEBENGINE
#include <QWebEngineCookieStore>
#include <QWebEngineProfile>
#include <QWebEngineView>
#endif

namespace {
constexpr auto kKeychainService = "Swift";
constexpr auto kKeychainKey = "youtube-music-session";

QString cookieValue(const QHash<QString, QNetworkCookie> &cookies)
{
    QStringList values;
    values.reserve(cookies.size());
    for (auto it = cookies.cbegin(); it != cookies.cend(); ++it)
        values << QString::fromLatin1(it.value().name() + '=' + it.value().value());
    return values.join("; ");
}

bool isSessionCookieName(const QByteArray &name)
{
    static const QSet<QByteArray> names = {
        "SID", "HSID", "SSID", "APISID", "SAPISID", "LOGIN_INFO", "PREF", "CONSENT",
        "__Secure-1PSID", "__Secure-3PSID", "__Secure-1PAPISID", "__Secure-3PAPISID"
    };
    return names.contains(name);
}
}

AccountService::AccountService(SettingsService *settings, QObject *parent)
    : QObject(parent), m_settings(settings)
{
    // Remove the prior plaintext setting during startup; it is migrated only into
    // secure storage and is never exposed through the QML settings map again.
    m_legacyCookie = m_settings->takeLegacyAuthCookie();
    restoreStoredSession();
}

AccountService::~AccountService() = default;

void AccountService::setProvider(MusicProvider *provider)
{
    if (m_provider == provider) return;
    m_provider = provider;
    if (!m_provider) return;

    connect(m_provider, &MusicProvider::accountInfoLoaded, this,
            [this](quint64 token, const hm::AccountInfo &account) {
        if (token == m_validationToken) sessionValidated(account.name, account.channelHandle);
    });
    connect(m_provider, &MusicProvider::failed, this, [this](quint64 token, const hm::ApiError &error) {
        if (token != m_validationToken) return;
        sessionValidationFailed(hm::userMessage(error), error.kind == hm::ApiError::AuthRequired);
    });

    if (m_storageRestoreFinished && !m_cookie.isEmpty()) validateSession();
}

bool AccountService::embeddedLoginAvailable() const
{
#ifdef SWIFT_HAS_WEBENGINE
    return true;
#else
    return false;
#endif
}

bool AccountService::persistentStorageAvailable() const
{
#ifdef SWIFT_HAS_QTKEYCHAIN
    return true;
#else
    return false;
#endif
}

QString AccountService::state() const
{
    switch (m_state) {
    case State::Disconnected: return "disconnected";
    case State::Restoring: return "restoring";
    case State::Connecting: return "connecting";
    case State::Connected: return "connected";
    case State::Expired: return "expired";
    case State::Error: return "error";
    }
    return "error";
}

QString AccountService::cookieFromInput(const QString &input)
{
    const QString trimmed = input.trimmed();
    if (trimmed.isEmpty()) return {};

    QJsonParseError parseError;
    const QJsonDocument json = QJsonDocument::fromJson(trimmed.toUtf8(), &parseError);
    if (parseError.error == QJsonParseError::NoError && json.isObject()) {
        const QJsonObject object = json.object();
        for (auto it = object.constBegin(); it != object.constEnd(); ++it) {
            if (it.key().compare("cookie", Qt::CaseInsensitive) == 0)
                return it.value().toString().trimmed();
        }
    }

    const QRegularExpression headerRe(R"((?im)^\s*cookie\s*:\s*(.+?)\s*$)");
    const QRegularExpressionMatch headerMatch = headerRe.match(trimmed);
    if (headerMatch.hasMatch()) return headerMatch.captured(1).trimmed();

    QString candidate = trimmed;
    if (candidate.startsWith("Cookie:", Qt::CaseInsensitive))
        candidate = candidate.mid(candidate.indexOf(':') + 1).trimmed();
    // A raw Cookie header is one line. Do not accidentally treat unrelated copied
    // HTTP headers as part of a credential.
    return candidate.contains('\n') || candidate.contains('\r') ? QString{} : candidate;
}

QString AccountService::authUserFromInput(const QString &input)
{
    const QRegularExpression re(R"((?im)^\s*x-goog-authuser\s*:\s*(\d+)\s*$)");
    const QRegularExpressionMatch match = re.match(input);
    return match.hasMatch() ? match.captured(1) : QStringLiteral("0");
}

bool AccountService::hasAuthCookie(const QString &cookie)
{
    const QRegularExpression sapisidRe(R"((?:^|;\s*)(?:SAPISID|__Secure-3PAPISID)=)");
    const QRegularExpression sessionRe(R"((?:^|;\s*)(?:SID|__Secure-3PSID)=)");
    return sapisidRe.match(cookie).hasMatch() && sessionRe.match(cookie).hasMatch();
}

void AccountService::setState(State state, const QString &message)
{
    const bool changed = m_state != state || m_statusMessage != message;
    m_state = state;
    m_statusMessage = message;
    if (changed) emit accountChanged();
}

void AccountService::clearInMemorySession()
{
    m_cookie.clear();
    m_authUser = QStringLiteral("0");
    m_displayName.clear();
    m_channelHandle.clear();
    m_validationToken = 0;
}

void AccountService::migrateLegacySessionIfNeeded()
{
    if (m_legacyCookie.isEmpty() || !m_cookie.isEmpty()) return;
    const QString oldCookie = m_legacyCookie;
    m_legacyCookie.clear();
    if (!hasAuthCookie(oldCookie)) {
        setState(State::Error, "The previous saved session is incomplete. Connect again to continue.");
        return;
    }
    persistAndValidate(oldCookie, QStringLiteral("0"));
}

void AccountService::restoreStoredSession()
{
#ifdef SWIFT_HAS_QTKEYCHAIN
    setState(State::Restoring, "Restoring your securely saved YouTube Music session…");
    auto *job = new QKeychain::ReadPasswordJob(kKeychainService, this);
    job->setKey(kKeychainKey);
    connect(job, &QKeychain::Job::finished, this, [this, job] {
        if (job->error() == QKeychain::NoError && !job->textData().isEmpty()) {
            QJsonParseError error;
            const QJsonDocument doc = QJsonDocument::fromJson(job->textData().toUtf8(), &error);
            if (error.error == QJsonParseError::NoError && doc.isObject()) {
                m_cookie = doc.object().value("cookie").toString();
                m_authUser = doc.object().value("authUser").toString("0");
            } else {
                // An early preview stored only the cookie; migrate it in place.
                m_cookie = job->textData();
                m_authUser = QStringLiteral("0");
            }
        }
        m_storageRestoreFinished = true;
        job->deleteLater();
        if (!m_cookie.isEmpty()) validateSession();
        else {
            setState(State::Disconnected, "No YouTube Music account connected.");
            migrateLegacySessionIfNeeded();
        }
    });
    job->start();
#else
    m_storageRestoreFinished = true;
    setState(State::Disconnected,
             "Secure credential storage is unavailable; connect for this app session or install QtKeychain.");
    migrateLegacySessionIfNeeded();
#endif
}

void AccountService::persistAndValidate(const QString &cookie, const QString &authUser)
{
    m_cookie = cookie;
    m_authUser = authUser.isEmpty() ? QStringLiteral("0") : authUser;
    m_displayName.clear();
    m_channelHandle.clear();
    emit sessionChanged();

#ifdef SWIFT_HAS_QTKEYCHAIN
    setState(State::Restoring, "Saving your session securely…");
    const QJsonObject stored{{"cookie", m_cookie}, {"authUser", m_authUser}};
    auto *job = new QKeychain::WritePasswordJob(kKeychainService, this);
    job->setKey(kKeychainKey);
    job->setTextData(QString::fromUtf8(QJsonDocument(stored).toJson(QJsonDocument::Compact)));
    connect(job, &QKeychain::Job::finished, this, [this, job] {
        const bool stored = job->error() == QKeychain::NoError;
        job->deleteLater();
        if (!stored) {
            setState(State::Error, "Couldn't save the session to the system keychain. Nothing was written to Settings.");
            return;
        }
        validateSession();
    });
    job->start();
#else
    validateSession();
#endif
}

void AccountService::validateSession()
{
    if (m_cookie.isEmpty()) {
        setState(State::Disconnected, "No YouTube Music account connected.");
        return;
    }
    if (!m_provider) {
        setState(State::Restoring, "Preparing your YouTube Music connection…");
        return;
    }
    setState(State::Restoring, "Checking your YouTube Music session…");
    m_validationToken = m_provider->fetchAccountInfo();
}

void AccountService::sessionValidated(const QString &name, const QString &channelHandle)
{
    m_displayName = name.isEmpty() ? QStringLiteral("Connected YouTube Music account") : name;
    m_channelHandle = channelHandle;
    setState(State::Connected, QStringLiteral("Connected as %1.").arg(m_displayName));
    emit sessionChanged();
}

void AccountService::sessionValidationFailed(const QString &message, bool expired)
{
    m_displayName.clear();
    m_channelHandle.clear();
    setState(expired ? State::Expired : State::Error,
             expired ? "Your YouTube Music session has expired. Reconnect to continue."
                     : message);
    emit sessionChanged();
}

void AccountService::importSession(const QString &headersOrCookie)
{
    const QString cookie = cookieFromInput(headersOrCookie);
    if (!hasAuthCookie(cookie)) {
        setState(State::Error,
                 "That session is missing the required YouTube cookies. Paste a complete Cookie header or copied request headers.");
        return;
    }
    persistAndValidate(cookie, authUserFromInput(headersOrCookie));
}

void AccountService::reconnect()
{
    if (embeddedLoginAvailable()) beginLogin();
    else setState(State::Error,
                  "Use Import Session to paste a complete Cookie header. This build does not include the embedded sign-in component.");
}

void AccountService::signOut()
{
    clearInMemorySession();
    emit sessionChanged();
#ifdef SWIFT_HAS_QTKEYCHAIN
    auto *job = new QKeychain::DeletePasswordJob(kKeychainService, this);
    job->setKey(kKeychainKey);
    connect(job, &QKeychain::Job::finished, this, [this, job] {
        const bool removed = job->error() == QKeychain::NoError;
        job->deleteLater();
        setState(State::Disconnected, removed ? "Signed out. The saved session was removed from your system keychain."
                                               : "Signed out of Swift. The system keychain entry may need manual removal.");
    });
    job->start();
#else
    setState(State::Disconnected, "Signed out. No session was stored on disk.");
#endif
}

void AccountService::refresh()
{
    if (m_cookie.isEmpty()) {
        setState(State::Disconnected, "Connect a YouTube Music account first.");
        return;
    }
    validateSession();
}

void AccountService::beginLogin()
{
#ifdef SWIFT_HAS_WEBENGINE
    if (m_loginView) {
        m_loginView->raise();
        m_loginView->activateWindow();
        return;
    }
    m_browserCookies.clear();
    if (!m_loginProfile) {
        m_loginProfile = new QWebEngineProfile(QStringLiteral("SwiftYouTubeMusicLogin"), this);
        m_loginProfile->setPersistentCookiesPolicy(QWebEngineProfile::NoPersistentCookies);
        connect(m_loginProfile->cookieStore(), &QWebEngineCookieStore::cookieAdded,
                this, &AccountService::captureBrowserCookie);
    }
    m_loginView = new QWebEngineView(m_loginProfile);
    m_loginView->setAttribute(Qt::WA_DeleteOnClose);
    m_loginView->resize(980, 740);
    m_loginView->setWindowTitle("Connect YouTube Music — Swift");
    connect(m_loginView, &QObject::destroyed, this, [this] { m_loginView = nullptr; });
    setState(State::Connecting, "Sign in to Google in the secure connection window…");
    m_loginView->load(QUrl(QStringLiteral("https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fmusic.youtube.com%2F")));
    m_loginView->show();
#else
    setState(State::Error,
             "This build does not include embedded sign-in. Import a complete Cookie header instead.");
#endif
}

#ifdef SWIFT_HAS_WEBENGINE
void AccountService::captureBrowserCookie(const QNetworkCookie &cookie)
{
    const QString domain = cookie.domain().toLower();
    if (!domain.contains("youtube.com") || !isSessionCookieName(cookie.name())) return;
    m_browserCookies.insert(QString::fromLatin1(cookie.name()), cookie);
    if (hasAuthCookie(cookieValue(m_browserCookies)))
        QTimer::singleShot(600, this, &AccountService::captureBrowserSession);
}

void AccountService::captureBrowserSession()
{
    if (m_state != State::Connecting) return;
    const QString cookie = cookieValue(m_browserCookies);
    if (!hasAuthCookie(cookie)) return;
    if (m_loginView) m_loginView->close();
    persistAndValidate(cookie, QStringLiteral("0"));
}
#endif
