#pragma once
#include <QAbstractListModel>
#include <QElapsedTimer>
#include <QNetworkAccessManager>
#include <QPointer>
#include <QSet>
#include <QTimer>
#include <QVector>
#include <functional>

class MusicPlayer;
class SettingsService;
class QNetworkReply;

// One row per lyric line. `timeMs` is -1 for unsynced (plain) lyrics.
class LyricsModel : public QAbstractListModel
{
    Q_OBJECT
public:
    enum Roles { TextRole = Qt::UserRole + 1, TimeRole };
    struct Line { qint64 timeMs = -1; QString text; };

    using QAbstractListModel::QAbstractListModel;
    int rowCount(const QModelIndex &parent = {}) const override { return parent.isValid() ? 0 : int(m_lines.size()); }
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    void setLines(QVector<Line> lines);
    const QVector<Line> &lines() const { return m_lines; }

private:
    QVector<Line> m_lines;
};

// Looks up lyrics for the playing track on LRCLIB (https://lrclib.net, free, no account) and
// keeps `currentIndex` on the line being sung. Results are cached on disk, so a song is looked
// up once. Nothing is requested until QML sets `wanted` (lyrics are actually on screen).
//
// status: 0 idle, 1 loading, 2 ready, 3 not found, 4 instrumental, 5 network failure
class LyricsService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(LyricsModel *lines READ lines CONSTANT)
    Q_PROPERTY(int status READ status NOTIFY statusChanged)
    Q_PROPERTY(bool synced READ synced NOTIFY statusChanged)
    Q_PROPERTY(int currentIndex READ currentIndex NOTIFY currentIndexChanged)
    Q_PROPERTY(bool wanted READ wanted WRITE setWanted NOTIFY wantedChanged)
public:
    enum Status { Idle, Loading, Ready, NotFound, Instrumental, Failed };

    LyricsService(MusicPlayer *player, SettingsService *settings, QObject *parent = nullptr);

    LyricsModel *lines() { return &m_model; }
    int status() const { return m_status; }
    bool synced() const { return m_synced && m_status == Ready; }
    int currentIndex() const { return m_index; }
    bool wanted() const { return m_wanted; }
    void setWanted(bool on);

    Q_INVOKABLE void retry();

signals:
    void statusChanged();
    void currentIndexChanged();
    void wantedChanged();

private:
    struct Query { QString videoId, title, artist, album; qint64 durationMs = 0; };

    void onTrackChanged();
    void onPosition();
    void tick();
    void updateIndex();
    void updateTimer();
    void load();
    void resetState();
    void setStatus(Status s);
    void fetchExact(const Query &q);
    void fetchLoose(const Query &q);
    void fetchSearch(const Query &q, int attempt);
    void get(const QUrl &url, std::function<void(int http, const QByteArray &body, bool netError)> done);
    void apply(const QJsonObject &o, bool store);
    QString cacheFile(const QString &videoId) const;
    qint64 estimatedPosition() const;

    static QString cleanTitle(QString title, const QString &artist);
    static QString primaryArtist(QString artist);
    static QVector<LyricsModel::Line> parseLrc(const QString &lrc);
    static QVector<LyricsModel::Line> parsePlain(const QString &text);

    MusicPlayer *m_player;
    QNetworkAccessManager m_net;
    QPointer<QNetworkReply> m_reply;
    LyricsModel m_model;
    QTimer m_tick;
    QTimer m_deadline;       // a lookup that is still Loading when this fires becomes Failed
    QElapsedTimer m_clock;
    QElapsedTimer m_loadClock; // time since the current lookup started (for the log)
    qint64 m_basePos = 0;
    QString m_trackId;       // track currently playing
    QString m_loadedId;      // track the model / status belong to
    QSet<QString> m_missing; // definitive "no lyrics" answers this session
    QString m_cacheDir;
    quint64 m_gen = 0;
    Status m_status = Idle;
    int m_index = -1;
    bool m_synced = false;
    bool m_wanted = false;
    bool m_enabled = true;
};
