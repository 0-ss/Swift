#include "LyricsService.h"
#include "SettingsService.h"
#include "playback/MusicPlayer.h"
#include <QCryptographicHash>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkReply>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QUrlQuery>
#include <algorithm>
#include <cmath>

namespace {
constexpr auto kApi = "https://lrclib.net/api";
constexpr qint64 kLeadMs = 220;       // light up a line a moment before it is sung
constexpr qint64 kMaxExtrapolateMs = 1200;
constexpr qint64 kDurationSlackMs = 6000;
constexpr int kDeadlineMs = 15000;     // never show "Loading" longer than this
}

// ---- model ---------------------------------------------------------------------------------

QVariant LyricsModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_lines.size()) return {};
    const Line &l = m_lines[index.row()];
    switch (role) {
    case TextRole: return l.text;
    case TimeRole: return l.timeMs;
    }
    return {};
}

QHash<int, QByteArray> LyricsModel::roleNames() const
{
    return {{TextRole, "text"}, {TimeRole, "timeMs"}};
}

void LyricsModel::setLines(QVector<Line> lines)
{
    beginResetModel();
    m_lines = std::move(lines);
    endResetModel();
}

// ---- service -------------------------------------------------------------------------------

LyricsService::LyricsService(MusicPlayer *player, SettingsService *settings, QObject *parent)
    : QObject(parent), m_player(player)
{
    m_cacheDir = QStandardPaths::writableLocation(QStandardPaths::CacheLocation) + "/lyrics";
    QDir().mkpath(m_cacheDir);
    // keep the cache small: drop the oldest entries once it grows past a generous size
    QDir dir(m_cacheDir);
    const QFileInfoList files = dir.entryInfoList({"*.json"}, QDir::Files, QDir::Time | QDir::Reversed);
    if (files.size() > 2000)
        for (int i = 0; i < files.size() - 1500; ++i) QFile::remove(files[i].absoluteFilePath());

    m_net.setRedirectPolicy(QNetworkRequest::NoLessSafeRedirectPolicy);
    m_net.setTransferTimeout(9000);

    m_deadline.setSingleShot(true);
    m_deadline.setInterval(kDeadlineMs);
    connect(&m_deadline, &QTimer::timeout, this, [this] {
        if (m_status != Loading) return;
        qInfo().noquote() << "[lyrics] gave up after" << kDeadlineMs << "ms";
        ++m_gen;                                    // late replies are ignored
        if (m_reply) m_reply->abort();
        setStatus(Failed);                          // UI offers "Try Again"
    });

    m_enabled = settings->get("lyricsEnabled").toBool();
    connect(settings, &SettingsService::changed, this, [this](const QString &key, const QVariant &v) {
        if (key != "lyricsEnabled") return;
        m_enabled = v.toBool();
        if (m_enabled) load(); else { ++m_gen; if (m_reply) m_reply->abort(); resetState(); }
        updateTimer();
    });

    m_tick.setInterval(90);
    connect(&m_tick, &QTimer::timeout, this, &LyricsService::tick);
    m_clock.start();

    connect(player, &MusicPlayer::trackChanged, this, &LyricsService::onTrackChanged);
    connect(player, &MusicPlayer::positionChanged, this, &LyricsService::onPosition);
    connect(player, &MusicPlayer::playingChanged, this, &LyricsService::updateTimer);
    m_trackId = player->videoId();
}

void LyricsService::setWanted(bool on)
{
    if (m_wanted == on) return;
    m_wanted = on;
    qInfo().noquote() << "[lyrics] wanted =" << on;
    emit wantedChanged();
    if (on) load();
    updateTimer();
}

void LyricsService::retry()
{
    if (m_status == Failed || m_status == NotFound) { m_missing.remove(m_trackId); m_loadedId.clear(); load(); }
}

void LyricsService::onTrackChanged()
{
    const QString id = m_player->videoId();
    if (id == m_trackId) return;        // queue edits also emit trackChanged
    m_trackId = id;
    qInfo().noquote() << "[lyrics] track changed:" << id << m_player->artist() << "-" << m_player->title();
    ++m_gen;
    if (m_reply) m_reply->abort();
    resetState();
    load();
}

void LyricsService::resetState()
{
    m_deadline.stop();
    m_loadedId.clear();
    m_synced = false;
    m_model.setLines({});
    if (m_index != -1) { m_index = -1; emit currentIndexChanged(); }
    setStatus(Idle);
}

void LyricsService::setStatus(Status s)
{
    if (s != Loading) m_deadline.stop();
    if (m_status == s) return;
    m_status = s;
    emit statusChanged();
    updateTimer();
}

QString LyricsService::cacheFile(const QString &videoId) const
{
    return m_cacheDir + "/" + QString::fromLatin1(QCryptographicHash::hash(videoId.toUtf8(), QCryptographicHash::Sha1).toHex()) + ".json";
}

void LyricsService::load()
{
    if (!m_enabled || !m_wanted || m_trackId.isEmpty() || m_loadedId == m_trackId) {
        qInfo().noquote() << "[lyrics] load skipped: enabled" << m_enabled << "wanted" << m_wanted
                          << "trackId" << m_trackId << "loadedId" << m_loadedId << "status" << int(m_status);
        return;
    }
    if (!m_player->hasTrack()) { qInfo() << "[lyrics] load skipped: player has no track"; return; }

    m_loadedId = m_trackId;
    ++m_gen;
    if (m_reply) m_reply->abort();

    // 1. disk cache
    QFile f(cacheFile(m_trackId));
    if (f.open(QIODevice::ReadOnly)) {
        const QJsonDocument d = QJsonDocument::fromJson(f.readAll());
        if (d.isObject()) { apply(d.object(), false); return; }
    }
    if (m_missing.contains(m_trackId)) { setStatus(NotFound); return; }

    // 2. LRCLIB
    Query q;
    q.videoId = m_trackId;
    q.artist = primaryArtist(m_player->artist());
    q.title = cleanTitle(m_player->title(), q.artist);
    q.album = m_player->album();
    q.durationMs = m_player->duration();
    setStatus(Loading);
    m_loadClock.restart();
    m_deadline.start();
    qInfo().noquote() << "[lyrics] looking up" << q.artist << "-" << q.title
                      << "| album:" << q.album << "| duration ms:" << q.durationMs;
    fetchExact(q);
}

void LyricsService::get(const QUrl &url, std::function<void(int, const QByteArray &, bool)> done)
{
    QNetworkRequest req(url);
    req.setHeader(QNetworkRequest::UserAgentHeader, "Swift/0.1.0 (desktop music client)");
    req.setRawHeader("Accept", "application/json");
    QNetworkReply *r = m_net.get(req);
    m_reply = r;
    const quint64 gen = m_gen;
    connect(r, &QNetworkReply::finished, this, [this, r, gen, url, done = std::move(done)] {
        r->deleteLater();
        if (gen != m_gen) return;       // superseded by another track
        const int http = r->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        const bool netError = http == 0;
        qInfo().noquote() << "[lyrics]" << url.path() << "->"
                          << (netError ? r->errorString() : QString::number(http))
                          << QString("(%1 ms)").arg(m_loadClock.elapsed());
        done(http, r->readAll(), netError);
    });
}

void LyricsService::fetchExact(const Query &q)
{
    QUrl url(QString("%1/get").arg(kApi));
    QUrlQuery qs;
    qs.addQueryItem("track_name", q.title);
    qs.addQueryItem("artist_name", q.artist);
    if (!q.album.isEmpty()) qs.addQueryItem("album_name", q.album);
    if (q.durationMs > 0) qs.addQueryItem("duration", QString::number(qRound(q.durationMs / 1000.0)));
    url.setQuery(qs);

    get(url, [this, q](int http, const QByteArray &body, bool netError) {
        if (netError) { setStatus(Failed); return; }
        if (http == 200) {
            const QJsonDocument d = QJsonDocument::fromJson(body);
            if (d.isObject()) { apply(d.object(), true); return; }
        }
        // 404 or anything unusable. /get only accepts the duration within +-2 s of its record, so
        // try once more without it before falling back to the (much slower) /search.
        if (q.durationMs > 0 || !q.album.isEmpty()) fetchLoose(q);
        else fetchSearch(q, 0);
    });
}

// Pick the best candidate: right length, synced if possible, title as close as possible.
static QJsonObject pickBest(const QJsonArray &arr, const QString &title, qint64 durationMs)
{
    QJsonObject best;
    double bestScore = -1e18;
    for (const QJsonValue &v : arr) {
        const QJsonObject o = v.toObject();
        const double durMs = o.value("duration").toDouble() * 1000.0;
        const bool known = durationMs > 0 && durMs > 0;
        if (known && std::abs(durMs - double(durationMs)) > kDurationSlackMs) continue;
        double score = 0;
        if (!o.value("syncedLyrics").toString().trimmed().isEmpty()) score += 100;
        else if (!o.value("plainLyrics").toString().trimmed().isEmpty()) score += 20;
        else if (!o.value("instrumental").toBool()) continue;
        if (known) score -= std::abs(durMs - double(durationMs)) / 100.0;
        if (o.value("trackName").toString().compare(title, Qt::CaseInsensitive) == 0) score += 30;
        if (score > bestScore) { bestScore = score; best = o; }
    }
    return best;
}

void LyricsService::fetchLoose(const Query &q)
{
    QUrl url(QString("%1/get").arg(kApi));
    QUrlQuery qs;
    qs.addQueryItem("track_name", q.title);
    qs.addQueryItem("artist_name", q.artist);
    url.setQuery(qs);

    get(url, [this, q](int http, const QByteArray &body, bool netError) {
        if (netError) { setStatus(Failed); return; }
        if (http == 200) {
            const QJsonDocument d = QJsonDocument::fromJson(body);
            if (d.isObject()) {
                // same length check as for search results, so synced lines do not drift
                const QJsonObject best = pickBest(QJsonArray{d.object()}, q.title, q.durationMs);
                if (!best.isEmpty()) { apply(best, true); return; }
            }
        }
        fetchSearch(q, 0);
    });
}

void LyricsService::fetchSearch(const Query &q, int attempt)
{
    QUrl url(QString("%1/search").arg(kApi));
    QUrlQuery qs;
    if (attempt == 0) {
        qs.addQueryItem("track_name", q.title);
        qs.addQueryItem("artist_name", q.artist);
    } else {
        qs.addQueryItem("q", q.artist + " " + q.title);
    }
    url.setQuery(qs);

    get(url, [this, q, attempt](int http, const QByteArray &body, bool netError) {
        if (netError) { setStatus(Failed); return; }
        const QJsonDocument d = QJsonDocument::fromJson(body);
        if (http == 200 && d.isArray()) {
            const QJsonObject best = pickBest(d.array(), q.title, q.durationMs);
            if (!best.isEmpty()) { apply(best, true); return; }
        } else if (http >= 500 || http == 429) {
            setStatus(Failed);
            return;
        }
        if (attempt == 0) { fetchSearch(q, 1); return; }
        m_missing.insert(q.videoId);
        setStatus(NotFound);
    });
}

void LyricsService::apply(const QJsonObject &o, bool store)
{
    const QString syncedText = o.value("syncedLyrics").toString();
    const QString plainText = o.value("plainLyrics").toString();

    QVector<LyricsModel::Line> lines;
    bool synced = false;
    if (o.value("instrumental").toBool() && syncedText.trimmed().isEmpty() && plainText.trimmed().isEmpty()) {
        m_model.setLines({});
        m_synced = false;
        if (store) m_missing.insert(m_trackId);
        setStatus(Instrumental);
        return;
    }
    if (!syncedText.trimmed().isEmpty()) {
        lines = parseLrc(syncedText);
        synced = lines.size() >= 2;
    }
    if (!synced) lines = parsePlain(plainText);

    if (lines.isEmpty()) {
        m_model.setLines({});
        m_synced = false;
        m_missing.insert(m_trackId);
        setStatus(NotFound);
        return;
    }

    if (store) {
        QFile f(cacheFile(m_trackId));
        if (f.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            QJsonObject slim;
            slim["syncedLyrics"] = syncedText;
            slim["plainLyrics"] = plainText;
            slim["instrumental"] = o.value("instrumental").toBool();
            f.write(QJsonDocument(slim).toJson(QJsonDocument::Compact));
        }
    }

    m_synced = synced;
    if (m_index != -1) { m_index = -1; emit currentIndexChanged(); }
    m_model.setLines(std::move(lines));
    m_basePos = m_player->position();
    m_clock.restart();
    qInfo().noquote() << "[lyrics] ready:" << m_model.lines().size() << "lines, synced" << synced;
    setStatus(Ready);
    updateIndex();
}

// ---- timing --------------------------------------------------------------------------------

qint64 LyricsService::estimatedPosition() const
{
    // The player only reports its position every so often; between reports, extrapolate
    // from a monotonic clock so the highlighted line changes on time.
    const qint64 extra = m_player->playing() ? std::min(m_clock.elapsed(), kMaxExtrapolateMs) : 0;
    return m_basePos + extra;
}

void LyricsService::onPosition()
{
    m_basePos = m_player->position();
    m_clock.restart();
    if (synced()) updateIndex();
}

void LyricsService::tick()
{
    if (synced()) updateIndex();
}

void LyricsService::updateTimer()
{
    const bool run = m_enabled && m_wanted && synced() && m_player->playing();
    if (run && !m_tick.isActive()) m_tick.start();
    else if (!run && m_tick.isActive()) m_tick.stop();
}

void LyricsService::updateIndex()
{
    const auto &lines = m_model.lines();
    if (!synced() || lines.isEmpty()) return;
    const qint64 t = estimatedPosition() + kLeadMs;
    const auto it = std::upper_bound(lines.cbegin(), lines.cend(), t,
        [](qint64 v, const LyricsModel::Line &l) { return v < l.timeMs; });
    const int idx = int(it - lines.cbegin()) - 1;
    if (idx != m_index) { m_index = idx; emit currentIndexChanged(); }
}

// ---- cleaning & parsing --------------------------------------------------------------------

QString LyricsService::primaryArtist(QString artist)
{
    static const QRegularExpression topic(R"(\s*-\s*Topic\s*$|\s*VEVO\s*$)", QRegularExpression::CaseInsensitiveOption);
    static const QRegularExpression split(R"(\s*(?:,|&|;|•|\bfeat\.?\b|\bft\.?\b|\bfeaturing\b|\bwith\b|\bx\b)\s*)",
                                          QRegularExpression::CaseInsensitiveOption);
    artist.remove(topic);
    const QStringList parts = artist.split(split, Qt::SkipEmptyParts);
    return (parts.isEmpty() ? artist : parts.first()).trimmed();
}

QString LyricsService::cleanTitle(QString title, const QString &artist)
{
    // "(Official Video)", "[Lyrics]", "(Remastered 2011)", "(feat. X)" ...
    static const QRegularExpression noise(
        R"(\s*[\(\[][^\)\]]*(?:official|lyric|video|audio|visuali[sz]er|remaster|feat\.?|ft\.?|with |explicit|clean|\bhd\b|\bhq\b|4k|\bmv\b|live|version|edit)[^\)\]]*[\)\]])",
        QRegularExpression::CaseInsensitiveOption);
    static const QRegularExpression trailing(R"(\s*[-–|]\s*(?:official\s.*|lyrics?.*|audio.*|remaster.*)$)",
                                             QRegularExpression::CaseInsensitiveOption);
    if (!artist.isEmpty() && title.startsWith(artist + " - ", Qt::CaseInsensitive))
        title = title.mid(artist.size() + 3);
    title.remove(noise);
    title.remove(trailing);
    return title.simplified();
}

QVector<LyricsModel::Line> LyricsService::parseLrc(const QString &lrc)
{
    static const QRegularExpression stamp(R"(\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\])");
    static const QRegularExpression wordStamp(R"(<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>)");

    QVector<LyricsModel::Line> out;
    const QStringList rows = lrc.split('\n');
    for (const QString &raw : rows) {
        const QString row = raw.trimmed();
        if (row.isEmpty()) continue;

        QVector<qint64> times;
        qsizetype end = 0;
        for (;;) {                                  // leading [mm:ss.xx] tags, possibly several
            const QRegularExpressionMatch m = stamp.match(row, end);
            if (!m.hasMatch() || m.capturedStart() != end) break;
            const QString frac = m.captured(3);
            const int fracMs = frac.isEmpty() ? 0 : frac.toInt() * (frac.size() == 1 ? 100 : frac.size() == 2 ? 10 : 1);
            times.push_back(m.captured(1).toLongLong() * 60000 + m.captured(2).toLongLong() * 1000 + fracMs);
            end = m.capturedEnd();
        }
        if (times.isEmpty()) continue;              // [ar:..] [ti:..] and other metadata

        QString text = row.mid(end);
        text.remove(wordStamp);
        text = text.simplified();
        for (qint64 t : times) out.push_back({t, text});
    }
    std::stable_sort(out.begin(), out.end(), [](const auto &a, const auto &b) { return a.timeMs < b.timeMs; });

    // collapse runs of empty lines and trim empty lines from the end
    QVector<LyricsModel::Line> cleaned;
    for (const auto &l : std::as_const(out)) {
        if (l.text.isEmpty() && !cleaned.isEmpty() && cleaned.last().text.isEmpty()) continue;
        cleaned.push_back(l);
    }
    while (!cleaned.isEmpty() && cleaned.last().text.isEmpty() && cleaned.size() > 1) cleaned.removeLast();
    // a long instrumental intro gets a leading gap line, so there is something to show
    if (!cleaned.isEmpty() && cleaned.first().timeMs > 5000 && !cleaned.first().text.isEmpty())
        cleaned.prepend({0, QString()});
    return cleaned;
}

QVector<LyricsModel::Line> LyricsService::parsePlain(const QString &text)
{
    QVector<LyricsModel::Line> out;
    for (const QString &raw : text.split('\n')) {
        const QString line = raw.simplified();
        if (line.isEmpty() && (out.isEmpty() || out.last().text.isEmpty())) continue;
        out.push_back({-1, line});
    }
    while (!out.isEmpty() && out.last().text.isEmpty()) out.removeLast();
    return out;
}
