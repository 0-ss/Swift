#pragma once

#include <QIcon>
#include <QObject>

class QMenu;
class QSystemTrayIcon;
class QWindow;

class SystemTrayService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool enabled READ enabled WRITE setEnabled NOTIFY enabledChanged)
    Q_PROPERTY(bool available READ available CONSTANT)
    Q_PROPERTY(bool active READ active NOTIFY enabledChanged)
public:
    explicit SystemTrayService(QObject *parent = nullptr);

    bool enabled() const { return m_enabled; }
    bool available() const { return m_available; }
    bool active() const { return m_enabled && m_available; }

    void setEnabled(bool on);

    Q_INVOKABLE void attachWindow(QObject *object);
    Q_INVOKABLE void hideToTray();
    Q_INVOKABLE void showWindow();
    Q_INVOKABLE void quit();

signals:
    void enabledChanged();

private:
    void setWindowVisible(bool visible);

    QSystemTrayIcon *m_tray = nullptr;
    QMenu *m_menu = nullptr;
    QWindow *m_window = nullptr;
    bool m_enabled = true;
    bool m_available = false;
};
