#pragma once
#include <QObject>
#include <QQmlNetworkAccessManagerFactory>

class SettingsService;

// Gives the QML engine a network manager with an on-disk HTTP cache, so artwork
// is downloaded once and survives restarts.
class CacheService : public QObject, public QQmlNetworkAccessManagerFactory
{
    Q_OBJECT
public:
    explicit CacheService(SettingsService *settings, QObject *parent = nullptr);

    QNetworkAccessManager *create(QObject *parent) override;

    Q_INVOKABLE qint64 sizeBytes() const;
    Q_INVOKABLE void clear();
    QString path() const;

private:
    qint64 m_limitBytes;
};
