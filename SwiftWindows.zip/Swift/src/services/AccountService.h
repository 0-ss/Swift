#pragma once

#include <QHash>
#include <QNetworkCookie>
#include <QObject>
#include <QString>

class SettingsService;
class MusicProvider;
#ifdef SWIFT_HAS_WEBENGINE
class QWebEngineProfile;
class QWebEngineView;
#endif

// Owns the authenticated YouTube Music session. The raw credential never crosses
// into QML or QSettings: persistent storage is delegated to QtKeychain when that
// optional dependency is available.
class AccountService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool connected READ connected NOTIFY accountChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY accountChanged)
    Q_PROPERTY(bool embeddedLoginAvailable READ embeddedLoginAvailable CONSTANT)
    Q_PROPERTY(bool persistentStorageAvailable READ persistentStorageAvailable CONSTANT)
    Q_PROPERTY(QString displayName READ displayName NOTIFY accountChanged)
    Q_PROPERTY(QString channelHandle READ channelHandle NOTIFY accountChanged)
    Q_PROPERTY(QString statusMessage READ statusMessage NOTIFY accountChanged)
    Q_PROPERTY(QString state READ state NOTIFY accountChanged)
public:
    enum class State { Disconnected, Restoring, Connecting, Connected, Expired, Error };
    Q_ENUM(State)

    explicit AccountService(SettingsService *settings, QObject *parent = nullptr);
    ~AccountService() override;

    void setProvider(MusicProvider *provider);

    bool connected() const { return m_state == State::Connected; }
    bool busy() const { return m_state == State::Restoring || m_state == State::Connecting; }
    bool embeddedLoginAvailable() const;
    bool persistentStorageAvailable() const;
    QString displayName() const { return m_displayName; }
    QString channelHandle() const { return m_channelHandle; }
    QString statusMessage() const { return m_statusMessage; }
    QString state() const;

    // Used only by the provider while constructing authenticated request headers.
    QString sessionCookie() const { return m_cookie; }
    QString authUser() const { return m_authUser; }

    Q_INVOKABLE void beginLogin();
    Q_INVOKABLE void importSession(const QString &headersOrCookie);
    Q_INVOKABLE void reconnect();
    Q_INVOKABLE void signOut();
    Q_INVOKABLE void refresh();

    // Provider callbacks use these methods to ensure authentication failures are
    // shown as account state instead of a generic networking error.
    void sessionValidated(const QString &name, const QString &channelHandle);
    void sessionValidationFailed(const QString &message, bool expired);

signals:
    void accountChanged();
    void sessionChanged();

private:
    static QString cookieFromInput(const QString &input);
    static QString authUserFromInput(const QString &input);
    static bool hasAuthCookie(const QString &cookie);
    void restoreStoredSession();
    void persistAndValidate(const QString &cookie, const QString &authUser);
    void validateSession();
    void setState(State state, const QString &message);
    void clearInMemorySession();
    void migrateLegacySessionIfNeeded();
#ifdef SWIFT_HAS_WEBENGINE
    void captureBrowserCookie(const QNetworkCookie &cookie);
    void captureBrowserSession();
#endif

    SettingsService *m_settings = nullptr;
    MusicProvider *m_provider = nullptr;
    State m_state = State::Disconnected;
    QString m_cookie;
    QString m_authUser = QStringLiteral("0");
    QString m_displayName;
    QString m_channelHandle;
    QString m_statusMessage = QStringLiteral("No YouTube Music account connected.");
    QString m_legacyCookie;
    quint64 m_validationToken = 0;
    bool m_storageRestoreFinished = false;
#ifdef SWIFT_HAS_WEBENGINE
    QWebEngineProfile *m_loginProfile = nullptr;
    QWebEngineView *m_loginView = nullptr;
    QHash<QString, QNetworkCookie> m_browserCookies;
#endif
};
