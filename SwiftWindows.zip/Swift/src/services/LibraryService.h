#pragma once
#include "models/SongModel.h"
#include <QObject>
#include <QTimer>

// Liked songs and recently played tracks, persisted as JSON in the app data folder.
// Because tracks are stored with their artwork URLs, these lists render offline.
class LibraryService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(SongModel *favorites READ favorites CONSTANT)
    Q_PROPERTY(SongModel *recents READ recents CONSTANT)
    Q_PROPERTY(QStringList favoriteIds READ favoriteIds NOTIFY favoritesChanged)
public:
    explicit LibraryService(QObject *parent = nullptr);
    ~LibraryService() override;

    SongModel *favorites() { return &m_favorites; }
    SongModel *recents() { return &m_recents; }
    QStringList favoriteIds() const { return m_favoriteIds; }

    Q_INVOKABLE void toggleFavorite(const QVariantMap &track);
    Q_INVOKABLE void clearRecents();

public slots:
    void addRecent(const hm::Track &t);

signals:
    void favoritesChanged();

private:
    void load();
    void save();
    void scheduleSave() { m_saveTimer.start(); }

    SongModel m_favorites, m_recents;
    QStringList m_favoriteIds;
    QTimer m_saveTimer;
};
