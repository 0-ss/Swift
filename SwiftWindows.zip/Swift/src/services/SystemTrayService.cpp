#include "SystemTrayService.h"
#include "SettingsService.h"
#include <QAction>
#include <QApplication>
#include <QCoreApplication>
#include <QMenu>
#include <QSystemTrayIcon>
#include <QWindow>

namespace {
const QString kIconPath = QStringLiteral(":/qt/qml/Swift/qml/assets/image.png");
}

SystemTrayService::SystemTrayService(QObject *parent)
: QObject(parent),
m_tray(new QSystemTrayIcon(this)),
m_menu(new QMenu())
{
    m_available = QSystemTrayIcon::isSystemTrayAvailable();
    m_tray->setIcon(QIcon(kIconPath));
    m_tray->setToolTip(QStringLiteral("Swift"));

    QAction *showAction = m_menu->addAction(QStringLiteral("Show Swift"));
    connect(showAction, &QAction::triggered, this, &SystemTrayService::showWindow);
    m_menu->addSeparator();
    QAction *quitAction = m_menu->addAction(QStringLiteral("Quit Swift"));
    connect(quitAction, &QAction::triggered, this, &SystemTrayService::quit);
    m_tray->setContextMenu(m_menu);

    connect(m_tray, &QSystemTrayIcon::activated, this,
            [this](QSystemTrayIcon::ActivationReason reason) {
        if (reason == QSystemTrayIcon::Trigger
                || reason == QSystemTrayIcon::DoubleClick
                || reason == QSystemTrayIcon::MiddleClick)
            showWindow();
    });

    // The service is created before the QML window; the setting is attached by main.cpp.
    QApplication::setQuitOnLastWindowClosed(!active());
}

void SystemTrayService::setEnabled(bool on)
{
    if (m_enabled == on) {
        m_tray->setVisible(active());
        QApplication::setQuitOnLastWindowClosed(!active());
        return;
    }
    m_enabled = on;
    m_tray->setVisible(active());
    QApplication::setQuitOnLastWindowClosed(!active());
    if (!active() && m_window && !m_window->isVisible()) showWindow();
    emit enabledChanged();
}

void SystemTrayService::attachWindow(QObject *object)
{
    m_window = qobject_cast<QWindow *>(object);
    if (m_window) m_window->setIcon(QIcon(kIconPath));
    m_tray->setVisible(active());
}

void SystemTrayService::setWindowVisible(bool visible)
{
    if (!m_window) return;
    if (visible) {
        m_window->show();
        m_window->raise();
        m_window->requestActivate();
    } else {
        m_window->hide();
    }
}

void SystemTrayService::hideToTray()
{
    if (active()) setWindowVisible(false);
}

void SystemTrayService::showWindow()
{
    setWindowVisible(true);
}

void SystemTrayService::quit()
{
    if (m_window) m_window->close();
    QCoreApplication::quit();
}
