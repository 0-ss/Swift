#pragma once
#include <QObject>
#include <QQmlPropertyMap>
#include <QSettings>

// Persistent settings. QML binds to `settings.values.<key>` and assigns to it
// directly; C++ uses get()/set(). Every change is written to QSettings.
class SettingsService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QQmlPropertyMap *values READ values CONSTANT)
public:
    explicit SettingsService(QObject *parent = nullptr);

    QQmlPropertyMap *values() { return &m_map; }
    QVariant get(const QString &key) const { return m_map.value(key); }
    void set(const QString &key, const QVariant &value);
    // One-time security migration. This removes the old plaintext key before
    // AccountService moves the credential into the system keychain.
    QString takeLegacyAuthCookie();

    Q_INVOKABLE void resetToDefaults();

signals:
    void changed(const QString &key, const QVariant &value);

private:
    static QVariantMap defaults();

    QSettings m_store;
    QQmlPropertyMap m_map;
};
