#include "LibraryService.h"
#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLoggingCategory>
#include <QSaveFile>
#include <QStandardPaths>

Q_LOGGING_CATEGORY(lcLibrary, "swift.library")

namespace {
constexpr int kMaxRecents = 50;

QString libraryPath()
{
    const QString dir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(dir);
    return dir + "/library.json";
}

QJsonArray toArray(const QVector<hm::Track> &tracks)
{
    QJsonArray a;
    for (const auto &t : tracks) a.append(t.toJson());
    return a;
}

QVector<hm::Track> fromArray(const QJsonArray &a)
{
    QVector<hm::Track> out;
    for (const auto &v : a) {
        auto t = hm::Track::fromJson(v.toObject());
        if (t.isValid()) out << t;
    }
    return out;
}
}

LibraryService::LibraryService(QObject *parent) : QObject(parent)
{
    m_saveTimer.setSingleShot(true);
    m_saveTimer.setInterval(500);
    connect(&m_saveTimer, &QTimer::timeout, this, &LibraryService::save);
    load();
}

LibraryService::~LibraryService()
{
    if (m_saveTimer.isActive()) save();
}

void LibraryService::load()
{
    QFile f(libraryPath());
    if (!f.open(QIODevice::ReadOnly)) return;
    const QJsonObject root = QJsonDocument::fromJson(f.readAll()).object();
    m_favorites.setTracks(fromArray(root["favorites"].toArray()));
    m_recents.setTracks(fromArray(root["recents"].toArray()));
    for (const auto &t : m_favorites.tracks()) m_favoriteIds << t.videoId;
}

void LibraryService::save()
{
    QSaveFile f(libraryPath());
    if (!f.open(QIODevice::WriteOnly)) {
        qCWarning(lcLibrary) << "cannot write library:" << f.errorString();
        return;
    }
    const QJsonObject root{{"favorites", toArray(m_favorites.tracks())},
                           {"recents", toArray(m_recents.tracks())}};
    f.write(QJsonDocument(root).toJson(QJsonDocument::Compact));
    if (!f.commit()) qCWarning(lcLibrary) << "commit failed:" << f.errorString();
}

void LibraryService::toggleFavorite(const QVariantMap &track)
{
    const hm::Track t = hm::trackFromVariant(track);
    if (!t.isValid()) return;
    const int idx = m_favoriteIds.indexOf(t.videoId);
    if (idx >= 0) {
        m_favoriteIds.removeAt(idx);
        m_favorites.removeTrackAt(idx);
    } else {
        m_favoriteIds.prepend(t.videoId);
        m_favorites.insertTrack(0, t);
    }
    emit favoritesChanged();
    scheduleSave();
}

void LibraryService::addRecent(const hm::Track &t)
{
    if (!t.isValid()) return;
    for (int i = 0; i < m_recents.count(); ++i) {
        if (m_recents.trackAt(i).videoId == t.videoId) {
            m_recents.removeTrackAt(i);
            break;
        }
    }
    m_recents.insertTrack(0, t);
    while (m_recents.count() > kMaxRecents) m_recents.removeTrackAt(m_recents.count() - 1);
    scheduleSave();
}

void LibraryService::clearRecents()
{
    m_recents.clear();
    scheduleSave();
}
