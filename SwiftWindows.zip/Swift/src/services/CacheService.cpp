#include "CacheService.h"
#include "SettingsService.h"
#include <QDir>
#include <QDirIterator>
#include <QNetworkAccessManager>
#include <QNetworkDiskCache>
#include <QStandardPaths>

CacheService::CacheService(SettingsService *settings, QObject *parent)
    : QObject(parent)
    , m_limitBytes(qint64(settings->get("cacheLimitMb").toInt()) << 20) // read once: create() may run off-thread
{
}

QString CacheService::path() const
{
    return QStandardPaths::writableLocation(QStandardPaths::CacheLocation) + "/artwork";
}

QNetworkAccessManager *CacheService::create(QObject *parent)
{
    auto *nam = new QNetworkAccessManager(parent);
    auto *disk = new QNetworkDiskCache(nam);
    disk->setCacheDirectory(path());
    disk->setMaximumCacheSize(m_limitBytes);
    nam->setCache(disk);
    nam->setRedirectPolicy(QNetworkRequest::NoLessSafeRedirectPolicy);
    return nam;
}

qint64 CacheService::sizeBytes() const
{
    qint64 total = 0;
    QDirIterator it(path(), QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        it.next();
        total += it.fileInfo().size();
    }
    return total;
}

void CacheService::clear()
{
    QDir(path()).removeRecursively();
}
