#pragma once

#include "api/MusicProvider.h"
#include "models/SongModel.h"
#include <QAbstractListModel>
#include <QObject>

class AccountService;

struct PlaylistSummary {
    QString id, name, description;
    int trackCount = 0;
    qint64 durationMs = 0;
    QStringList covers;
    bool owned = true;
};

// One row per playlist, backed only by playlist data read from YouTube Music.
class PlaylistListModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(int count READ count NOTIFY countChanged)
public:
    enum Role { IdRole = Qt::UserRole + 1, NameRole, DescriptionRole, TrackCountRole,
                DurationRole, CoversRole, OwnedRole };

    using QAbstractListModel::QAbstractListModel;

    int rowCount(const QModelIndex &parent = {}) const override { return parent.isValid() ? 0 : count(); }
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    int count() const { return int(m_items.size()); }
    const PlaylistSummary &at(int row) const { return m_items[row]; }
    void setSummaries(const QVector<PlaylistSummary> &summaries);
    void updateSummary(int row, const PlaylistSummary &summary);
    void removeSummary(int row);
    Q_INVOKABLE QVariantMap get(int row) const;

signals:
    void countChanged();

private:
    QVector<PlaylistSummary> m_items;
};

// Remote-authoritative playlist facade. It never writes a local playlist file:
// changes remain pending until YouTube Music acknowledges them and a fresh browse
// response is loaded back into the model.
class PlaylistService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(PlaylistListModel *playlists READ playlists CONSTANT)
    Q_PROPERTY(SongModel *openTracks READ openTracks CONSTANT)
    Q_PROPERTY(QVariantMap openInfo READ openInfo NOTIFY openChanged)
    Q_PROPERTY(QString openId READ openId NOTIFY openChanged)
    Q_PROPERTY(bool loading READ loading NOTIFY stateChanged)
    Q_PROPERTY(bool openLoading READ openLoading NOTIFY openChanged)
    Q_PROPERTY(bool syncing READ syncing NOTIFY stateChanged)
    Q_PROPERTY(QString syncingPlaylistId READ syncingPlaylistId NOTIFY stateChanged)
    Q_PROPERTY(QString errorMessage READ errorMessage NOTIFY stateChanged)
    Q_PROPERTY(QString state READ state NOTIFY stateChanged)
    // 0 playlist order, 1 title, 2 artist, 3 album, 4 time
    Q_PROPERTY(int sortKey READ sortKey NOTIFY sortChanged)
    Q_PROPERTY(bool sortAscending READ sortAscending NOTIFY sortChanged)
public:
    enum class SyncState { Disconnected, Loading, Ready, Empty, Error, AuthenticationRequired };
    Q_ENUM(SyncState)

    PlaylistService(MusicProvider *provider, AccountService *account, QObject *parent = nullptr);

    PlaylistListModel *playlists() { return &m_listModel; }
    SongModel *openTracks() { return &m_open; }
    QVariantMap openInfo() const;
    QString openId() const { return m_openId; }
    bool loading() const { return m_loading; }
    bool openLoading() const { return m_openLoading; }
    bool syncing() const { return m_pending.kind != PendingKind::None; }
    QString syncingPlaylistId() const { return m_pending.playlistId; }
    QString errorMessage() const { return m_error; }
    QString state() const;
    int sortKey() const { return m_sortKey; }
    bool sortAscending() const { return m_ascending; }

    Q_INVOKABLE void refresh();
    Q_INVOKABLE QVariantMap info(const QString &id) const;
    Q_INVOKABLE bool contains(const QString &id, const QString &videoId) const;
    Q_INVOKABLE QVariantList tracksOf(const QString &id) const;
    Q_INVOKABLE void open(const QString &id);
    Q_INVOKABLE void close();
    Q_INVOKABLE void play(const QString &id, bool shuffle);

    Q_INVOKABLE void create(const QString &name, const QString &description, const QVariantList &tracks = {});
    Q_INVOKABLE void edit(const QString &id, const QString &name, const QString &description);
    Q_INVOKABLE void remove(const QString &id);
    Q_INVOKABLE int addTrack(const QString &id, const QVariantMap &track);
    Q_INVOKABLE int addTracks(const QString &id, const QVariantList &tracks);
    Q_INVOKABLE int addModel(const QString &id, QObject *songModel);
    Q_INVOKABLE void removeAt(int viewIndex);
    Q_INVOKABLE void move(int from, int to);
    Q_INVOKABLE void setSort(int key, bool ascending);
    Q_INVOKABLE void commitSortAsOrder();

signals:
    void openChanged();
    void stateChanged();
    void sortChanged();
    void removed(const QString &id);
    void created(const QString &id, bool withTracks);
    void playbackReady(bool shuffle);
    void message(const QString &text);

private:
    enum class PendingKind { None, PrepareAdd, Create, Edit, Delete, Add, Remove, Reorder };
    struct Pending {
        PendingKind kind = PendingKind::None;
        quint64 token = 0;
        QString playlistId;
        QString name, description;
        QVector<hm::Track> tracks;
        QVector<hm::Track> desiredOrder;
        bool shuffle = false;
        bool awaitingVerification = false;
    };

    int indexOf(const QString &id) const;
    PlaylistSummary summaryOf(const hm::RemotePlaylist &playlist) const;
    QVariantMap infoAt(int index) const;
    void replacePlaylist(const hm::RemotePlaylist &playlist);
    void applyLibrary(const QVector<hm::RemotePlaylist> &playlists);
    void loadOpenPlaylist(const QString &id);
    void beginPending(Pending pending, quint64 token);
    void requestVerification();
    void finishPendingSuccess();
    void finishPendingFailure(const QString &message, bool refreshToReconcile = false);
    void handleProviderFailure(quint64 token, const hm::ApiError &error);
    void handleLoadedPlaylist(quint64 token, const hm::RemotePlaylist &playlist);
    QVector<int> sortedOrder(const hm::RemotePlaylist &playlist) const;
    void rebuildOpen();
    void setError(const hm::ApiError &error);
    bool ensureConnected(const QString &operation);

    MusicProvider *m_provider = nullptr;
    AccountService *m_account = nullptr;
    PlaylistListModel m_listModel;
    SongModel m_open;
    QVector<hm::RemotePlaylist> m_lists;
    QString m_openId;
    QVector<int> m_viewMap;
    quint64 m_libraryToken = 0;
    quint64 m_openToken = 0;
    bool m_loading = false;
    bool m_openLoading = false;
    SyncState m_state = SyncState::Disconnected;
    QString m_error;
    int m_sortKey = 0;
    bool m_ascending = true;
    bool m_pendingPlayback = false;
    bool m_pendingPlaybackShuffle = false;
    Pending m_pending;
};
