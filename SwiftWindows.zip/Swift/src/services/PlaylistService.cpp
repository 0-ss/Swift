#include "PlaylistService.h"

#include "AccountService.h"
#include <QHash>
#include <QSet>
#include <algorithm>
#include <utility>

// ---- PlaylistListModel ---------------------------------------------------------------------

QVariant PlaylistListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= count()) return {};
    const PlaylistSummary &summary = m_items[index.row()];
    switch (role) {
    case IdRole: return summary.id;
    case NameRole: return summary.name;
    case DescriptionRole: return summary.description;
    case TrackCountRole: return summary.trackCount;
    case DurationRole: return summary.durationMs;
    case CoversRole: return summary.covers;
    case OwnedRole: return summary.owned;
    default: return {};
    }
}

QHash<int, QByteArray> PlaylistListModel::roleNames() const
{
    return {{IdRole, "playlistId"}, {NameRole, "name"}, {DescriptionRole, "description"},
            {TrackCountRole, "trackCount"}, {DurationRole, "durationMs"}, {CoversRole, "covers"},
            {OwnedRole, "owned"}};
}

void PlaylistListModel::setSummaries(const QVector<PlaylistSummary> &summaries)
{
    beginResetModel();
    m_items = summaries;
    endResetModel();
    emit countChanged();
}

void PlaylistListModel::updateSummary(int row, const PlaylistSummary &summary)
{
    if (row < 0 || row >= count()) return;
    m_items[row] = summary;
    emit dataChanged(index(row), index(row));
}

void PlaylistListModel::removeSummary(int row)
{
    if (row < 0 || row >= count()) return;
    beginRemoveRows({}, row, row);
    m_items.removeAt(row);
    endRemoveRows();
    emit countChanged();
}

QVariantMap PlaylistListModel::get(int row) const
{
    if (row < 0 || row >= count()) return {};
    const PlaylistSummary &summary = m_items[row];
    return {{"id", summary.id}, {"name", summary.name}, {"description", summary.description},
            {"trackCount", summary.trackCount}, {"durationMs", summary.durationMs},
            {"covers", summary.covers}, {"owned", summary.owned}};
}

// ---- PlaylistService -----------------------------------------------------------------------

PlaylistService::PlaylistService(MusicProvider *provider, AccountService *account, QObject *parent)
    : QObject(parent), m_provider(provider), m_account(account)
{
    connect(m_provider, &MusicProvider::libraryPlaylistsLoaded, this,
            [this](quint64 token, const QVector<hm::RemotePlaylist> &playlists) {
        if (token != m_libraryToken) return;
        m_libraryToken = 0;
        m_loading = false;
        applyLibrary(playlists);
        if (m_pending.kind == PendingKind::Delete && m_pending.awaitingVerification) {
            bool stillPresent = indexOf(m_pending.playlistId) >= 0;
            if (stillPresent) finishPendingFailure("YouTube Music did not confirm deletion. The playlist is still present.");
            else finishPendingSuccess();
        }
        emit stateChanged();
    });
    connect(m_provider, &MusicProvider::remotePlaylistLoaded, this,
            [this](quint64 token, const hm::RemotePlaylist &playlist) { handleLoadedPlaylist(token, playlist); });
    connect(m_provider, &MusicProvider::playlistMutationFinished, this,
            [this](quint64 token, const QString &playlistId, const QString &createdId) {
        if (token != m_pending.token) return;
        if (m_pending.kind == PendingKind::Create && !createdId.isEmpty()) m_pending.playlistId = createdId;
        if (m_pending.kind == PendingKind::Delete) {
            m_pending.awaitingVerification = true;
            m_loading = true;
            m_libraryToken = m_provider->loadLibraryPlaylists();
            emit stateChanged();
            return;
        }
        requestVerification();
    });
    connect(m_provider, &MusicProvider::failed, this,
            [this](quint64 token, const hm::ApiError &error) { handleProviderFailure(token, error); });
    connect(m_account, &AccountService::accountChanged, this, [this] {
        if (m_account->connected()) {
            if (!m_loading) refresh();
            return;
        }
        if (m_account->state() == "expired") m_state = SyncState::AuthenticationRequired;
        else if (m_account->state() != "restoring" && m_account->state() != "connecting") m_state = SyncState::Disconnected;
        if (m_state == SyncState::AuthenticationRequired || m_state == SyncState::Disconnected) {
            m_loading = false;
            m_openLoading = false;
            m_lists.clear();
            m_listModel.setSummaries({});
            m_open.clear();
            m_viewMap.clear();
        }
        emit openChanged();
        emit stateChanged();
    });

    if (m_account->connected()) refresh();
}

QString PlaylistService::state() const
{
    switch (m_state) {
    case SyncState::Disconnected: return "disconnected";
    case SyncState::Loading: return "loading";
    case SyncState::Ready: return "ready";
    case SyncState::Empty: return "empty";
    case SyncState::Error: return "error";
    case SyncState::AuthenticationRequired: return "auth-error";
    }
    return "error";
}

bool PlaylistService::ensureConnected(const QString &operation)
{
    if (m_account->connected()) return true;
    emit message(QStringLiteral("Connect your YouTube Music account before %1.").arg(operation));
    return false;
}

int PlaylistService::indexOf(const QString &id) const
{
    for (int index = 0; index < m_lists.size(); ++index)
        if (m_lists[index].id == id) return index;
    return -1;
}

PlaylistSummary PlaylistService::summaryOf(const hm::RemotePlaylist &playlist) const
{
    PlaylistSummary summary;
    summary.id = playlist.id;
    summary.name = playlist.name;
    summary.description = playlist.description;
    summary.trackCount = playlist.trackCount;
    summary.durationMs = playlist.durationMs;
    summary.covers = playlist.covers;
    summary.owned = playlist.owned;
    return summary;
}

QVariantMap PlaylistService::infoAt(int index) const
{
    return index < 0 || index >= m_lists.size() ? QVariantMap{} : m_listModel.get(index);
}

QVariantMap PlaylistService::info(const QString &id) const
{
    return infoAt(indexOf(id));
}

QVariantMap PlaylistService::openInfo() const
{
    return info(m_openId);
}

void PlaylistService::replacePlaylist(const hm::RemotePlaylist &playlist)
{
    int index = indexOf(playlist.id);
    if (index < 0) {
        m_lists << playlist;
        QVector<PlaylistSummary> summaries;
        summaries.reserve(m_lists.size());
        for (const auto &item : std::as_const(m_lists)) summaries << summaryOf(item);
        m_listModel.setSummaries(summaries);
        return;
    }
    m_lists[index] = playlist;
    m_listModel.updateSummary(index, summaryOf(playlist));
}

void PlaylistService::applyLibrary(const QVector<hm::RemotePlaylist> &playlists)
{
    QHash<QString, hm::RemotePlaylist> detailed;
    for (const hm::RemotePlaylist &old : std::as_const(m_lists)) {
        if (!old.tracks.isEmpty()) detailed.insert(old.id, old);
    }

    m_lists = playlists;
    for (hm::RemotePlaylist &playlist : m_lists) {
        const auto cached = detailed.constFind(playlist.id);
        if (cached == detailed.cend()) continue;
        playlist.tracks = cached->tracks;
        if (playlist.trackCount == 0) playlist.trackCount = cached->trackCount;
        if (playlist.durationMs == 0) playlist.durationMs = cached->durationMs;
        if (playlist.covers.isEmpty()) playlist.covers = cached->covers;
    }

    QVector<PlaylistSummary> summaries;
    summaries.reserve(m_lists.size());
    for (const hm::RemotePlaylist &playlist : std::as_const(m_lists)) summaries << summaryOf(playlist);
    m_listModel.setSummaries(summaries);
    m_state = m_lists.isEmpty() ? SyncState::Empty : SyncState::Ready;
    m_error.clear();
}

void PlaylistService::refresh()
{
    if (!ensureConnected("refreshing playlists")) {
        m_state = SyncState::Disconnected;
        emit stateChanged();
        return;
    }
    if (m_loading) return;
    m_loading = true;
    m_state = SyncState::Loading;
    m_error.clear();
    m_libraryToken = m_provider->loadLibraryPlaylists();
    emit stateChanged();
}

bool PlaylistService::contains(const QString &id, const QString &videoId) const
{
    const int index = indexOf(id);
    if (index < 0) return false;
    return std::any_of(m_lists[index].tracks.cbegin(), m_lists[index].tracks.cend(),
                       [&](const hm::Track &track) { return track.videoId == videoId; });
}

QVariantList PlaylistService::tracksOf(const QString &id) const
{
    QVariantList tracks;
    const int index = indexOf(id);
    if (index < 0) return tracks;
    for (const hm::Track &track : m_lists[index].tracks) tracks << hm::toVariant(track);
    return tracks;
}

void PlaylistService::loadOpenPlaylist(const QString &id)
{
    if (!ensureConnected("opening a playlist")) return;
    m_openLoading = true;
    m_openToken = m_provider->loadPlaylist(id);
    emit openChanged();
}

void PlaylistService::open(const QString &id)
{
    if (indexOf(id) < 0) return;
    if (m_openId != id) {
        m_openId = id;
        m_sortKey = 0;
        m_ascending = true;
        emit sortChanged();
    }
    m_open.clear();
    m_viewMap.clear();
    loadOpenPlaylist(id);
    emit openChanged();
}

void PlaylistService::close()
{
    if (m_openId.isEmpty()) return;
    m_openId.clear();
    m_open.clear();
    m_viewMap.clear();
    m_openLoading = false;
    emit openChanged();
}

void PlaylistService::play(const QString &id, bool shuffle)
{
    if (indexOf(id) < 0 || !ensureConnected("playing a playlist")) return;
    m_pendingPlayback = true;
    m_pendingPlaybackShuffle = shuffle;
    open(id);
}

void PlaylistService::beginPending(Pending pending, quint64 token)
{
    m_pending = std::move(pending);
    m_pending.token = token;
    m_error.clear();
    emit stateChanged();
    emit openChanged();
}

void PlaylistService::create(const QString &name, const QString &description, const QVariantList &tracks)
{
    if (!ensureConnected("creating a playlist") || syncing()) return;
    QVector<hm::Track> initial;
    QSet<QString> seen;
    for (const QVariant &value : tracks) {
        const hm::Track track = hm::trackFromVariant(value.toMap());
        if (track.isValid() && !seen.contains(track.videoId)) { seen.insert(track.videoId); initial << track; }
    }
    const QString title = name.simplified().isEmpty() ? QStringLiteral("Untitled Playlist") : name.simplified();
    Pending pending;
    pending.kind = PendingKind::Create;
    pending.name = title;
    pending.description = description.trimmed();
    pending.tracks = initial;
    beginPending(pending, m_provider->createPlaylist(title, pending.description, initial));
    emit message("Creating playlist in YouTube Music…");
}

void PlaylistService::edit(const QString &id, const QString &name, const QString &description)
{
    if (!ensureConnected("editing a playlist") || syncing()) return;
    if (indexOf(id) < 0 || name.simplified().isEmpty()) return;
    Pending pending;
    pending.kind = PendingKind::Edit;
    pending.playlistId = id;
    pending.name = name.simplified();
    pending.description = description.trimmed();
    beginPending(pending, m_provider->updatePlaylist(id, pending.name, pending.description));
    emit message("Saving changes to YouTube Music…");
}

void PlaylistService::remove(const QString &id)
{
    if (!ensureConnected("deleting a playlist") || syncing() || indexOf(id) < 0) return;
    Pending pending;
    pending.kind = PendingKind::Delete;
    pending.playlistId = id;
    beginPending(pending, m_provider->deletePlaylist(id));
    emit message("Deleting playlist from YouTube Music…");
}

int PlaylistService::addTracks(const QString &id, const QVariantList &tracks)
{
    if (!ensureConnected("adding songs") || syncing() || indexOf(id) < 0) return 0;
    QVector<hm::Track> requested;
    QSet<QString> seen;
    for (const QVariant &value : tracks) {
        const hm::Track track = hm::trackFromVariant(value.toMap());
        if (track.isValid() && !seen.contains(track.videoId)) { seen.insert(track.videoId); requested << track; }
    }
    if (requested.isEmpty()) return 0;

    // Always read the target playlist before a write. This avoids adding a song
    // that exists in a stale card/model and supplies current setVideoIds.
    Pending pending;
    pending.kind = PendingKind::PrepareAdd;
    pending.playlistId = id;
    pending.tracks = requested;
    beginPending(pending, m_provider->loadPlaylist(id));
    emit message("Checking the playlist before adding songs…");
    return requested.size();
}

int PlaylistService::addTrack(const QString &id, const QVariantMap &track)
{
    return addTracks(id, {track});
}

int PlaylistService::addModel(const QString &id, QObject *songModel)
{
    const auto *songs = qobject_cast<SongModel *>(songModel);
    if (!songs) return 0;
    QVariantList tracks;
    for (const hm::Track &track : songs->tracks()) tracks << hm::toVariant(track);
    return addTracks(id, tracks);
}

void PlaylistService::removeAt(int viewIndex)
{
    if (!ensureConnected("removing a song") || syncing()) return;
    const int index = indexOf(m_openId);
    if (index < 0 || viewIndex < 0 || viewIndex >= m_open.count()) return;
    const int source = m_sortKey == 0 ? viewIndex : m_viewMap.value(viewIndex, -1);
    if (source < 0 || source >= m_lists[index].tracks.size()) return;
    const hm::Track track = m_lists[index].tracks[source];
    if (track.setVideoId.isEmpty()) {
        emit message("Refreshing the playlist before removing that song…");
        loadOpenPlaylist(m_openId);
        return;
    }
    Pending pending;
    pending.kind = PendingKind::Remove;
    pending.playlistId = m_openId;
    pending.tracks = {track};
    beginPending(pending, m_provider->removePlaylistItems(m_openId, pending.tracks));
    emit message("Removing song from YouTube Music…");
}

void PlaylistService::move(int from, int to)
{
    if (!ensureConnected("reordering a playlist") || syncing() || m_sortKey != 0) return;
    const int index = indexOf(m_openId);
    if (index < 0 || from == to || from < 0 || to < 0
            || from >= m_lists[index].tracks.size() || to >= m_lists[index].tracks.size()) return;
    QVector<hm::Track> desired = m_lists[index].tracks;
    desired.move(from, to);
    Pending pending;
    pending.kind = PendingKind::Reorder;
    pending.playlistId = m_openId;
    pending.desiredOrder = desired;
    beginPending(pending, m_provider->reorderPlaylist(m_openId, desired));
    emit message("Saving playlist order to YouTube Music…");
}

QVector<int> PlaylistService::sortedOrder(const hm::RemotePlaylist &playlist) const
{
    QVector<int> order(playlist.tracks.size());
    for (int index = 0; index < order.size(); ++index) order[index] = index;
    if (m_sortKey == 0) return order;
    const auto text = [&](int index) -> const QString & {
        const hm::Track &track = playlist.tracks[index];
        return m_sortKey == 1 ? track.title : m_sortKey == 2 ? track.artist : track.album;
    };
    const auto less = [&](int left, int right) {
        if (m_sortKey == 4) return playlist.tracks[left].durationMs < playlist.tracks[right].durationMs;
        return QString::localeAwareCompare(text(left), text(right)) < 0;
    };
    if (m_ascending) std::stable_sort(order.begin(), order.end(), less);
    else std::stable_sort(order.begin(), order.end(), [&](int left, int right) { return less(right, left); });
    return order;
}

void PlaylistService::rebuildOpen()
{
    const int index = indexOf(m_openId);
    if (index < 0) {
        m_open.clear();
        m_viewMap.clear();
        return;
    }
    const hm::RemotePlaylist &playlist = m_lists[index];
    m_viewMap = sortedOrder(playlist);
    QVector<hm::Track> tracks;
    tracks.reserve(m_viewMap.size());
    for (int source : std::as_const(m_viewMap)) tracks << playlist.tracks[source];
    m_open.setTracks(tracks);
}

void PlaylistService::setSort(int key, bool ascending)
{
    key = qBound(0, key, 4);
    if (key == m_sortKey && ascending == m_ascending) return;
    m_sortKey = key;
    m_ascending = ascending;
    rebuildOpen();
    emit sortChanged();
}

void PlaylistService::commitSortAsOrder()
{
    if (!ensureConnected("saving playlist order") || syncing() || m_sortKey == 0) return;
    const int index = indexOf(m_openId);
    if (index < 0) return;
    QVector<hm::Track> desired;
    desired.reserve(m_viewMap.size());
    for (int source : std::as_const(m_viewMap)) desired << m_lists[index].tracks[source];
    Pending pending;
    pending.kind = PendingKind::Reorder;
    pending.playlistId = m_openId;
    pending.desiredOrder = desired;
    beginPending(pending, m_provider->reorderPlaylist(m_openId, desired));
    emit message("Saving playlist order to YouTube Music…");
}

void PlaylistService::requestVerification()
{
    if (m_pending.playlistId.isEmpty()) {
        finishPendingFailure("YouTube Music did not return a playlist ID. Check your library before trying again.");
        return;
    }
    m_pending.awaitingVerification = true;
    m_pending.token = m_provider->loadPlaylist(m_pending.playlistId);
    emit message("Confirming the change with YouTube Music…");
    emit stateChanged();
}

void PlaylistService::finishPendingSuccess()
{
    const Pending finished = m_pending;
    m_pending = {};
    emit stateChanged();
    emit openChanged();

    switch (finished.kind) {
    case PendingKind::Create:
        emit message("Playlist created and synchronized with YouTube Music.");
        emit created(finished.playlistId, !finished.tracks.isEmpty());
        break;
    case PendingKind::Delete: {
        const int index = indexOf(finished.playlistId);
        if (index >= 0) {
            m_lists.removeAt(index);
            m_listModel.removeSummary(index);
        }
        if (m_openId == finished.playlistId) close();
        emit removed(finished.playlistId);
        emit message("Playlist deleted from YouTube Music.");
        break;
    }
    case PendingKind::PrepareAdd:
        emit message("Those songs are already in the YouTube Music playlist.");
        break;
    default:
        emit message("Synced with YouTube Music.");
        break;
    }
    // Re-read summaries after every acknowledged change to reflect edits made
    // elsewhere and updated library ordering/counts.
    refresh();
}

void PlaylistService::finishPendingFailure(const QString &message, bool refreshToReconcile)
{
    const QString playlistId = m_pending.playlistId;
    m_pending = {};
    m_error = message;
    if (!message.isEmpty()) emit this->message(message);
    emit stateChanged();
    emit openChanged();
    if (refreshToReconcile) {
        if (!playlistId.isEmpty() && playlistId == m_openId) loadOpenPlaylist(playlistId);
        else refresh();
    }
}

void PlaylistService::setError(const hm::ApiError &error)
{
    m_error = hm::userMessage(error);
    if (error.kind == hm::ApiError::AuthRequired) {
        m_state = SyncState::AuthenticationRequired;
        m_account->sessionValidationFailed(m_error, true);
    } else {
        m_state = SyncState::Error;
    }
}

void PlaylistService::handleProviderFailure(quint64 token, const hm::ApiError &error)
{
    if (token == m_libraryToken) {
        m_libraryToken = 0;
        m_loading = false;
        setError(error);
        emit stateChanged();
        return;
    }
    if (token == m_openToken) {
        m_openToken = 0;
        m_openLoading = false;
        setError(error);
        emit openChanged();
        emit stateChanged();
        return;
    }
    if (token != m_pending.token) return;

    // Mutations are deliberately not retried. A timeout might mean YouTube Music
    // applied the change but the response was lost; reload instead of issuing a
    // duplicate add/move request.
    const bool uncertain = error.kind == hm::ApiError::Network || error.kind == hm::ApiError::RateLimited;
    const QString prefix = uncertain ? "Couldn't confirm the change. The playlist is being refreshed; don't retry yet. " : QString{};
    finishPendingFailure(prefix + hm::userMessage(error), uncertain);
}

void PlaylistService::handleLoadedPlaylist(quint64 token, const hm::RemotePlaylist &playlist)
{
    if (token == m_openToken) {
        m_openToken = 0;
        m_openLoading = false;
        replacePlaylist(playlist);
        if (playlist.id == m_openId) rebuildOpen();
        if (m_pendingPlayback && playlist.id == m_openId) {
            const bool shuffle = m_pendingPlaybackShuffle;
            m_pendingPlayback = false;
            emit playbackReady(shuffle);
        }
        emit openChanged();
    }

    if (token != m_pending.token) return;
    if (m_pending.kind == PendingKind::PrepareAdd) {
        replacePlaylist(playlist);
        QSet<QString> existing;
        for (const hm::Track &track : playlist.tracks) existing.insert(track.videoId);
        QVector<hm::Track> additions;
        for (const hm::Track &track : std::as_const(m_pending.tracks)) {
            if (!existing.contains(track.videoId)) additions << track;
        }
        if (additions.isEmpty()) {
            finishPendingSuccess();
            return;
        }
        m_pending.kind = PendingKind::Add;
        m_pending.tracks = additions;
        m_pending.token = m_provider->addPlaylistItems(m_pending.playlistId, additions);
        emit message(additions.size() == 1 ? "Adding song to YouTube Music…" : "Adding songs to YouTube Music…");
        emit stateChanged();
        return;
    }

    if (!m_pending.awaitingVerification) return;
    replacePlaylist(playlist);
    bool verified = true;
    switch (m_pending.kind) {
    case PendingKind::Create:
        verified = !playlist.name.isEmpty();
        break;
    case PendingKind::Edit:
        verified = playlist.name == m_pending.name && playlist.description == m_pending.description;
        break;
    case PendingKind::Add:
        for (const hm::Track &track : std::as_const(m_pending.tracks)) {
            const bool present = std::any_of(playlist.tracks.cbegin(), playlist.tracks.cend(),
                                             [&](const hm::Track &actual) { return actual.videoId == track.videoId; });
            if (!present) { verified = false; break; }
        }
        break;
    case PendingKind::Remove:
        for (const hm::Track &track : std::as_const(m_pending.tracks)) {
            const bool present = std::any_of(playlist.tracks.cbegin(), playlist.tracks.cend(),
                                             [&](const hm::Track &actual) { return actual.setVideoId == track.setVideoId; });
            if (present) { verified = false; break; }
        }
        break;
    case PendingKind::Reorder:
        if (playlist.tracks.size() != m_pending.desiredOrder.size()) verified = false;
        for (int index = 0; verified && index < playlist.tracks.size(); ++index)
            verified = playlist.tracks[index].setVideoId == m_pending.desiredOrder[index].setVideoId;
        break;
    default: break;
    }
    if (!verified) {
        finishPendingFailure("YouTube Music did not confirm the change. The screen was refreshed with its current data.");
        return;
    }
    if (playlist.id == m_openId) rebuildOpen();
    finishPendingSuccess();
}
