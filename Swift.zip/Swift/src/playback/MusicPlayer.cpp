#include "MusicPlayer.h"
#include "services/SettingsService.h"
#include <QJsonArray>
#include <QJsonDocument>
#include <QLoggingCategory>
#include <QRandomGenerator>
#include <QSettings>
#include <cmath>

Q_LOGGING_CATEGORY(lcPlayer, "swift.player")

MusicPlayer::MusicPlayer(MusicProvider *provider, SettingsService *settings, QObject *parent)
    : QObject(parent), m_provider(provider), m_settings(settings), m_queue(new QueueModel(this))
{
    m_player.setAudioOutput(&m_audio);

    connect(&m_player, &QMediaPlayer::playbackStateChanged, this, [this](QMediaPlayer::PlaybackState s) {
        emit playingChanged();
        if (s == QMediaPlayer::PlayingState && !m_startedLogged) {
            m_startedLogged = true;
            m_failStreak = 0;
            emit trackStarted(m_queue->currentTrack());
        }
    });
    connect(&m_player, &QMediaPlayer::positionChanged, this, &MusicPlayer::positionChanged);
    connect(&m_player, &QMediaPlayer::durationChanged, this, &MusicPlayer::durationChanged);
    connect(&m_player, &QMediaPlayer::mediaStatusChanged, this, &MusicPlayer::onMediaStatus);
    connect(&m_player, &QMediaPlayer::errorOccurred, this, &MusicPlayer::onPlayerError);
    connect(m_provider, &MusicProvider::streamResolved, this, &MusicPlayer::onStreamResolved);
    connect(m_provider, &MusicProvider::failed, this, &MusicPlayer::onProviderFailed);

    m_saveTimer.setInterval(5000);
    connect(&m_saveTimer, &QTimer::timeout, this, [this] { if (playing()) saveState(); });
    m_saveTimer.start();

    setVolume(float(m_settings->get("volume").toDouble()));
    restoreState();
}

qint64 MusicPlayer::position() const
{
    if (m_player.source().isEmpty() && m_pendingSeek > 0) return m_pendingSeek;
    return m_player.position();
}

qint64 MusicPlayer::duration() const
{
    const qint64 d = m_player.duration();
    return d > 0 ? d : m_queue->currentTrack().durationMs;
}

void MusicPlayer::setVolume(float v)
{
    v = qBound(0.0f, v, 1.0f);
    m_volume = v;
    // The slider is perceptual; map it to a gentler curve for the audio device.
    m_audio.setVolume(std::pow(v, 2.5f));
    m_settings->set("volume", double(v));
    emit volumeChanged();
}

void MusicPlayer::setShuffle(bool on)
{
    if (m_shuffle == on) return;
    m_shuffle = on;
    m_history.clear();
    emit shuffleChanged();
}

void MusicPlayer::setRepeatMode(int mode)
{
    mode = qBound(0, mode, 2);
    if (m_repeat == mode) return;
    m_repeat = mode;
    emit repeatModeChanged();
}

void MusicPlayer::play()
{
    if (!hasTrack()) return;
    if (m_player.source().isEmpty())
        loadCurrent(true, m_pendingSeek);
    else
        m_player.play();
}

void MusicPlayer::pause()
{
    m_player.pause();
    saveState();
}

void MusicPlayer::togglePlayback()
{
    if (playing()) pause(); else play();
}

void MusicPlayer::seek(qint64 pos)
{
    pos = qMax<qint64>(0, pos);
    if (m_player.source().isEmpty()) {
        m_pendingSeek = pos;
        emit positionChanged();
    } else {
        m_player.setPosition(pos);
    }
}

void MusicPlayer::next()
{
    if (!advance()) {
        m_player.stop();
        emit positionChanged();
    }
}

void MusicPlayer::previous()
{
    const int n = m_queue->count();
    if (n == 0) return;
    if (position() > 3000) return seek(0);

    int target = -1;
    if (m_shuffle && !m_history.isEmpty()) target = m_history.takeLast();
    else if (m_queue->currentIndex() > 0) target = m_queue->currentIndex() - 1;
    else if (m_repeat == 1) target = n - 1;

    if (target < 0) return seek(0);
    setCurrent(target, true);
}

bool MusicPlayer::advance()
{
    const int n = m_queue->count();
    if (n == 0) return false;
    const int cur = m_queue->currentIndex();
    int target = -1;
    if (m_shuffle && n > 1) {
        do { target = QRandomGenerator::global()->bounded(n); } while (target == cur);
    } else if (cur + 1 < n) {
        target = cur + 1;
    } else if (m_repeat == 1) {
        target = 0;
    }
    if (target < 0) return false;
    m_history.append(cur);
    if (m_history.size() > 100) m_history.removeFirst();
    setCurrent(target, true);
    return true;
}

void MusicPlayer::setCurrent(int index, bool autoplay)
{
    m_retried = false;
    m_queue->setCurrentIndex(index);
    loadCurrent(autoplay);
}

void MusicPlayer::loadCurrent(bool autoplay, qint64 seekTo)
{
    const hm::Track t = m_queue->currentTrack();
    if (!t.isValid()) return;
    m_autoplay = autoplay;
    m_pendingSeek = seekTo;
    m_startedLogged = false;
    setError({});
    setLoading(true);
    m_player.stop();
    m_player.setSource({});
    m_token = m_provider->resolveStream(t.videoId);
    emit trackChanged();
    emit positionChanged();
    emit durationChanged();
    saveState();
}

void MusicPlayer::onStreamResolved(quint64 token, const QString &, const QUrl &url)
{
    if (token != m_token) return;
    m_player.setSource(url);
    if (m_autoplay) m_player.play();
}

void MusicPlayer::onProviderFailed(quint64 token, const hm::ApiError &err)
{
    if (token != m_token) return;
    setLoading(false);
    setError(hm::userMessage(err));
    qCWarning(lcPlayer) << "resolve failed:" << err.message;

    // Skip over unavailable tracks, but stop after a few in a row.
    if (err.kind == hm::ApiError::Unavailable && m_autoplay
            && m_queue->count() > 1 && ++m_failStreak < 3) {
        QTimer::singleShot(900, this, [this, token] { if (token == m_token) advance(); });
    }
}

void MusicPlayer::onMediaStatus(QMediaPlayer::MediaStatus status)
{
    switch (status) {
    case QMediaPlayer::LoadedMedia:
    case QMediaPlayer::BufferedMedia:
        setLoading(false);
        if (m_pendingSeek > 0) {
            m_player.setPosition(m_pendingSeek);
            m_pendingSeek = 0;
        }
        break;
    case QMediaPlayer::EndOfMedia:
        if (m_repeat == 2) {
            m_player.setPosition(0);
            m_player.play();
        } else if (!advance()) {
            m_player.stop();
        }
        break;
    default:
        break;
    }
}

void MusicPlayer::onPlayerError(QMediaPlayer::Error, const QString &text)
{
    qCWarning(lcPlayer) << "media error:" << text;
    // Stream URLs expire; retry once with a fresh one from the current position.
    if (!m_retried && hasTrack()) {
        m_retried = true;
        loadCurrent(true, m_player.position());
        return;
    }
    setLoading(false);
    setError("Playback failed. Try the track again.");
}

void MusicPlayer::playFrom(QObject *model, int index)
{
    if (model == m_queue) return playQueueIndex(index);
    auto *songs = qobject_cast<SongModel *>(model);
    if (!songs || index < 0 || index >= songs->count()) return;
    m_history.clear();
    m_queue->reset(songs->tracks());
    setCurrent(index, true);
}

void MusicPlayer::playTracks(const QVariantList &tracks, int index, bool shuffle)
{
    QVector<hm::Track> list;
    for (const QVariant &v : tracks) {
        const hm::Track t = hm::trackFromVariant(v.toMap());
        if (t.isValid()) list << t;
    }
    if (list.isEmpty()) return;
    setShuffle(shuffle);   // also clears the shuffle history
    if (shuffle) index = QRandomGenerator::global()->bounded(int(list.size()));
    index = qBound(0, index, int(list.size()) - 1);
    m_queue->reset(list);
    setCurrent(index, true);
}

void MusicPlayer::playQueueIndex(int index)
{
    if (index < 0 || index >= m_queue->count()) return;
    setCurrent(index, true);
}

void MusicPlayer::enqueue(const QVariantMap &track)
{
    const hm::Track t = hm::trackFromVariant(track);
    if (!t.isValid()) return;
    const bool wasEmpty = m_queue->count() == 0;
    m_queue->appendTrack(t);
    if (wasEmpty) {
        m_queue->setCurrentIndex(0);
        emit trackChanged();
    }
}

void MusicPlayer::playNext(const QVariantMap &track)
{
    const hm::Track t = hm::trackFromVariant(track);
    if (!t.isValid()) return;
    if (m_queue->count() == 0) return enqueue(track);
    m_queue->insertTrack(m_queue->currentIndex() + 1, t);
}

void MusicPlayer::removeFromQueue(int index)
{
    if (m_queue->removeTracked(index)) {
        if (m_queue->count() == 0) {
            clearQueue();
        } else {
            loadCurrent(playing());
        }
    }
}

void MusicPlayer::moveInQueue(int from, int to)
{
    m_queue->moveTracked(from, to);
}

void MusicPlayer::clearQueue()
{
    m_token = 0;
    m_player.stop();
    m_player.setSource({});
    m_pendingSeek = 0;
    m_history.clear();
    m_queue->reset({});
    setLoading(false);
    emit trackChanged();
    emit positionChanged();
    emit durationChanged();
    saveState();
}

void MusicPlayer::setLoading(bool on)
{
    if (m_loading == on) return;
    m_loading = on;
    emit loadingChanged();
}

void MusicPlayer::setError(const QString &msg)
{
    if (m_error == msg) return;
    m_error = msg;
    emit errorChanged();
}

void MusicPlayer::saveState()
{
    QSettings s;
    QJsonArray arr;
    for (const auto &t : m_queue->tracks()) arr.append(t.toJson());
    s.setValue("session/queue", QJsonDocument(arr).toJson(QJsonDocument::Compact));
    s.setValue("session/index", m_queue->currentIndex());
    s.setValue("session/position", position());
    s.setValue("session/shuffle", m_shuffle);
    s.setValue("session/repeat", m_repeat);
}

void MusicPlayer::restoreState()
{
    QSettings s;
    setShuffle(s.value("session/shuffle", false).toBool());
    setRepeatMode(s.value("session/repeat", 0).toInt());
    if (!m_settings->get("restoreSession").toBool()) return;

    QVector<hm::Track> tracks;
    for (const auto &v : QJsonDocument::fromJson(s.value("session/queue").toByteArray()).array()) {
        auto t = hm::Track::fromJson(v.toObject());
        if (t.isValid()) tracks << t;
    }
    if (tracks.isEmpty()) return;
    const int idx = qBound(0, s.value("session/index", 0).toInt(), int(tracks.size()) - 1);
    m_queue->reset(tracks);
    m_queue->setCurrentIndex(idx);
    m_pendingSeek = s.value("session/position", 0).toLongLong();
    emit trackChanged();
}
