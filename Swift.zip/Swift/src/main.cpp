#include "AppController.h"
#include "api/YouTubeMusicClient.h"
#include "playback/MusicPlayer.h"
#include "services/CacheService.h"
#include "services/LibraryService.h"
#include "services/PlaylistService.h"
#include "services/SettingsService.h"
#include <QGuiApplication>
#include <QNetworkAccessManager>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QGuiApplication::setOrganizationName("Swift");
    QGuiApplication::setApplicationName("Swift");
    QGuiApplication::setApplicationVersion("0.1.0");
    QQuickStyle::setStyle("Basic"); // every control is custom drawn; Basic avoids native-style overrides

    SettingsService settings;
    CacheService cache(&settings);
    LibraryService library;
    PlaylistService playlists;

    QNetworkAccessManager apiNetwork;
    YouTubeMusicClient provider(&apiNetwork, &settings);

    MusicPlayer player(&provider, &settings);
    AppController controller(&provider, &settings);

    QObject::connect(&player, &MusicPlayer::trackStarted, &library, &LibraryService::addRecent);
    QObject::connect(&app, &QGuiApplication::aboutToQuit, &player, &MusicPlayer::saveState);

    QQmlApplicationEngine engine; // declared last so it is destroyed first
    engine.setNetworkAccessManagerFactory(&cache);
    QQmlContext *ctx = engine.rootContext();
    ctx->setContextProperty("app", &controller);
    ctx->setContextProperty("player", &player);
    ctx->setContextProperty("library", &library);
    ctx->setContextProperty("playlists", &playlists);
    ctx->setContextProperty("settings", &settings);
    ctx->setContextProperty("cache", &cache);

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app,
                     [] { QCoreApplication::exit(-1); }, Qt::QueuedConnection);
    engine.loadFromModule("Swift", "Main");
    return app.exec();
}
