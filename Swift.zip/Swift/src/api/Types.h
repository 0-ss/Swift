#pragma once
#include <QJsonObject>
#include <QString>
#include <QVariantMap>
#include <QVector>

namespace hm {

struct Track {
    QString videoId, title, artist, album, artworkUrl;
    qint64 durationMs = 0;

    bool isValid() const { return !videoId.isEmpty(); }
    QJsonObject toJson() const;
    static Track fromJson(const QJsonObject &o);
};

enum class CollectionKind { Unknown, Album, Artist, Playlist };
QString toString(CollectionKind k);
CollectionKind collectionKindFromString(const QString &s);

struct Collection {
    QString browseId, title, subtitle, artworkUrl;
    CollectionKind kind = CollectionKind::Unknown;
};

enum class SearchFilter { All = 0, Songs, Albums, Artists, Playlists };

struct SearchResults {
    QVector<Track> tracks;
    QVector<Collection> collections;
};

struct ApiError {
    enum Kind { None, Network, RateLimited, InvalidResponse, AuthRequired, Unavailable, Unknown };
    Kind kind = None;
    QString message;
    int retryAfterSec = 0;
    explicit operator bool() const { return kind != None; }
};

// Short, user-facing description that tells the person what to do next.
QString userMessage(const ApiError &e);

QVariantMap toVariant(const Track &t);
Track trackFromVariant(const QVariantMap &m);
QVariantMap toVariant(const Collection &c);
Collection collectionFromVariant(const QVariantMap &m);

} // namespace hm
