#pragma once
#include "Types.h"
#include <QObject>
#include <QUrl>

// Everything the app needs from a music backend. The UI and player only know
// this interface, so the unofficial YouTube Music implementation can be swapped.
// Each call returns a token; results arrive via signals carrying the same token,
// which lets callers ignore stale responses.
class MusicProvider : public QObject
{
    Q_OBJECT
public:
    using QObject::QObject;

    virtual quint64 search(const QString &query, hm::SearchFilter filter) = 0;
    virtual quint64 loadCollection(const hm::Collection &collection) = 0;
    virtual quint64 resolveStream(const QString &videoId) = 0;

signals:
    void searchFinished(quint64 token, const hm::SearchResults &results);
    void collectionLoaded(quint64 token, const hm::SearchResults &results);
    void streamResolved(quint64 token, const QString &videoId, const QUrl &url);
    void failed(quint64 token, const hm::ApiError &error);

protected:
    quint64 newToken() { return ++m_token; }

private:
    quint64 m_token = 0;
};
