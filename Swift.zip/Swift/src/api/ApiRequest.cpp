#include "ApiRequest.h"
#include <QJsonDocument>
#include <QLoggingCategory>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QTimer>

Q_LOGGING_CATEGORY(lcApi, "swift.api")

namespace {
constexpr int kMaxRetries = 2;
constexpr int kTimeoutMs = 15000;
}

ApiRequest::ApiRequest(QNetworkAccessManager *nam, QObject *parent)
    : QObject(parent), m_nam(nam)
{
}

void ApiRequest::post(const QUrl &url, const QJsonObject &body, const Headers &headers,
                      Callback callback, int attempt)
{
    QNetworkRequest req(url);
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    req.setTransferTimeout(kTimeoutMs);
    for (const auto &h : headers)
        req.setRawHeader(h.first, h.second);

    QNetworkReply *reply = m_nam->post(req, QJsonDocument(body).toJson(QJsonDocument::Compact));

    connect(reply, &QNetworkReply::finished, this, [=, this]() {
        reply->deleteLater();
        const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        const QByteArray payload = reply->readAll();

        const bool retryable = status == 429 || status >= 500
                || (status == 0 && reply->error() != QNetworkReply::NoError);
        if (retryable && attempt < kMaxRetries) {
            int delayMs = 500 * (1 << attempt);
            if (status == 429) {
                const int ra = reply->rawHeader("Retry-After").toInt();
                if (ra > 0) delayMs = qMin(ra, 10) * 1000;
            }
            qCInfo(lcApi) << "retrying" << url.path() << "after" << delayMs << "ms (status" << status << ")";
            QTimer::singleShot(delayMs, this, [=, this] { post(url, body, headers, callback, attempt + 1); });
            return;
        }

        hm::ApiError err;
        if (status == 429) {
            err = {hm::ApiError::RateLimited, "Rate limited", reply->rawHeader("Retry-After").toInt()};
        } else if (status == 401 || status == 403) {
            err = {hm::ApiError::AuthRequired, "Authentication failed", 0};
        } else if (status == 0 || reply->error() != QNetworkReply::NoError) {
            err = {hm::ApiError::Network, reply->errorString(), 0};
        }
        if (err) {
            qCWarning(lcApi) << url.path() << "failed:" << err.message;
            callback({}, err);
            return;
        }

        QJsonParseError pe;
        const QJsonDocument doc = QJsonDocument::fromJson(payload, &pe);
        if (pe.error != QJsonParseError::NoError || !doc.isObject()) {
            callback({}, {hm::ApiError::InvalidResponse, pe.errorString(), 0});
            return;
        }
        const QJsonObject root = doc.object();
        if (root.contains("error")) {
            const int code = root["error"].toObject()["code"].toInt();
            const QString msg = root["error"].toObject()["message"].toString();
            const auto kind = (code == 401 || code == 403) ? hm::ApiError::AuthRequired
                            : code == 429 ? hm::ApiError::RateLimited : hm::ApiError::Unknown;
            callback({}, {kind, msg, 0});
            return;
        }
        callback(root, {});
    });
}
