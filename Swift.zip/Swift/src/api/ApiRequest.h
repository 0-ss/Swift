#pragma once
#include "Types.h"
#include <QList>
#include <QNetworkAccessManager>
#include <QObject>
#include <QPair>
#include <functional>

// Asynchronous JSON POST with timeout, bounded retry/backoff and error mapping.
class ApiRequest : public QObject
{
    Q_OBJECT
public:
    using Headers = QList<QPair<QByteArray, QByteArray>>;
    using Callback = std::function<void(QJsonObject, hm::ApiError)>;

    explicit ApiRequest(QNetworkAccessManager *nam, QObject *parent = nullptr);

    void post(const QUrl &url, const QJsonObject &body, const Headers &headers,
              Callback callback, int attempt = 0);

private:
    QNetworkAccessManager *m_nam;
};
