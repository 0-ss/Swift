#pragma once
#include "ApiRequest.h"
#include "MusicProvider.h"

class SettingsService;

// Provider backed by the unofficial InnerTube endpoints used by music.youtube.com.
// The endpoints and response shapes are undocumented and can change without notice;
// all of that knowledge lives in this class and its parser.
class YouTubeMusicClient : public MusicProvider
{
    Q_OBJECT
public:
    YouTubeMusicClient(QNetworkAccessManager *nam, SettingsService *settings, QObject *parent = nullptr);

    quint64 search(const QString &query, hm::SearchFilter filter) override;
    quint64 loadCollection(const hm::Collection &collection) override;
    quint64 resolveStream(const QString &videoId) override;

private:
    QJsonObject context() const;
    ApiRequest::Headers headers() const;
    QUrl endpoint(const QString &name) const;
    void resolveExternally(quint64 token, const QString &videoId);

    ApiRequest m_http;
    SettingsService *m_settings;
};
