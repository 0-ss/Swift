#include "Types.h"

namespace hm {

QJsonObject Track::toJson() const
{
    return {{"videoId", videoId}, {"title", title}, {"artist", artist},
            {"album", album}, {"artworkUrl", artworkUrl}, {"durationMs", durationMs}};
}

Track Track::fromJson(const QJsonObject &o)
{
    Track t;
    t.videoId = o["videoId"].toString();
    t.title = o["title"].toString();
    t.artist = o["artist"].toString();
    t.album = o["album"].toString();
    t.artworkUrl = o["artworkUrl"].toString();
    t.durationMs = qint64(o["durationMs"].toDouble());
    return t;
}

QString toString(CollectionKind k)
{
    switch (k) {
    case CollectionKind::Album: return "album";
    case CollectionKind::Artist: return "artist";
    case CollectionKind::Playlist: return "playlist";
    default: return "unknown";
    }
}

CollectionKind collectionKindFromString(const QString &s)
{
    if (s == "album") return CollectionKind::Album;
    if (s == "artist") return CollectionKind::Artist;
    if (s == "playlist") return CollectionKind::Playlist;
    return CollectionKind::Unknown;
}

QString userMessage(const ApiError &e)
{
    switch (e.kind) {
    case ApiError::None: return {};
    case ApiError::Network: return "Can't reach YouTube Music. Check your connection and try again.";
    case ApiError::RateLimited: return "Too many requests. Wait a moment, then try again.";
    case ApiError::InvalidResponse: return "YouTube Music sent a response Swift couldn't read.";
    case ApiError::AuthRequired: return "This needs a signed-in session. Add your cookie in Settings > Account.";
    case ApiError::Unavailable: return e.message.isEmpty() ? "This track isn't available." : e.message;
    case ApiError::Unknown: break;
    }
    return e.message.isEmpty() ? "Something went wrong." : e.message;
}

QVariantMap toVariant(const Track &t)
{
    return {{"videoId", t.videoId}, {"title", t.title}, {"artist", t.artist},
            {"album", t.album}, {"artworkUrl", t.artworkUrl}, {"durationMs", t.durationMs}};
}

Track trackFromVariant(const QVariantMap &m)
{
    Track t;
    t.videoId = m["videoId"].toString();
    t.title = m["title"].toString();
    t.artist = m["artist"].toString();
    t.album = m["album"].toString();
    t.artworkUrl = m["artworkUrl"].toString();
    t.durationMs = m["durationMs"].toLongLong();
    return t;
}

QVariantMap toVariant(const Collection &c)
{
    return {{"browseId", c.browseId}, {"title", c.title}, {"subtitle", c.subtitle},
            {"artworkUrl", c.artworkUrl}, {"kind", toString(c.kind)}};
}

Collection collectionFromVariant(const QVariantMap &m)
{
    Collection c;
    c.browseId = m["browseId"].toString();
    c.title = m["title"].toString();
    c.subtitle = m["subtitle"].toString();
    c.artworkUrl = m["artworkUrl"].toString();
    c.kind = collectionKindFromString(m["kind"].toString());
    return c;
}

} // namespace hm
