#include "YouTubeMusicClient.h"
#include "services/SettingsService.h"
#include <QCryptographicHash>
#include <QDate>
#include <QDateTime>
#include <QJsonArray>
#include <QProcess>
#include <QRegularExpression>
#include <QSet>
#include <QTimer>

using namespace hm;

namespace {

const QByteArray kOrigin = "https://music.youtube.com";

template<typename... K>
QJsonValue dig(const QJsonValue &start, K... keys)
{
    QJsonValue v = start;
    ((v = v.toObject().value(QLatin1String(keys))), ...);
    return v;
}

QString filterParams(SearchFilter f)
{
    switch (f) {
    case SearchFilter::Songs: return "EgWKAQIIAWoKEAkQBRAKEAMQBA==";
    case SearchFilter::Albums: return "EgWKAQIYAWoKEAkQChAFEAMQBA==";
    case SearchFilter::Artists: return "EgWKAQIgAWoKEAkQChAFEAMQBA==";
    case SearchFilter::Playlists: return "Eg-KAQwIABAAGAAgACgBMABqChAEEAMQCRAFEAo=";
    default: return {};
    }
}

QString bestThumb(const QJsonArray &thumbs)
{
    if (thumbs.isEmpty()) return {};
    QString url = thumbs.last().toObject()["url"].toString();
    static const QRegularExpression sizeSuffix("=w\\d+-h\\d+.*$");
    return url.replace(sizeSuffix, "=w544-h544-l90-rj");
}

// Splits a run list on "•" separator runs into display fragments.
QStringList splitRuns(const QJsonArray &runs)
{
    QStringList parts;
    QString cur;
    for (const auto &r : runs) {
        const QString t = r.toObject()["text"].toString();
        if (t.trimmed() == QStringLiteral("•")) {
            if (!cur.isEmpty()) parts << cur;
            cur.clear();
        } else {
            cur += t;
        }
    }
    if (!cur.isEmpty()) parts << cur;
    return parts;
}

bool isDuration(const QString &s)
{
    static const QRegularExpression re("^\\d{1,2}(:\\d{2}){1,2}$");
    return re.match(s).hasMatch();
}

qint64 parseDuration(const QString &s)
{
    qint64 seconds = 0;
    for (const QString &p : s.split(':'))
        seconds = seconds * 60 + p.toInt();
    return seconds * 1000;
}

CollectionKind kindFromPageType(const QString &pageType)
{
    if (pageType.contains("ALBUM")) return CollectionKind::Album;
    if (pageType.contains("ARTIST") || pageType.contains("USER_CHANNEL")) return CollectionKind::Artist;
    if (pageType.contains("PLAYLIST")) return CollectionKind::Playlist;
    return CollectionKind::Unknown;
}

QString pageTypeOf(const QJsonValue &navEndpoint)
{
    return dig(navEndpoint, "browseEndpoint", "browseEndpointContextSupportedConfigs",
               "browseEndpointContextMusicConfig", "pageType").toString();
}

void parseListItem(const QJsonObject &o, SearchResults &out)
{
    const QJsonArray flex = o["flexColumns"].toArray();
    auto runsAt = [&](int i) -> QJsonArray {
        return i < flex.size()
            ? dig(QJsonValue(flex[i]), "musicResponsiveListItemFlexColumnRenderer", "text", "runs").toArray()
            : QJsonArray{};
    };
    const QJsonArray titleRuns = runsAt(0);
    if (titleRuns.isEmpty()) return;

    const QString title = titleRuns[0].toObject()["text"].toString();
    QString videoId = dig(o, "playlistItemData", "videoId").toString();
    if (videoId.isEmpty())
        videoId = dig(QJsonValue(titleRuns[0]), "navigationEndpoint", "watchEndpoint", "videoId").toString();

    QStringList parts = splitRuns(runsAt(1));
    const QString art = bestThumb(dig(o, "thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails").toArray());

    if (!videoId.isEmpty()) {
        Track t;
        t.videoId = videoId;
        t.title = title;
        t.artworkUrl = art;
        bool isVideo = false;
        if (!parts.isEmpty() && (parts[0] == "Song" || parts[0] == "Video")) {
            isVideo = parts[0] == "Video";
            parts.removeFirst();
        }
        if (!parts.isEmpty() && isDuration(parts.last()))
            t.durationMs = parseDuration(parts.takeLast());
        if (!parts.isEmpty()) t.artist = parts[0];
        if (parts.size() > 1 && !isVideo) t.album = parts[1];
        if (t.album.isEmpty() && !isVideo) {
            const QJsonArray albumRuns = runsAt(2);
            if (!albumRuns.isEmpty())
                t.album = albumRuns[0].toObject()["text"].toString();
        }
        if (t.durationMs == 0) {
            const QJsonArray fixed = o["fixedColumns"].toArray();
            if (!fixed.isEmpty()) {
                const QString d = dig(QJsonValue(fixed[0]), "musicResponsiveListItemFixedColumnRenderer", "text", "runs")
                                      .toArray().first().toObject()["text"].toString();
                if (isDuration(d)) t.durationMs = parseDuration(d);
            }
        }
        out.tracks.push_back(t);
        return;
    }

    const QString browseId = dig(o, "navigationEndpoint", "browseEndpoint", "browseId").toString();
    const CollectionKind kind = kindFromPageType(pageTypeOf(o["navigationEndpoint"]));
    if (browseId.isEmpty() || kind == CollectionKind::Unknown) return;
    out.collections.push_back({browseId, title, parts.join(" • "), art, kind});
}

void parseTwoRowItem(const QJsonObject &o, SearchResults &out)
{
    const QString title = dig(o, "title", "runs").toArray().first().toObject()["text"].toString();
    const QString subtitle = splitRuns(o["subtitle"].toObject()["runs"].toArray()).join(" • ");
    const QString art = bestThumb(dig(o, "thumbnailRenderer", "musicThumbnailRenderer", "thumbnail", "thumbnails").toArray());

    const QString videoId = dig(o, "navigationEndpoint", "watchEndpoint", "videoId").toString();
    if (!videoId.isEmpty()) {
        Track t;
        t.videoId = videoId; t.title = title; t.artist = subtitle; t.artworkUrl = art;
        out.tracks.push_back(t);
        return;
    }
    const QString browseId = dig(o, "navigationEndpoint", "browseEndpoint", "browseId").toString();
    const CollectionKind kind = kindFromPageType(pageTypeOf(o["navigationEndpoint"]));
    if (browseId.isEmpty() || kind == CollectionKind::Unknown) return;
    out.collections.push_back({browseId, title, subtitle, art, kind});
}

void walk(const QJsonValue &v, SearchResults &out)
{
    if (v.isArray()) {
        for (const auto &e : v.toArray()) walk(e, out);
    } else if (v.isObject()) {
        const QJsonObject o = v.toObject();
        if (o.contains("musicResponsiveListItemRenderer"))
            return parseListItem(o["musicResponsiveListItemRenderer"].toObject(), out);
        if (o.contains("musicTwoRowItemRenderer"))
            return parseTwoRowItem(o["musicTwoRowItemRenderer"].toObject(), out);
        for (auto it = o.begin(); it != o.end(); ++it) walk(it.value(), out);
    }
}

SearchResults parseResults(const QJsonObject &root)
{
    SearchResults r;
    walk(root, r);
    QSet<QString> seenT, seenC;
    QVector<Track> tracks;
    for (const Track &t : std::as_const(r.tracks))
        if (!seenT.contains(t.videoId)) { seenT.insert(t.videoId); tracks << t; }
    QVector<Collection> cols;
    for (const Collection &c : std::as_const(r.collections))
        if (!seenC.contains(c.browseId)) { seenC.insert(c.browseId); cols << c; }
    return {tracks, cols};
}

} // namespace

YouTubeMusicClient::YouTubeMusicClient(QNetworkAccessManager *nam, SettingsService *settings, QObject *parent)
    : MusicProvider(parent), m_http(nam, this), m_settings(settings)
{
}

QUrl YouTubeMusicClient::endpoint(const QString &name) const
{
    return QUrl(QStringLiteral("https://music.youtube.com/youtubei/v1/%1?prettyPrint=false").arg(name));
}

QJsonObject YouTubeMusicClient::context() const
{
    const QString version = "1." + QDate::currentDate().addDays(-1).toString("yyyyMMdd") + ".01.00";
    return {{"client", QJsonObject{{"clientName", "WEB_REMIX"},
                                   {"clientVersion", version},
                                   {"hl", m_settings->get("language").toString()}}}};
}

ApiRequest::Headers YouTubeMusicClient::headers() const
{
    ApiRequest::Headers h = {
        {"Origin", kOrigin},
        {"X-Origin", kOrigin},
        {"User-Agent", "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"},
        {"Accept-Language", m_settings->get("language").toString().toUtf8()},
    };
    const QString cookie = m_settings->get("authCookie").toString().trimmed();
    if (!cookie.isEmpty()) {
        h.append({"Cookie", cookie.toUtf8()});
        h.append(std::pair<QByteArray, QByteArray>{"X-Goog-AuthUser", "0"});
        QString sapisid;
        for (const QString &part : cookie.split(';')) {
            const QString p = part.trimmed();
            if (p.startsWith("SAPISID=")) sapisid = p.mid(8);
            else if (sapisid.isEmpty() && p.startsWith("__Secure-3PAPISID=")) sapisid = p.mid(18);
        }
        if (!sapisid.isEmpty()) {
            const qint64 ts = QDateTime::currentSecsSinceEpoch();
            const QByteArray digest = QCryptographicHash::hash(
                QByteArray::number(ts) + ' ' + sapisid.toUtf8() + ' ' + kOrigin,
                QCryptographicHash::Sha1).toHex();
            h.append({"Authorization", "SAPISIDHASH " + QByteArray::number(ts) + "_" + digest});
        }
    }
    return h;
}

quint64 YouTubeMusicClient::search(const QString &query, SearchFilter filter)
{
    const quint64 token = newToken();
    QJsonObject body{{"context", context()}, {"query", query}};
    if (const QString p = filterParams(filter); !p.isEmpty())
        body["params"] = p;

    m_http.post(endpoint("search"), body, headers(), [this, token](QJsonObject root, ApiError err) {
        if (err) return emit failed(token, err);
        const SearchResults r = parseResults(root);
        if (r.tracks.isEmpty() && r.collections.isEmpty() && !root.contains("contents"))
            return emit failed(token, {ApiError::InvalidResponse, "Unexpected search response", 0});
        emit searchFinished(token, r);
    });
    return token;
}

quint64 YouTubeMusicClient::loadCollection(const Collection &c)
{
    const quint64 token = newToken();
    const QJsonObject body{{"context", context()}, {"browseId", c.browseId}};
    m_http.post(endpoint("browse"), body, headers(), [this, token, c](QJsonObject root, ApiError err) {
        if (err) return emit failed(token, err);
        SearchResults r = parseResults(root);
        // Track rows on album pages inherit the album's cover and title.
        for (Track &t : r.tracks) {
            if (t.artworkUrl.isEmpty()) t.artworkUrl = c.artworkUrl;
            if (t.album.isEmpty() && c.kind == CollectionKind::Album) t.album = c.title;
        }
        emit collectionLoaded(token, r);
    });
    return token;
}

quint64 YouTubeMusicClient::resolveStream(const QString &videoId)
{
    const quint64 token = newToken();
    const QJsonObject body{{"context", context()}, {"videoId", videoId},
                           {"contentCheckOk", true}, {"racyCheckOk", true}};
    m_http.post(endpoint("player"), body, headers(), [this, token, videoId](QJsonObject root, ApiError err) {
        // The web player endpoint often answers "Video unavailable" / LOGIN_REQUIRED for
        // clients without a PO token even though the track is fine, so let the external
        // resolver (yt-dlp) have a go before giving up.
        const bool hasResolver = !m_settings->get("resolverCommand").toString().trimmed().isEmpty();
        if (err) {
            if (hasResolver && err.kind != ApiError::Network) return resolveExternally(token, videoId);
            return emit failed(token, err);
        }

        const QString status = dig(root, "playabilityStatus", "status").toString();
        if (status != "OK") {
            if (hasResolver) return resolveExternally(token, videoId);
            if (status == "LOGIN_REQUIRED")
                return emit failed(token, {ApiError::AuthRequired, {}, 0});
            const QString reason = dig(root, "playabilityStatus", "reason").toString();
            return emit failed(token, {ApiError::Unavailable, reason.isEmpty() ? "This track isn't available." : reason, 0});
        }

        // Use a directly playable audio URL when the response includes one.
        QUrl best;
        int bestRate = -1;
        for (const auto &f : dig(root, "streamingData", "adaptiveFormats").toArray()) {
            const QJsonObject fo = f.toObject();
            if (!fo["mimeType"].toString().startsWith("audio/") || !fo.contains("url")) continue;
            const int rate = fo["bitrate"].toInt();
            if (rate > bestRate) { bestRate = rate; best = QUrl(fo["url"].toString()); }
        }
        if (best.isValid()) return emit streamResolved(token, videoId, best);

        // Most web responses ship signed ("cipher") formats that this client does not decode.
        resolveExternally(token, videoId);
    });
    return token;
}

void YouTubeMusicClient::resolveExternally(quint64 token, const QString &videoId)
{
    QStringList argv = QProcess::splitCommand(m_settings->get("resolverCommand").toString().trimmed());
    if (argv.isEmpty()) {
        emit failed(token, {ApiError::Unavailable,
                            "Playback needs a stream resolver. Set one in Settings > Network.", 0});
        return;
    }
    const QString program = argv.takeFirst();
    argv << "-f" << "bestaudio" << "-g" << "--no-playlist"
         << QStringLiteral("https://music.youtube.com/watch?v=%1").arg(videoId);

    auto *proc = new QProcess(this);
    auto *timeout = new QTimer(proc);
    timeout->setSingleShot(true);
    connect(timeout, &QTimer::timeout, proc, [proc] { proc->kill(); });

    connect(proc, &QProcess::errorOccurred, this, [=, this](QProcess::ProcessError e) {
        if (e != QProcess::FailedToStart) return;
        emit failed(token, {ApiError::Unavailable,
                            QStringLiteral("Couldn't start \"%1\". Check the resolver command in Settings > Network.").arg(program), 0});
        proc->deleteLater();
    });
    connect(proc, &QProcess::finished, this, [=, this](int code, QProcess::ExitStatus) {
        const QByteArray out = proc->readAllStandardOutput().trimmed();
        const QUrl url(QString::fromUtf8(out.split('\n').value(0)));
        if (code == 0 && url.isValid() && url.scheme().startsWith("http"))
            emit streamResolved(token, videoId, url);
        else
            emit failed(token, {ApiError::Unavailable, "The stream resolver couldn't find audio for this track.", 0});
        proc->deleteLater();
    });
    proc->start(program, argv);
    timeout->start(25000);
}
