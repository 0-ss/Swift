#pragma once
#include "models/SongModel.h"
#include <QAbstractListModel>
#include <QObject>
#include <QTimer>

struct PlaylistSummary {
    QString id, name, description;
    int trackCount = 0;
    qint64 durationMs = 0;
    QStringList covers;   // up to four distinct artwork URLs, for the collage
};

// One row per playlist: what the Playlists page and the sidebar show.
class PlaylistListModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(int count READ count NOTIFY countChanged)
public:
    enum Role { IdRole = Qt::UserRole + 1, NameRole, DescriptionRole, TrackCountRole, DurationRole, CoversRole };

    using QAbstractListModel::QAbstractListModel;

    int rowCount(const QModelIndex &parent = {}) const override { return parent.isValid() ? 0 : count(); }
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    int count() const { return int(m_items.size()); }
    const PlaylistSummary &at(int row) const { return m_items[row]; }
    void insertSummary(int row, const PlaylistSummary &s);
    void updateSummary(int row, const PlaylistSummary &s);
    void removeSummary(int row);

    Q_INVOKABLE QVariantMap get(int row) const;

signals:
    void countChanged();

private:
    QVector<PlaylistSummary> m_items;
};

// User playlists, stored locally as JSON. A playlist has a custom order (the order tracks were
// added or dragged into). The opened playlist can additionally be *viewed* sorted by a column,
// without touching the custom order; the sorted view can be saved as the new order.
class PlaylistService : public QObject
{
    Q_OBJECT
    Q_PROPERTY(PlaylistListModel *playlists READ playlists CONSTANT)
    Q_PROPERTY(SongModel *openTracks READ openTracks CONSTANT)
    Q_PROPERTY(QVariantMap openInfo READ openInfo NOTIFY openChanged)
    Q_PROPERTY(QString openId READ openId NOTIFY openChanged)
    // 0 playlist order, 1 title, 2 artist, 3 album, 4 time, 5 date added
    Q_PROPERTY(int sortKey READ sortKey NOTIFY sortChanged)
    Q_PROPERTY(bool sortAscending READ sortAscending NOTIFY sortChanged)
public:
    explicit PlaylistService(QObject *parent = nullptr);
    ~PlaylistService() override;

    PlaylistListModel *playlists() { return &m_listModel; }
    SongModel *openTracks() { return &m_open; }
    QVariantMap openInfo() const;
    QString openId() const { return m_openId; }
    int sortKey() const { return m_sortKey; }
    bool sortAscending() const { return m_ascending; }

    Q_INVOKABLE QString create(const QString &name, const QString &description = {});
    Q_INVOKABLE bool edit(const QString &id, const QString &name, const QString &description);
    Q_INVOKABLE void remove(const QString &id);
    Q_INVOKABLE QVariantMap info(const QString &id) const;
    Q_INVOKABLE bool contains(const QString &id, const QString &videoId) const;
    Q_INVOKABLE QVariantList tracksOf(const QString &id) const;   // in playlist order

    Q_INVOKABLE void open(const QString &id);
    Q_INVOKABLE void close();

    // Adding. Songs already in a playlist are skipped. Each returns how many were added.
    Q_INVOKABLE int addTrack(const QString &id, const QVariantMap &track);
    Q_INVOKABLE int addTracks(const QString &id, const QVariantList &tracks);
    Q_INVOKABLE int addModel(const QString &id, QObject *songModel);

    // Editing the open playlist. Indices are positions in the list as shown.
    Q_INVOKABLE void removeAt(int viewIndex);
    Q_INVOKABLE void move(int from, int to);          // only in playlist order
    Q_INVOKABLE void setSort(int key, bool ascending);
    Q_INVOKABLE void commitSortAsOrder();

signals:
    void openChanged();
    void sortChanged();
    void removed(const QString &id);
    void message(const QString &text);   // short confirmations for a toast

private:
    struct Playlist {
        QString id, name, description;
        qint64 created = 0, updated = 0;
        QVector<hm::Track> tracks;
        QVector<qint64> added;
    };

    int indexOf(const QString &id) const;
    PlaylistSummary summaryOf(const Playlist &p) const;
    void touch(int index);
    bool addOne(Playlist &p, const hm::Track &t);
    QVector<int> sortedOrder(const Playlist &p) const;
    void rebuildOpen();
    void load();
    void save();

    QVector<Playlist> m_lists;
    PlaylistListModel m_listModel;
    SongModel m_open;
    QString m_openId;
    QVector<int> m_viewMap;     // view row -> source row; identity in playlist order
    int m_sortKey = 0;
    bool m_ascending = true;
    QTimer m_saveTimer;
};
