#include "SettingsService.h"

QVariantMap SettingsService::defaults()
{
    return {
        // Appearance
        {"themeMode", 0},            // 0 system, 1 light, 2 dark
        {"accentColor", "#FA233B"},
        {"reduceMotion", false},
        {"showWindowButtons", true}, // custom macOS-style traffic lights (frameless window)
        {"floatingPlayerBar", false}, // false: player bar in the top toolbar; true: floating glass bar at the bottom
        {"liquidGlass", true},       // floating bar material: true Liquid Glass, false classic blur
        {"floatingSidebar", true},   // true: sidebar floats as an inset glass panel; false: docked full-height sidebar
        // Playback
        {"restoreSession", true},
        {"volume", 0.8},
        // Notifications
        {"notifyOnTrackChange", false},
        // Network / account
        {"language", "en"},
        {"resolverCommand", "yt-dlp"},
        {"authCookie", ""},
        // Cache
        {"cacheLimitMb", 256},
    };
}

SettingsService::SettingsService(QObject *parent) : QObject(parent)
{
    const QVariantMap defs = defaults();
    for (auto it = defs.cbegin(); it != defs.cend(); ++it) {
        QVariant v = m_store.value(it.key(), it.value());
        v.convert(it.value().metaType()); // QSettings may hand back strings
        m_map.insert(it.key(), v);
    }
    connect(&m_map, &QQmlPropertyMap::valueChanged, this, [this](const QString &k, const QVariant &v) {
        m_store.setValue(k, v);
        emit changed(k, v);
    });
}

void SettingsService::set(const QString &key, const QVariant &value)
{
    if (m_map.value(key) == value) return;
    m_map.insert(key, value);
    m_store.setValue(key, value);
    emit changed(key, value);
}

void SettingsService::resetToDefaults()
{
    const QVariantMap defs = defaults();
    for (auto it = defs.cbegin(); it != defs.cend(); ++it) {
        if (it.key() == "authCookie") continue; // signing out is a separate action
        set(it.key(), it.value());
    }
}
