#include "PlaylistService.h"
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLoggingCategory>
#include <QSaveFile>
#include <QSet>
#include <QStandardPaths>
#include <QUuid>
#include <algorithm>

Q_LOGGING_CATEGORY(lcPlaylists, "swift.playlists")

namespace {
QString storePath()
{
    const QString dir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(dir);
    return dir + "/playlists.json";
}
}

// ---- PlaylistListModel ---------------------------------------------------------------------

QVariant PlaylistListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= count()) return {};
    const PlaylistSummary &s = m_items[index.row()];
    switch (role) {
    case IdRole: return s.id;
    case NameRole: return s.name;
    case DescriptionRole: return s.description;
    case TrackCountRole: return s.trackCount;
    case DurationRole: return s.durationMs;
    case CoversRole: return s.covers;
    default: return {};
    }
}

QHash<int, QByteArray> PlaylistListModel::roleNames() const
{
    return {{IdRole, "playlistId"}, {NameRole, "name"}, {DescriptionRole, "description"},
            {TrackCountRole, "trackCount"}, {DurationRole, "durationMs"}, {CoversRole, "covers"}};
}

void PlaylistListModel::insertSummary(int row, const PlaylistSummary &s)
{
    row = qBound(0, row, count());
    beginInsertRows({}, row, row);
    m_items.insert(row, s);
    endInsertRows();
    emit countChanged();
}

void PlaylistListModel::updateSummary(int row, const PlaylistSummary &s)
{
    if (row < 0 || row >= count()) return;
    m_items[row] = s;
    emit dataChanged(index(row), index(row));
}

void PlaylistListModel::removeSummary(int row)
{
    if (row < 0 || row >= count()) return;
    beginRemoveRows({}, row, row);
    m_items.removeAt(row);
    endRemoveRows();
    emit countChanged();
}

QVariantMap PlaylistListModel::get(int row) const
{
    if (row < 0 || row >= count()) return {};
    const PlaylistSummary &s = m_items[row];
    return {{"id", s.id}, {"name", s.name}, {"description", s.description},
            {"trackCount", s.trackCount}, {"durationMs", s.durationMs}, {"covers", s.covers}};
}

// ---- PlaylistService -----------------------------------------------------------------------

PlaylistService::PlaylistService(QObject *parent) : QObject(parent)
{
    m_saveTimer.setSingleShot(true);
    m_saveTimer.setInterval(400);
    connect(&m_saveTimer, &QTimer::timeout, this, &PlaylistService::save);
    load();
}

PlaylistService::~PlaylistService()
{
    if (m_saveTimer.isActive()) save();
}

int PlaylistService::indexOf(const QString &id) const
{
    for (int i = 0; i < m_lists.size(); ++i)
        if (m_lists[i].id == id) return i;
    return -1;
}

PlaylistSummary PlaylistService::summaryOf(const Playlist &p) const
{
    PlaylistSummary s;
    s.id = p.id;
    s.name = p.name;
    s.description = p.description;
    s.trackCount = int(p.tracks.size());
    QSet<QString> seen;
    for (const hm::Track &t : p.tracks) {
        s.durationMs += t.durationMs;
        if (s.covers.size() < 4 && !t.artworkUrl.isEmpty() && !seen.contains(t.artworkUrl)) {
            seen.insert(t.artworkUrl);
            s.covers << t.artworkUrl;
        }
    }
    return s;
}

void PlaylistService::touch(int index)
{
    Playlist &p = m_lists[index];
    p.updated = QDateTime::currentMSecsSinceEpoch();
    m_listModel.updateSummary(index, summaryOf(p));
    if (p.id == m_openId) emit openChanged();
    m_saveTimer.start();
}

QVariantMap PlaylistService::info(const QString &id) const
{
    const int i = indexOf(id);
    return i < 0 ? QVariantMap{} : m_listModel.get(i);
}

QVariantMap PlaylistService::openInfo() const
{
    return m_openId.isEmpty() ? QVariantMap{} : info(m_openId);
}

bool PlaylistService::contains(const QString &id, const QString &videoId) const
{
    const int i = indexOf(id);
    if (i < 0) return false;
    return std::any_of(m_lists[i].tracks.cbegin(), m_lists[i].tracks.cend(),
                       [&](const hm::Track &t) { return t.videoId == videoId; });
}

QVariantList PlaylistService::tracksOf(const QString &id) const
{
    QVariantList out;
    const int i = indexOf(id);
    if (i < 0) return out;
    for (const hm::Track &t : m_lists[i].tracks) out << hm::toVariant(t);
    return out;
}

QString PlaylistService::create(const QString &name, const QString &description)
{
    QString base = name.simplified();
    if (base.isEmpty()) base = "Untitled Playlist";
    QString unique = base;
    if (name.simplified().isEmpty()) {
        QSet<QString> taken;
        for (const Playlist &p : std::as_const(m_lists)) taken.insert(p.name);
        for (int n = 2; taken.contains(unique); ++n) unique = QStringLiteral("%1 %2").arg(base).arg(n);
    }

    Playlist p;
    p.id = QUuid::createUuid().toString(QUuid::WithoutBraces);
    p.name = unique;
    p.description = description.trimmed();
    p.created = p.updated = QDateTime::currentMSecsSinceEpoch();
    m_lists.append(p);
    m_listModel.insertSummary(int(m_lists.size()) - 1, summaryOf(p));
    m_saveTimer.start();
    return p.id;
}

bool PlaylistService::edit(const QString &id, const QString &name, const QString &description)
{
    const int i = indexOf(id);
    if (i < 0) return false;
    const QString n = name.simplified();
    if (!n.isEmpty()) m_lists[i].name = n;
    m_lists[i].description = description.trimmed();
    touch(i);
    return true;
}

void PlaylistService::remove(const QString &id)
{
    const int i = indexOf(id);
    if (i < 0) return;
    if (id == m_openId) close();
    m_lists.removeAt(i);
    m_listModel.removeSummary(i);
    m_saveTimer.start();
    emit removed(id);
}

void PlaylistService::open(const QString &id)
{
    if (indexOf(id) < 0) return;
    if (m_openId != id) {
        m_openId = id;
        m_sortKey = 0;
        m_ascending = true;
        emit sortChanged();
    }
    rebuildOpen();
    emit openChanged();
}

void PlaylistService::close()
{
    if (m_openId.isEmpty()) return;
    m_openId.clear();
    m_open.clear();
    m_viewMap.clear();
    emit openChanged();
}

bool PlaylistService::addOne(Playlist &p, const hm::Track &t)
{
    if (!t.isValid()) return false;
    for (const hm::Track &x : std::as_const(p.tracks))
        if (x.videoId == t.videoId) return false;
    p.tracks.append(t);
    p.added.append(QDateTime::currentMSecsSinceEpoch());
    return true;
}

int PlaylistService::addTracks(const QString &id, const QVariantList &tracks)
{
    const int i = indexOf(id);
    if (i < 0) return 0;
    Playlist &p = m_lists[i];
    int added = 0;
    for (const QVariant &v : tracks) {
        const hm::Track t = hm::trackFromVariant(v.toMap());
        if (!addOne(p, t)) continue;
        ++added;
        if (id == m_openId && m_sortKey == 0) m_open.appendTrack(t);
    }
    if (added > 0) {
        if (id == m_openId && m_sortKey != 0) rebuildOpen();
        touch(i);
    }
    const QString name = p.name;
    if (added == 0)
        emit message(tracks.size() == 1 ? QStringLiteral("Already in “%1”.").arg(name)
                                        : QStringLiteral("Those songs are already in “%1”.").arg(name));
    else
        emit message(added == 1 ? QStringLiteral("Added to “%1”.").arg(name)
                                : QStringLiteral("Added %1 songs to “%2”.").arg(added).arg(name));
    return added;
}

int PlaylistService::addTrack(const QString &id, const QVariantMap &track)
{
    return addTracks(id, {track});
}

int PlaylistService::addModel(const QString &id, QObject *songModel)
{
    auto *songs = qobject_cast<SongModel *>(songModel);
    if (!songs) return 0;
    QVariantList list;
    for (const hm::Track &t : songs->tracks()) list << hm::toVariant(t);
    return addTracks(id, list);
}

void PlaylistService::removeAt(int viewIndex)
{
    const int i = indexOf(m_openId);
    if (i < 0 || viewIndex < 0 || viewIndex >= m_open.count()) return;
    Playlist &p = m_lists[i];
    const int src = m_sortKey == 0 ? viewIndex : m_viewMap.value(viewIndex, -1);
    if (src < 0 || src >= p.tracks.size()) return;
    p.tracks.removeAt(src);
    p.added.removeAt(src);
    if (m_sortKey == 0) m_open.removeTrackAt(viewIndex);
    else rebuildOpen();
    touch(i);
}

void PlaylistService::move(int from, int to)
{
    const int i = indexOf(m_openId);
    if (i < 0 || m_sortKey != 0) return;
    Playlist &p = m_lists[i];
    if (from == to || from < 0 || to < 0 || from >= p.tracks.size() || to >= p.tracks.size()) return;
    p.tracks.move(from, to);
    p.added.move(from, to);
    m_open.moveTrack(from, to);
    touch(i);
}

QVector<int> PlaylistService::sortedOrder(const Playlist &p) const
{
    QVector<int> order(p.tracks.size());
    for (int k = 0; k < order.size(); ++k) order[k] = k;
    if (m_sortKey == 0) return order;

    auto text = [&](int idx) -> const QString & {
        const hm::Track &t = p.tracks[idx];
        return m_sortKey == 1 ? t.title : m_sortKey == 2 ? t.artist : t.album;
    };
    auto less = [&](int a, int b) {
        switch (m_sortKey) {
        case 4: return p.tracks[a].durationMs < p.tracks[b].durationMs;
        case 5: return p.added[a] < p.added[b];
        default: return QString::localeAwareCompare(text(a), text(b)) < 0;
        }
    };
    if (m_ascending) std::stable_sort(order.begin(), order.end(), less);
    else std::stable_sort(order.begin(), order.end(), [&](int a, int b) { return less(b, a); });
    return order;
}

void PlaylistService::rebuildOpen()
{
    const int i = indexOf(m_openId);
    if (i < 0) {
        m_open.clear();
        m_viewMap.clear();
        return;
    }
    const Playlist &p = m_lists[i];
    m_viewMap = sortedOrder(p);
    QVector<hm::Track> view;
    view.reserve(m_viewMap.size());
    for (int src : std::as_const(m_viewMap)) view << p.tracks[src];
    m_open.setTracks(view);
}

void PlaylistService::setSort(int key, bool ascending)
{
    key = qBound(0, key, 5);
    if (key == m_sortKey && ascending == m_ascending) return;
    m_sortKey = key;
    m_ascending = ascending;
    rebuildOpen();
    emit sortChanged();
}

void PlaylistService::commitSortAsOrder()
{
    const int i = indexOf(m_openId);
    if (i < 0 || m_sortKey == 0) return;
    Playlist &p = m_lists[i];
    QVector<hm::Track> tracks;
    QVector<qint64> added;
    for (int src : std::as_const(m_viewMap)) {
        tracks << p.tracks[src];
        added << p.added[src];
    }
    p.tracks = tracks;
    p.added = added;
    m_sortKey = 0;
    m_ascending = true;
    rebuildOpen();
    emit sortChanged();
    touch(i);
    emit message("Saved as the playlist order.");
}

void PlaylistService::load()
{
    QFile f(storePath());
    if (!f.open(QIODevice::ReadOnly)) return;
    const QJsonObject root = QJsonDocument::fromJson(f.readAll()).object();
    for (const QJsonValue &pv : root["playlists"].toArray()) {
        const QJsonObject o = pv.toObject();
        Playlist p;
        p.id = o["id"].toString();
        if (p.id.isEmpty()) continue;
        p.name = o["name"].toString("Untitled Playlist");
        p.description = o["description"].toString();
        p.created = qint64(o["created"].toDouble());
        p.updated = qint64(o["updated"].toDouble());
        for (const QJsonValue &tv : o["tracks"].toArray()) {
            const QJsonObject to = tv.toObject();
            const hm::Track t = hm::Track::fromJson(to);
            if (!t.isValid()) continue;
            p.tracks << t;
            p.added << qint64(to["added"].toDouble());
        }
        m_lists << p;
        m_listModel.insertSummary(m_listModel.count(), summaryOf(p));
    }
}

void PlaylistService::save()
{
    QJsonArray lists;
    for (const Playlist &p : std::as_const(m_lists)) {
        QJsonArray tracks;
        for (int k = 0; k < p.tracks.size(); ++k) {
            QJsonObject t = p.tracks[k].toJson();
            t["added"] = double(p.added.value(k));
            tracks.append(t);
        }
        lists.append(QJsonObject{{"id", p.id}, {"name", p.name}, {"description", p.description},
                                 {"created", double(p.created)}, {"updated", double(p.updated)},
                                 {"tracks", tracks}});
    }
    QSaveFile f(storePath());
    if (!f.open(QIODevice::WriteOnly)) {
        qCWarning(lcPlaylists) << "cannot write playlists:" << f.errorString();
        return;
    }
    f.write(QJsonDocument(QJsonObject{{"version", 1}, {"playlists", lists}}).toJson(QJsonDocument::Compact));
    if (!f.commit()) qCWarning(lcPlaylists) << "commit failed:" << f.errorString();
}
