import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import Swift

// Full-screen player: blurred artwork wash, large cover, scrubber and controls.
// Always rendered on a dark scheme (white text), like Music's full-screen view.
Item {
    id: np
    signal close()
    signal openQueue()

    readonly property color fg: "white"
    readonly property color fgDim: Theme.alpha("#FFFFFF", 0.62)

    Rectangle { anchors.fill: parent; color: "#1B1B1D" }

    Image {
        id: bgSource
        anchors.fill: parent
        source: player.artworkUrl
        fillMode: Image.PreserveAspectCrop
        visible: false
        asynchronous: true
        sourceSize.width: 128
        sourceSize.height: 128
    }
    MultiEffect {
        anchors.fill: parent
        source: bgSource
        blurEnabled: true
        blur: 1.0
        blurMax: 64
        saturation: 0.5
        brightness: -0.15
        opacity: 0.85
    }
    Rectangle { anchors.fill: parent; color: Theme.alpha("#000000", 0.28) }

    MouseArea { anchors.fill: parent }   // swallow clicks to the page behind

    IconButton {
        x: Window.window && Window.window.lightsRoom > 0 ? Window.window.lightsRoom + 6 : 16
        y: 16
        glyph: "chevronDown"; size: 18; color: np.fg
        hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
        tip: "Close full screen player"
        onClicked: np.close()
    }

    ColumnLayout {
        id: col
        anchors.centerIn: parent
        width: Math.min(440, parent.width - 64)
        spacing: 16

        Artwork {
            Layout.alignment: Qt.AlignHCenter
            Layout.preferredWidth: Math.max(160, Math.min(col.width, np.height - 330, 420))
            Layout.preferredHeight: Layout.preferredWidth
            source: player.artworkUrl
            corner: Theme.rXl - 2
            outline: false
            scale: player.playing ? 1 : 0.9
            Behavior on scale { NumberAnimation { duration: Theme.base * 1.6; easing.type: Easing.OutCubic } }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.topMargin: 6
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Text {
                    Layout.fillWidth: true
                    text: player.title
                    elide: Text.ElideRight
                    color: np.fg
                    font.family: Theme.fontFamily
                    font.pixelSize: 20
                    font.weight: Font.Bold
                }
                Text {
                    Layout.fillWidth: true
                    text: player.artist
                    elide: Text.ElideRight
                    color: np.fgDim
                    font.family: Theme.fontFamily
                    font.pixelSize: 16
                }
            }
            IconButton {
                readonly property bool liked: library.favoriteIds.indexOf(player.videoId) >= 0
                glyph: liked ? "heartFill" : "heart"; size: 20; active: liked
                color: np.fg
                hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
                tip: liked ? "Remove from Liked Songs" : "Add to Liked Songs"
                onClicked: library.toggleFavorite({videoId: player.videoId, title: player.title, artist: player.artist,
                                                   album: player.album, artworkUrl: player.artworkUrl, durationMs: player.duration})
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 2
            ProgressSlider {
                Layout.fillWidth: true
                fillColor: np.fgDim
                trackColor: Theme.alpha("#FFFFFF", 0.22)
                to: Math.max(1, player.duration)
                value: player.position
                onCommitted: (v) => player.seek(v)
            }
            RowLayout {
                Layout.fillWidth: true
                Text { text: Theme.fmt(player.position); color: np.fgDim; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall }
                Item { Layout.fillWidth: true }
                Text { visible: player.loading; text: "Loading…"; color: np.fgDim; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall }
                Item { Layout.fillWidth: true }
                Text { text: Theme.fmtRemaining(player.position, player.duration); color: np.fgDim; font.family: Theme.fontFamily; font.pixelSize: Theme.sizeSmall }
            }
        }

        RowLayout {
            Layout.alignment: Qt.AlignHCenter
            spacing: 14
            IconButton { glyph: "shuffle"; size: 18; active: player.shuffle; color: np.fg; activeColor: np.fg; tip: "Shuffle"
                         hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
                         onClicked: player.shuffle = !player.shuffle }
            IconButton { glyph: "prev"; size: 26; implicitWidth: 48; implicitHeight: 44; color: np.fg; tip: "Previous"
                         hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
                         onClicked: player.previous() }
            IconButton { glyph: player.playing ? "pause" : "play"; size: 34; implicitWidth: 58; implicitHeight: 52; color: np.fg
                         tip: player.playing ? "Pause" : "Play"
                         hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
                         onClicked: player.togglePlayback() }
            IconButton { glyph: "next"; size: 26; implicitWidth: 48; implicitHeight: 44; color: np.fg; tip: "Next"
                         hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
                         onClicked: player.next() }
            IconButton { glyph: player.repeatMode === 2 ? "repeatOne" : "repeat"; size: 18; active: player.repeatMode > 0
                         color: np.fg; activeColor: np.fg; tip: "Repeat"
                         hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
                         onClicked: player.cycleRepeat() }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.topMargin: 4
            spacing: 8
            Glyph { Layout.preferredWidth: 14; Layout.preferredHeight: 14; name: "speakerMute"; size: 14; color: np.fgDim }
            ProgressSlider {
                Layout.fillWidth: true
                fillColor: np.fgDim
                trackColor: Theme.alpha("#FFFFFF", 0.22)
                value: player.volume
                onMoved: (v) => player.volume = v
                onCommitted: (v) => player.volume = v
            }
            Glyph { Layout.preferredWidth: 16; Layout.preferredHeight: 16; name: "speakerWave"; size: 16; color: np.fgDim }
            IconButton { glyph: "upnext"; size: 17; color: np.fg; tip: "Show Up Next"
                         hoverColor: Theme.alpha("#FFFFFF", 0.14); pressedColor: Theme.alpha("#FFFFFF", 0.24)
                         onClicked: np.openQueue() }
        }
    }
}
