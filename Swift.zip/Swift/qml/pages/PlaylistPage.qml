import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

// One playlist. Songs can be dragged into any order (while the list is in "playlist order"),
// or the view can be sorted by clicking a column title. Sorting only changes the view until
// "Save as Playlist Order" is chosen.
PageScaffold {
    id: page
    readonly property var info: playlists.openInfo
    readonly property bool custom: playlists.sortKey === 0
    readonly property int count: playlists.openTracks.count
    readonly property real coverSize: page.availableWidth < 640 ? 140 : 232
    readonly property int rowH: 52
    readonly property var sortNames: ["Playlist Order", "Title", "Artist", "Album", "Time", "Date Added"]

    function durationText(ms) {
        const min = Math.round(ms / 60000)
        if (min <= 0) return ""
        return min >= 60 ? Math.floor(min / 60) + " hr " + (min % 60) + " min" : min + " min"
    }
    function editThis() { Window.window.editPlaylist(playlists.openId) }
    function deleteThis() { Window.window.deletePlaylist(playlists.openId) }
    function sortBy(key) {
        if (key === 0) playlists.setSort(0, true)
        else if (key === playlists.sortKey) playlists.setSort(key, !playlists.sortAscending)
        else playlists.setSort(key, true)
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 24
        PlaylistCover {
            Layout.preferredWidth: page.coverSize
            Layout.preferredHeight: page.coverSize
            Layout.alignment: Qt.AlignTop
            covers: info.covers || []
            corner: Theme.rLg
        }
        ColumnLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: page.coverSize
            spacing: 4
            Text {
                Layout.fillWidth: true
                text: info.name || ""
                wrapMode: Text.WordWrap
                maximumLineCount: 3
                elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: page.availableWidth < 640 ? 22 : 26
                font.weight: Font.Bold
            }
            Text {
                visible: text.length > 0
                Layout.fillWidth: true
                text: info.description || ""
                wrapMode: Text.WordWrap
                maximumLineCount: 3
                elide: Text.ElideRight
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody + 1
            }
            Text {
                Layout.fillWidth: true
                text: {
                    const n = page.count
                    const d = page.durationText(info.durationMs || 0)
                    return n + (n === 1 ? " song" : " songs") + (d.length ? ", " + d : "")
                }
                color: Theme.textTertiary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
            }
            Item { Layout.fillHeight: true }
            RowLayout {
                spacing: 10
                PillButton {
                    text: "Play"; glyph: "play"
                    enabled: page.count > 0
                    onClicked: { player.shuffle = false; player.playFrom(playlists.openTracks, 0) }
                }
                PillButton {
                    text: "Shuffle"; glyph: "shuffle"
                    enabled: page.count > 0
                    onClicked: { player.shuffle = true; player.playFrom(playlists.openTracks, Math.floor(Math.random() * page.count)) }
                }
                IconButton {
                    id: moreBtn
                    glyph: "ellipsis"; size: 17; tip: "More"
                    color: Theme.textSecondary
                    onClicked: moreMenu.popup(moreBtn, 0, moreBtn.height + 4)
                }
            }
        }
    }

    PlaylistMenu {
        id: moreMenu
        empty: page.count === 0
        onPlay: { player.shuffle = false; player.playFrom(playlists.openTracks, 0) }
        onShuffle: { player.shuffle = true; player.playFrom(playlists.openTracks, Math.floor(Math.random() * page.count)) }
        onEdit: page.editThis()
        onRemove: page.deleteThis()
    }

    // shown while the view is sorted
    Rectangle {
        visible: !page.custom && page.count > 0
        Layout.fillWidth: true
        implicitHeight: bannerRow.implicitHeight + 16
        radius: Theme.rMd
        color: Theme.card
        RowLayout {
            id: bannerRow
            anchors.fill: parent
            anchors.leftMargin: 14
            anchors.rightMargin: 8
            spacing: 8
            Text {
                Layout.fillWidth: true
                text: "Sorted by " + page.sortNames[playlists.sortKey] + (playlists.sortAscending ? " (ascending)" : " (descending)")
                      + ". Dragging is off until you return to playlist order."
                wrapMode: Text.WordWrap
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
            }
            PillButton { text: "Save as Playlist Order"; onClicked: playlists.commitSortAsOrder() }
            PillButton { text: "Back to Playlist Order"; onClicked: playlists.setSort(0, true) }
        }
    }

    // empty playlist
    ColumnLayout {
        visible: page.count === 0
        Layout.fillWidth: true
        Layout.topMargin: 36
        spacing: 10
        Glyph { Layout.alignment: Qt.AlignHCenter; name: "note"; size: 38; color: Theme.textTertiary }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: "No Songs"
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeHeading
            font.weight: Font.Bold
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            Layout.maximumWidth: 380
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: "Search for songs, then choose Add to Playlist from the … menu on any song."
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }
        PillButton {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 6
            text: "Find Songs"; glyph: "search"
            onClicked: Window.window.focusSearch()
        }
    }

    ColumnLayout {
        Layout.fillWidth: true
        Layout.topMargin: 6
        spacing: 0
        visible: page.count > 0

        TrackHeader {
            Layout.fillWidth: true
            sortable: true
            sortKey: playlists.sortKey
            ascending: playlists.sortAscending
            onSortClicked: (key) => page.sortBy(key)
        }

        // Rows are positioned by hand so the others can slide out of the way of a dragged row.
        Item {
            id: list
            Layout.fillWidth: true
            Layout.preferredHeight: page.count * page.rowH

            property int dragFrom: -1
            property int dragTo: -1
            property real dragY: 0
            property real grabOffset: 0
            property real lastSceneY: 0

            function updateDrag() {
                if (dragFrom < 0) return
                const y = list.mapFromItem(null, 0, lastSceneY).y - grabOffset
                dragY = Math.max(0, Math.min((page.count - 1) * page.rowH, y))
                dragTo = Math.max(0, Math.min(page.count - 1, Math.round(dragY / page.rowH)))
            }

            // keep scrolling while a row is held near the top or bottom edge
            Timer {
                interval: 16
                repeat: true
                running: list.dragFrom >= 0
                onTriggered: {
                    const vy = page.mapFromItem(null, 0, list.lastSceneY).y
                    const edge = 56
                    const bottom = page.height - edge - page.bottomInset
                    let dy = 0
                    if (vy < edge + page.topInset) dy = -Math.ceil((edge + page.topInset - vy) / 4)
                    else if (vy > bottom) dy = Math.ceil((vy - bottom) / 4)
                    if (dy !== 0)
                        page.contentY = Math.max(0, Math.min(Math.max(0, page.contentHeight - page.height), page.contentY + dy))
                    list.updateDrag()
                }
            }

            Repeater {
                model: playlists.openTracks
                delegate: Item {
                    id: slot
                    width: list.width
                    height: page.rowH
                    readonly property bool dragging: list.dragFrom === index
                    readonly property real restY: {
                        const f = list.dragFrom, t = list.dragTo
                        if (f < 0 || index === f) return index * page.rowH
                        if (index > f && index <= t) return (index - 1) * page.rowH
                        if (index < f && index >= t) return (index + 1) * page.rowH
                        return index * page.rowH
                    }
                    y: dragging ? list.dragY : restY
                    z: dragging ? 5 : 0
                    Behavior on y { enabled: !slot.dragging; NumberAnimation { duration: Theme.fast; easing.type: Easing.OutCubic } }

                    // lifted look while dragging
                    Rectangle {
                        anchors.fill: parent
                        radius: Theme.rSm
                        visible: slot.dragging
                        color: Theme.menu
                        border.width: 1
                        border.color: Theme.alpha(Theme.accent, 0.7)
                    }

                    TrackRow {
                        anchors.fill: parent
                        striped: index % 2 === 0 && !slot.dragging
                        inPlaylist: true
                        canReorder: page.custom && page.count > 1
                        videoId: model.videoId; title: model.title; artist: model.artist; album: model.album
                        artworkUrl: model.artworkUrl; durationMs: model.durationMs
                        isCurrent: player.videoId === model.videoId
                        onActivated: player.playFrom(playlists.openTracks, index)
                        onFavoriteToggled: library.toggleFavorite(playlists.openTracks.get(index))
                        onEnqueueRequested: player.enqueue(playlists.openTracks.get(index))
                        onPlayNextRequested: player.playNext(playlists.openTracks.get(index))
                        onRemoveRequested: playlists.removeAt(index)
                        onMoveRequested: (where) => {
                            const last = page.count - 1
                            const to = where === "top" ? 0 : where === "bottom" ? last
                                     : where === "up" ? index - 1 : index + 1
                            if (to >= 0 && to <= last) playlists.move(index, to)
                        }
                    }

                    // Alt+↑ / Alt+↓ move the focused song; Delete removes it
                    Keys.onPressed: (e) => {
                        if ((e.modifiers & Qt.AltModifier) && page.custom
                                && (e.key === Qt.Key_Up || e.key === Qt.Key_Down)) {
                            const to = index + (e.key === Qt.Key_Up ? -1 : 1)
                            if (to >= 0 && to < page.count) playlists.move(index, to)
                            e.accepted = true
                        } else if (e.key === Qt.Key_Delete || e.key === Qt.Key_Backspace) {
                            playlists.removeAt(index)
                            e.accepted = true
                        }
                    }

                    DragHandler {
                        id: dh
                        enabled: page.custom && page.count > 1
                        target: null
                        xAxis.enabled: false
                        dragThreshold: 6
                        onActiveChanged: {
                            if (active) {
                                list.lastSceneY = centroid.scenePosition.y
                                list.grabOffset = centroid.scenePressPosition.y - slot.mapToItem(null, 0, 0).y
                                list.dragFrom = index
                                list.dragTo = index
                                list.updateDrag()
                            } else if (list.dragFrom === index) {
                                const from = list.dragFrom, to = list.dragTo
                                if (from !== to) playlists.move(from, to)
                                list.dragFrom = -1
                                list.dragTo = -1
                            }
                        }
                        onCentroidChanged: {
                            if (!active) return
                            list.lastSceneY = centroid.scenePosition.y
                            list.updateDrag()
                        }
                    }
                }
            }
        }
    }
}
