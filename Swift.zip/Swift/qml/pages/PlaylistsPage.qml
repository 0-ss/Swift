import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

// Library > Playlists: every playlist as a card, plus "New Playlist".
PageScaffold {
    id: page
    readonly property int count: playlists.playlists.count

    RowLayout {
        Layout.fillWidth: true
        spacing: 10
        PageTitle { Layout.fillWidth: true; text: "Playlists" }
        PillButton {
            text: "New Playlist"; glyph: "plus"
            onClicked: Window.window.newPlaylist([])
        }
    }

    Text {
        visible: page.count > 0
        text: page.count + (page.count === 1 ? " playlist" : " playlists")
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
    }

    Flow {
        Layout.fillWidth: true
        visible: page.count > 0
        spacing: 22
        Repeater {
            model: playlists.playlists
            delegate: PlaylistCard {
                title: model.name
                subtitle: model.trackCount + (model.trackCount === 1 ? " song" : " songs")
                covers: model.covers
                empty: model.trackCount === 0
                onClicked: Window.window.openPlaylist(model.playlistId)
                onPlayRequested: player.playTracks(playlists.tracksOf(model.playlistId), 0, false)
                onShuffleRequested: player.playTracks(playlists.tracksOf(model.playlistId), 0, true)
                onEditRequested: Window.window.editPlaylist(model.playlistId)
                onRemoveRequested: Window.window.deletePlaylist(model.playlistId)
            }
        }
    }

    ColumnLayout {
        visible: page.count === 0
        Layout.fillWidth: true
        Layout.topMargin: 56
        spacing: 10
        Glyph { Layout.alignment: Qt.AlignHCenter; name: "playlist"; size: 44; color: Theme.textTertiary }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: "No Playlists"
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeHeading
            font.weight: Font.Bold
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            Layout.maximumWidth: 360
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: "Create a playlist, then add songs from any song’s … menu. You can drag songs into your own order."
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }
        PillButton {
            Layout.alignment: Qt.AlignHCenter
            Layout.topMargin: 8
            text: "New Playlist"; glyph: "plus"; prominent: true
            onClicked: Window.window.newPlaylist([])
        }
    }
}
