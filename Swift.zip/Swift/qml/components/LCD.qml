import QtQuick
import Swift

// The centre "LCD" of the player bar: cover, title, "artist — album", scrubber with elapsed /
// remaining time. Clicking the cover opens the full-screen player.
//
// Everything inside is placed with explicit pixel geometry rather than layouts, so the cover
// and the text block can never grow past the plate whatever the system font's metrics are.
Rectangle {
    id: lcd
    signal expand()
    property bool tall: false                       // taller plate when the bar floats
    readonly property int pad: 5                    // gap between plate edge and cover
    readonly property int lineH: tall ? 14 : 13     // height of the title and artist lines
    readonly property int gap: tall ? 3 : 2         // space above the scrubber row
    readonly property int rowH: 10                  // scrubber row
    readonly property int blockH: 2 * lineH + gap + rowH

    implicitHeight: tall ? 56 : 48
    implicitWidth: 420
    radius: Theme.rMd
    color: Theme.lcd
    border.width: 1
    border.color: Theme.lcdBorder

    Text {
        visible: !player.hasTrack
        anchors.centerIn: parent
        text: "Not Playing"
        color: Theme.textTertiary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeBody
    }

    Item {
        id: content
        visible: player.hasTrack
        anchors.fill: parent

        Artwork {
            id: art
            readonly property real side: lcd.height - 2 * lcd.pad
            x: lcd.pad
            y: Math.round((lcd.height - side) / 2)
            width: side
            height: side
            source: player.artworkUrl
            corner: 3
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: lcd.expand() }
            Accessible.role: Accessible.Button
            Accessible.name: "Open full screen player"
        }

        // title / artist / scrubber, centred vertically as one block
        Item {
            id: block
            x: art.x + art.width + 10
            width: lcd.width - x - 14
            y: Math.round((lcd.height - lcd.blockH) / 2)
            height: lcd.blockH
            clip: true

            Text {
                x: 0; y: 0
                width: parent.width; height: lcd.lineH
                text: player.title
                elide: Text.ElideRight
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody - 1
                font.weight: Font.Medium
            }
            Text {
                x: 0; y: lcd.lineH
                width: parent.width; height: lcd.lineH
                text: player.loading ? "Loading…" : player.artist + (player.album.length ? " — " + player.album : "")
                elide: Text.ElideRight
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody - 1
            }
            Item {
                id: scrub
                x: 0
                y: 2 * lcd.lineH + lcd.gap
                width: parent.width
                height: lcd.rowH

                Text {
                    id: elapsed
                    x: 0; y: 0
                    width: 32; height: parent.height
                    text: Theme.fmt(player.position)
                    verticalAlignment: Text.AlignVCenter
                    color: Theme.textSecondary
                    font.family: Theme.fontFamily
                    font.pixelSize: 10
                }
                Text {
                    id: remaining
                    x: parent.width - width; y: 0
                    width: 32; height: parent.height
                    horizontalAlignment: Text.AlignRight
                    verticalAlignment: Text.AlignVCenter
                    text: Theme.fmtRemaining(player.position, player.duration)
                    color: Theme.textSecondary
                    font.family: Theme.fontFamily
                    font.pixelSize: 10
                }
                ProgressSlider {
                    x: elapsed.width + 6
                    y: 0
                    width: parent.width - elapsed.width - remaining.width - 12
                    height: parent.height
                    to: Math.max(1, player.duration)
                    value: player.position
                    onCommitted: (v) => player.seek(v)
                }
            }
        }
    }
}
