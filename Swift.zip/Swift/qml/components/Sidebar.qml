import QtQuick
import QtQuick.Controls
import QtQuick.Effects
import QtQuick.Layouts
import Swift

// Floating source list, like the Music sidebar: search on top, Home, then Library and
// Playlists groups. It sits above the page content, which scrolls underneath it: a blurred,
// tinted copy of `glassSource` (the content layer) is drawn behind the controls.
// `topInset` aligns the first row with the toolbar; the traffic lights live in the top-left.
Item {
    id: sb
    property string current
    property real topInset: 11
    property Item glassSource                 // the item that shows through the glass
    property bool dragsWindow: false          // frameless window: the top strip moves it
    property string currentPlaylist: ""      // id of the playlist page that is open
    property alias searchField: search
    readonly property bool blurAvailable: GraphicsInfo.api !== GraphicsInfo.Software
    signal navigate(string page)
    signal searchSubmitted(string text)
    signal openPlaylist(string id)
    signal newPlaylist()
    signal editPlaylist(string id)
    signal deletePlaylist(string id)
    signal toggleSidebar()
    signal startDrag()
    clip: true

    // 1. solid base: the edges of the blur never go see-through, and it is the whole
    //    background when blur is unavailable (software rendering)
    Rectangle { anchors.fill: parent; color: Theme.sidebar }

    // 2. what is behind the sidebar, blurred. The source rect follows the sidebar while it slides.
    ShaderEffectSource {
        id: backdrop
        visible: false
        live: sb.visible && sb.blurAvailable && sb.glassSource !== null
        sourceItem: sb.blurAvailable ? sb.glassSource : null
        sourceRect: Qt.rect(sb.x, sb.y, width, height)
        width: sb.width + 48                  // a little extra so the blur has no faded right edge
        height: sb.height
    }
    MultiEffect {
        visible: sb.blurAvailable && sb.glassSource !== null
        width: backdrop.width
        height: backdrop.height
        source: backdrop
        autoPaddingEnabled: false
        blurEnabled: true
        blurMax: 48
        blur: 1.0
        saturation: 0.3
    }

    // 3. glass tint
    Rectangle {
        anchors.fill: parent
        color: sb.blurAvailable && sb.glassSource !== null ? Theme.sidebarGlass : Theme.sidebar
    }

    Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: Theme.separator }

    // Don't let clicks or the wheel fall through to the page underneath.
    MouseArea { anchors.fill: parent; acceptedButtons: Qt.AllButtons; onWheel: (w) => w.accepted = true }

    // Title-bar strip that drags a frameless window (sits under the buttons).
    Item {
        width: parent.width
        height: Theme.toolbarHeight
        DragHandler {
            target: null
            enabled: sb.dragsWindow
            onActiveChanged: if (active) sb.startDrag()
        }
    }

    component Header: Text {
        color: Theme.textSecondary
        font.family: Theme.fontFamily
        font.pixelSize: Theme.sizeSmall + 1
        font.weight: Font.DemiBold
        Layout.topMargin: 14
        Layout.leftMargin: 9
        Layout.bottomMargin: 3
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 11
        anchors.topMargin: sb.topInset
        anchors.bottomMargin: 10
        spacing: 1

        RowLayout {
            Layout.fillWidth: true
            Layout.bottomMargin: 8
            Item { Layout.fillWidth: true }
            IconButton { glyph: "sidebar"; size: 17; color: Theme.textSecondary; tip: "Hide sidebar"; onClicked: sb.toggleSidebar() }
        }

        SearchField {
            id: search
            Layout.fillWidth: true
            Layout.bottomMargin: 8
            onSubmitted: (t) => sb.searchSubmitted(t)
        }

        NavItem { Layout.fillWidth: true; glyph: "home"; label: "Home"; selected: sb.current === "home"; onClicked: sb.navigate("home") }

        // Library and playlists scroll, so a long list of playlists never pushes
        // Info and Settings off the bottom.
        Flickable {
            id: scroller
            Layout.fillWidth: true
            Layout.fillHeight: true
            contentWidth: width
            contentHeight: libCol.implicitHeight
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

            ColumnLayout {
                id: libCol
                width: scroller.width
                spacing: 1

                Header { text: "Library" }
                NavItem { Layout.fillWidth: true; glyph: "clock"; label: "Recently Played"; selected: sb.current === "recent"; onClicked: sb.navigate("recent") }
                NavItem { Layout.fillWidth: true; glyph: "heart"; label: "Liked Songs"; selected: sb.current === "liked"; onClicked: sb.navigate("liked") }
                NavItem { Layout.fillWidth: true; glyph: "playlist"; label: "Playlists"; selected: sb.current === "myplaylists"; onClicked: sb.navigate("myplaylists") }
                NavItem { Layout.fillWidth: true; glyph: "mic"; label: "Artists"; selected: sb.current === "artists"; onClicked: sb.navigate("artists") }
                NavItem { Layout.fillWidth: true; glyph: "albums"; label: "Albums"; selected: sb.current === "albums"; onClicked: sb.navigate("albums") }

                RowLayout {
                    Layout.fillWidth: true
                    Layout.rightMargin: 2
                    Header { Layout.fillWidth: true; text: "My Playlists" }
                    IconButton {
                        Layout.topMargin: 10
                        glyph: "plus"; size: 13
                        implicitWidth: 22; implicitHeight: 22
                        color: Theme.textSecondary
                        tip: "New Playlist"
                        onClicked: sb.newPlaylist()
                    }
                }
                Repeater {
                    model: playlists.playlists
                    delegate: NavItem {
                        Layout.fillWidth: true
                        glyph: "list"
                        label: model.name
                        selected: sb.current === "playlist" && sb.currentPlaylist === model.playlistId
                        onClicked: sb.openPlaylist(model.playlistId)
                        onRightClicked: ctx.popup()
                        PlaylistMenu {
                            id: ctx
                            empty: model.trackCount === 0
                            onPlay: player.playTracks(playlists.tracksOf(model.playlistId), 0, false)
                            onShuffle: player.playTracks(playlists.tracksOf(model.playlistId), 0, true)
                            onEdit: sb.editPlaylist(model.playlistId)
                            onRemove: sb.deletePlaylist(model.playlistId)
                        }
                    }
                }
                Text {
                    visible: playlists.playlists.count === 0
                    Layout.fillWidth: true
                    Layout.leftMargin: 9
                    Layout.rightMargin: 6
                    Layout.topMargin: 2
                    wrapMode: Text.WordWrap
                    text: "No playlists yet. Click + to create one."
                    color: Theme.textTertiary
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.sizeBody - 1
                }
                NavItem { Layout.fillWidth: true; Layout.topMargin: 6; glyph: "albums"; label: "Browse Playlists"; selected: sb.current === "playlists"; onClicked: sb.navigate("playlists") }
            }
        }

        NavItem { Layout.fillWidth: true; glyph: "info"; label: "Info"; logo: Theme.logo; selected: sb.current === "info"; onClicked: sb.navigate("info") }
        NavItem { Layout.fillWidth: true; glyph: "sliders"; label: "Settings"; selected: sb.current === "settings"; onClicked: sb.navigate("settings") }
    }
}
