import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

Flickable {
    id: f
    default property alias content: col.data
    property real margin: availableWidth < 600 ? 18 : 28
    // Pages are laid out under the floating glass sidebar; this keeps the content clear of it.
    readonly property real availableWidth: width - inset   // page width minus the area under the sidebar
    readonly property real inset: Window.window && Window.window.sidebarInset !== undefined ? Window.window.sidebarInset : 0
    // Room left at the bottom for the floating player bar (0 when it is docked at the top).
    readonly property real bottomInset: Window.window && Window.window.playerBarInset !== undefined ? Window.window.playerBarInset : 0
    property alias spacing: col.spacing

    contentWidth: width
    contentHeight: col.implicitHeight + 56 + bottomInset
    clip: true
    boundsBehavior: Flickable.StopAtBounds
    ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

    ColumnLayout {
        id: col
        x: f.margin + f.inset
        y: 20
        width: f.width - 2 * f.margin - f.inset
        spacing: 16
    }
}
