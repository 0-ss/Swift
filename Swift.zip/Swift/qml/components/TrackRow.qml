import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

// One row of Music's song table. Row actions (play, like, "…") only appear on hover;
// a liked song keeps its heart visible. Double-click or Return plays.
// Column geometry must match TrackHeader.
Rectangle {
    id: row
    property string videoId
    property string title
    property string artist
    property string album
    property url artworkUrl
    property real durationMs: 0
    property bool isCurrent: false
    property bool striped: false
    property bool numbered: false      // show a track number instead of artwork
    property int trackNumber: 0
    signal activated()
    signal favoriteToggled()
    signal enqueueRequested()
    signal playNextRequested()
    // Set by playlist pages: adds "Remove from Playlist" and, when in the playlist's own order, "Move".
    property bool inPlaylist: false
    property bool canReorder: false
    signal removeRequested()
    signal moveRequested(string where)

    function newPlaylistWithThis() { Window.window.newPlaylist([trackMap()]) }
    function trackMap() {
        return { videoId: videoId, title: title, artist: artist, album: album,
                 artworkUrl: artworkUrl.toString(), durationMs: durationMs }
    }

    readonly property bool liked: library.favoriteIds.indexOf(videoId) >= 0
    readonly property bool hovered: hover.hovered
    readonly property bool showArtist: width >= 560
    readonly property bool showAlbum: width >= 760 && !numbered

    implicitHeight: numbered ? 38 : 52
    radius: Theme.rSm
    color: striped ? Theme.stripe : "transparent"
    activeFocusOnTab: true
    border.width: activeFocus ? 2 : 0
    border.color: Theme.accent
    Keys.onReturnPressed: activated()
    Accessible.role: Accessible.ListItem
    Accessible.name: title + ", " + artist

    HoverHandler { id: hover }

    Rectangle { anchors.fill: parent; radius: parent.radius; color: Theme.hover; visible: row.hovered }

    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onDoubleClicked: (m) => { if (m.button === Qt.LeftButton) row.activated() }
        onClicked: (m) => { if (m.button === Qt.RightButton) menu.popup() }
    }

    TrackMenu {
        id: menu
        liked: row.liked
        onPlayNext: row.playNextRequested()
        onAddToQueue: row.enqueueRequested()
        onToggleLike: row.favoriteToggled()
        inPlaylist: row.inPlaylist
        canReorder: row.canReorder
        onAddToPlaylist: (id) => playlists.addTrack(id, row.trackMap())
        onNewPlaylist: row.newPlaylistWithThis()
        onRemoveFromPlaylist: row.removeRequested()
        onMoveRequested: (where) => row.moveRequested(where)
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 8
        spacing: 12

        // lead cell: artwork (or number) with hover play / now-playing bars
        Item {
            Layout.preferredWidth: row.numbered ? 26 : 40
            Layout.preferredHeight: row.numbered ? 26 : 40
            Layout.alignment: Qt.AlignVCenter

            Text {
                visible: row.numbered && !row.hovered && !row.isCurrent
                anchors.centerIn: parent
                text: row.trackNumber
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
            }
            Equalizer {
                visible: row.numbered && row.isCurrent && !row.hovered
                anchors.centerIn: parent
                running: player.playing
            }
            Glyph {
                visible: row.numbered && row.hovered
                anchors.centerIn: parent
                name: "play"; size: 14
                color: row.isCurrent ? Theme.accent : Theme.text
            }

            Artwork {
                visible: !row.numbered
                anchors.fill: parent
                source: row.artworkUrl
                corner: Theme.rSm
                Rectangle {
                    anchors.fill: parent
                    radius: Theme.rSm
                    color: Theme.alpha("#000000", 0.45)
                    visible: row.hovered || row.isCurrent
                    Glyph { visible: row.hovered; anchors.centerIn: parent; anchors.horizontalCenterOffset: 1; name: "play"; size: 15; color: "white" }
                    Equalizer { visible: !row.hovered && row.isCurrent; anchors.centerIn: parent; color: "white"; running: player.playing }
                }
            }
            MouseArea { anchors.fill: parent; enabled: row.hovered; onClicked: row.activated() }
        }

        // title (and artist when the artist column is hidden)
        ColumnLayout {
            Layout.fillWidth: true
            Layout.alignment: Qt.AlignVCenter
            spacing: 1
            Text {
                Layout.fillWidth: true
                text: row.title
                elide: Text.ElideRight
                color: row.isCurrent ? Theme.accent : Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody
            }
            Text {
                visible: !row.showArtist && !row.numbered
                Layout.fillWidth: true
                text: row.artist
                elide: Text.ElideRight
                color: Theme.textSecondary
                font.family: Theme.fontFamily
                font.pixelSize: Theme.sizeBody - 1
            }
        }

        Text {
            Layout.preferredWidth: 46
            text: row.durationMs > 0 ? Theme.fmt(row.durationMs) : ""
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }
        Text {
            visible: row.showArtist
            Layout.preferredWidth: Math.round(row.width * 0.22)
            text: row.artist
            elide: Text.ElideRight
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }
        Text {
            visible: row.showAlbum
            Layout.preferredWidth: Math.round(row.width * 0.22)
            text: row.album
            elide: Text.ElideRight
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
        }

        // hover-only actions
        Item {
            Layout.preferredWidth: 64
            Layout.fillHeight: true
            Loader {
                anchors.fill: parent
                active: row.hovered || row.liked || menu.visible
                sourceComponent: Item {
                    IconButton {
                        x: 0; anchors.verticalCenter: parent.verticalCenter
                        glyph: row.liked ? "heartFill" : "heart"; size: 15
                        active: row.liked
                        implicitWidth: 28; implicitHeight: 28
                        tip: row.liked ? "Remove from Liked Songs" : "Add to Liked Songs"
                        color: Theme.textSecondary
                        onClicked: row.favoriteToggled()
                    }
                    IconButton {
                        x: 32; anchors.verticalCenter: parent.verticalCenter
                        visible: row.hovered || menu.visible
                        glyph: "ellipsis"; size: 16
                        implicitWidth: 28; implicitHeight: 28
                        tip: "More"
                        color: Theme.textSecondary
                        onClicked: menu.popup(row, row.width - 72, row.height - 6)
                    }
                }
            }
        }
    }
}
