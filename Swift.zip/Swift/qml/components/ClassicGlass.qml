import QtQuick
import QtQuick.Effects
import Swift

// The original floating-bar material: a blurred, tinted copy of `glassSource` (the content
// layer) clipped to a rounded shape, with a soft drop shadow and a hairline edge. Selected with
// Settings > Appearance > Floating bar style > Classic blur. Fill the bar with it.
Item {
    id: root
    property Item glassSource
    property real sourceX: 0
    property real sourceY: 0
    property real cornerRadius: 18
    readonly property bool blurAvailable: GraphicsInfo.api !== GraphicsInfo.Software

    // soft drop shadow
    Rectangle { id: shadowSrc; anchors.fill: parent; radius: root.cornerRadius; color: Theme.window; visible: false }
    MultiEffect {
        anchors.fill: shadowSrc
        source: shadowSrc
        shadowEnabled: true
        shadowColor: "black"
        shadowOpacity: Theme.dark ? 0.55 : 0.28
        shadowBlur: 1.0
        shadowVerticalOffset: 6
    }
    // the glass itself, clipped to the rounded shape
    Item { id: glassMask; anchors.fill: parent; visible: false; layer.enabled: true
        Rectangle { anchors.fill: parent; radius: root.cornerRadius; color: "black" } }
    Item {
        id: glass
        anchors.fill: parent
        layer.enabled: true
        layer.effect: MultiEffect { maskEnabled: true; maskSource: glassMask }

        // solid base: the blur's faded edges never go see-through, and it is the whole
        // background when blur is unavailable (software rendering)
        Rectangle { anchors.fill: parent; color: Theme.window }

        // what is behind the bar, blurred; padded so the blur has no faded edge inside the bar
        readonly property real pad: 32
        ShaderEffectSource {
            id: backdrop
            visible: false
            live: root.visible && root.blurAvailable && root.glassSource !== null
            sourceItem: root.blurAvailable ? root.glassSource : null
            sourceRect: Qt.rect(root.sourceX - glass.pad, root.sourceY - glass.pad, root.width + 2 * glass.pad, root.height + 2 * glass.pad)
            x: -glass.pad; y: -glass.pad
            width: root.width + 2 * glass.pad
            height: root.height + 2 * glass.pad
        }
        MultiEffect {
            visible: root.blurAvailable && root.glassSource !== null
            x: -glass.pad; y: -glass.pad
            width: backdrop.width
            height: backdrop.height
            source: backdrop
            autoPaddingEnabled: false
            blurEnabled: true
            blurMax: 48
            blur: 1.0
            saturation: 0.3
        }
        // glass tint
        Rectangle { anchors.fill: parent; color: root.blurAvailable && root.glassSource !== null ? Theme.toolbarGlass : Theme.toolbar }
    }
    // hairline edge
    Rectangle {
        anchors.fill: parent
        radius: root.cornerRadius
        color: "transparent"
        border.width: 1
        border.color: Theme.dark ? "#26FFFFFF" : "#1A000000"
    }
}
