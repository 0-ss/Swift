import QtQuick
import QtQuick.Layouts
import Swift

// Player bar: transport, volume, LCD, Up Next toggle. It either fills the top of the window
// (default, blurred, with the pages scrolling underneath) or, with `floating`, becomes a rounded Liquid Glass bar that hovers at the bottom: the content layer
// (`glassSource`) is refracted and tinted behind the controls (see LiquidGlass.qml).
Rectangle {
    id: tb
    property bool floating: false
    property bool hideSeparator: false         // docked bar: drop the hairline under it
    property bool liquid: true                // floating material: Liquid Glass, or the classic blur
    property Item glassSource                 // the item that shows through the glass
    property point pointer: Qt.point(0, 0)    // cursor position in window coordinates
    property bool pointerActive: false        // cursor is over the window
    property real leftInset: 0          // room for the window buttons when the sidebar is hidden
    property bool sidebarVisible: true
    property bool canGoBack: false
    property bool upNextOpen: false
    signal toggleSidebar()
    signal back()
    signal toggleUpNext()
    signal expandPlayer()

    implicitHeight: Theme.toolbarHeight
    radius: floating ? 18 : 0
    color: "transparent"

    // ---- floating glass (only exists while floating) ----------------------------------------
    // Apple-style Liquid Glass: refracting, lit-rim glass with its own soft shadow.
    LiquidGlass {
        anchors.fill: parent
        visible: tb.floating && tb.liquid
        glassSource: tb.glassSource
        sourceX: tb.x
        sourceY: tb.y
        pointerX: tb.pointer.x - tb.x
        pointerY: tb.pointer.y - tb.y
        pointerActive: tb.pointerActive
        cornerRadius: tb.radius
    }

    // Settings > Appearance > Floating bar style > Classic blur: the original frosted glass
    Loader {
        anchors.fill: parent
        active: tb.floating && !tb.liquid
        sourceComponent: ClassicGlass {
            glassSource: tb.glassSource
            sourceX: tb.x
            sourceY: tb.y
            cornerRadius: tb.radius
        }
    }

    // Docked at the top: the same blur as the floating bar (classic frosted glass), but flat,
    // edge to edge, with no shadow or outline. Pages run underneath it and show through. The tint
    // follows the window colour so the bar matches the app in light and dark mode.
    Loader {
        anchors.fill: parent
        active: !tb.floating
        sourceComponent: ClassicGlass {
            glassSource: tb.glassSource
            sourceX: tb.x
            sourceY: tb.y
            cornerRadius: 0
            shadow: false
            outline: false
            tint: Theme.toolbarBlurTint
            fallback: Theme.window
        }
    }

    // top toolbar: hairline under the bar
    Rectangle { visible: !tb.floating && !tb.hideSeparator; anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.separator }

    // Don't let clicks or the wheel fall through to the page underneath the floating bar.
    MouseArea { anchors.fill: parent; enabled: tb.floating; acceptedButtons: Qt.AllButtons; onWheel: (w) => w.accepted = true }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: (tb.floating ? 16 : 12) + tb.leftInset
        anchors.rightMargin: tb.floating ? 16 : 12
        // docked: leave the 1px separator line out of the centring (50px area), so every
        // control lands on a whole pixel; floating: the full 64px
        anchors.topMargin: tb.floating ? 0 : 1
        anchors.bottomMargin: tb.floating ? 0 : 1
        spacing: 6

        // in floating mode these two live in the strip at the top of the window instead
        IconButton {
            visible: !tb.floating && !tb.sidebarVisible
            glyph: "sidebar"; size: 17; color: Theme.textSecondary; tip: "Show sidebar"
            onClicked: tb.toggleSidebar()
        }
        IconButton {
            visible: !tb.floating && tb.canGoBack
            glyph: "back"; size: 16; tip: "Back"
            onClicked: tb.back()
        }

        // transport. A RowLayout (not a Row, which top-aligns) so the larger play button and
        // its neighbours share one vertical centre; all heights are even so nothing lands on a
        // half pixel inside the bar.
        RowLayout {
            spacing: 2
            Layout.alignment: Qt.AlignVCenter
            IconButton { Layout.alignment: Qt.AlignVCenter; glyph: "shuffle"; size: 16; tip: "Shuffle"; active: player.shuffle; onClicked: player.shuffle = !player.shuffle }
            IconButton { Layout.alignment: Qt.AlignVCenter; glyph: "prev"; size: 20; tip: "Previous"; enabled: player.hasTrack; onClicked: player.previous() }
            IconButton {
                Layout.alignment: Qt.AlignVCenter
                glyph: player.playing ? "pause" : "play"; size: 24
                implicitWidth: 38; implicitHeight: 34
                tip: player.playing ? "Pause" : "Play"
                enabled: player.hasTrack
                onClicked: player.togglePlayback()
            }
            IconButton { Layout.alignment: Qt.AlignVCenter; glyph: "next"; size: 20; tip: "Next"; enabled: player.hasTrack; onClicked: player.next() }
            IconButton {
                Layout.alignment: Qt.AlignVCenter
                glyph: player.repeatMode === 2 ? "repeatOne" : "repeat"; size: 16; tip: "Repeat"
                active: player.repeatMode > 0
                onClicked: player.cycleRepeat()
            }
        }

        // volume
        RowLayout {
            visible: tb.width > (tb.floating ? 740 : 880)
            Layout.leftMargin: 10
            Layout.alignment: Qt.AlignVCenter
            spacing: 6
            Glyph { Layout.preferredWidth: 14; Layout.preferredHeight: 14; name: "speakerMute"; size: 14; color: Theme.textSecondary }
            ProgressSlider {
                Layout.preferredWidth: 88
                value: player.volume
                onMoved: (v) => player.volume = v
                onCommitted: (v) => player.volume = v
            }
            Glyph { Layout.preferredWidth: 16; Layout.preferredHeight: 16; name: "speakerWave"; size: 16; color: Theme.textSecondary }
        }

        Item { Layout.fillWidth: true; Layout.preferredWidth: 0 }
        LCD {
            tall: tb.floating
            Layout.fillWidth: true
            Layout.minimumWidth: 200
            Layout.preferredWidth: 480
            Layout.maximumWidth: 560
            Layout.alignment: Qt.AlignVCenter
            onExpand: tb.expandPlayer()
        }
        Item { Layout.fillWidth: true; Layout.preferredWidth: 0 }

        IconButton {
            Layout.alignment: Qt.AlignVCenter
            glyph: "upnext"; size: 18; tip: "Up Next"
            active: tb.upNextOpen
            onClicked: tb.toggleUpNext()
        }
    }
}
