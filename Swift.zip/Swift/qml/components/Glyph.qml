import QtQuick
import Swift

// Small vector icon set drawn on a 20x20 grid so no image assets are needed.
Canvas {
    id: g
    property string name
    property color color: Theme.text
    property real size: 20
    width: size
    height: size
    onNameChanged: requestPaint()
    onColorChanged: requestPaint()
    onSizeChanged: requestPaint()
    Connections { target: Theme; function onDarkChanged() { g.requestPaint() } }

    onPaint: {
        const ctx = getContext("2d")
        ctx.reset()
        ctx.scale(width / 20, height / 20)
        ctx.fillStyle = color
        ctx.strokeStyle = color
        ctx.lineWidth = 1.6
        ctx.lineCap = "round"
        ctx.lineJoin = "round"
        const line = (pts) => {
            ctx.beginPath(); ctx.moveTo(pts[0], pts[1])
            for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1])
            ctx.stroke()
        }
        // Filled polygon with a thin same-colour stroke so corners read as softly rounded.
        const poly = (pts) => {
            ctx.beginPath(); ctx.moveTo(pts[0], pts[1])
            for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1])
            ctx.closePath(); ctx.fill()
            ctx.lineWidth = 1.4; ctx.stroke(); ctx.lineWidth = 1.6
        }
        const rrect = (x, y, w, h, r, fill) => {
            ctx.beginPath(); ctx.roundedRect(x, y, w, h, r, r)
            if (fill) ctx.fill(); else ctx.stroke()
        }
        const dot = (x, y, r) => { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill() }
        const heart = () => {
            ctx.beginPath(); ctx.moveTo(10, 16.5)
            ctx.bezierCurveTo(2, 11, 2.5, 4.5, 6.5, 4.5)
            ctx.bezierCurveTo(8.3, 4.5, 9.4, 5.5, 10, 6.8)
            ctx.bezierCurveTo(10.6, 5.5, 11.7, 4.5, 13.5, 4.5)
            ctx.bezierCurveTo(17.5, 4.5, 18, 11, 10, 16.5)
            ctx.closePath()
        }
        const speaker = () => poly([2.5, 7.8, 6, 7.8, 10.5, 4.2, 10.5, 15.8, 6, 12.2, 2.5, 12.2])
        switch (name) {
        case "play": poly([5.5, 3.6, 16.5, 10, 5.5, 16.4]); break
        case "pause": rrect(4.8, 3.5, 3.9, 13, 1.1, true); rrect(11.3, 3.5, 3.9, 13, 1.1, true); break
        case "next": poly([2.5, 4.5, 10, 10, 2.5, 15.5]); poly([10, 4.5, 17.5, 10, 10, 15.5]); break
        case "prev": poly([17.5, 4.5, 10, 10, 17.5, 15.5]); poly([10, 4.5, 2.5, 10, 10, 15.5]); break
        case "heart": heart(); ctx.stroke(); break
        case "heartFill": heart(); ctx.fill(); break
        case "speakerMute": speaker(); break
        case "speaker":
            speaker()
            ctx.beginPath(); ctx.arc(10.5, 10, 4.2, -0.75, 0.75); ctx.stroke(); break
        case "speakerWave":
            speaker()
            ctx.beginPath(); ctx.arc(10.5, 10, 3.8, -0.75, 0.75); ctx.stroke()
            ctx.beginPath(); ctx.arc(10.5, 10, 7, -0.75, 0.75); ctx.stroke(); break
        case "search":
            ctx.beginPath(); ctx.arc(8.5, 8.5, 5.5, 0, Math.PI * 2); ctx.stroke()
            line([12.6, 12.6, 17, 17]); break
        case "list": case "queue": case "upnext":
            dot(3.5, 5, 1.1); dot(3.5, 10, 1.1); dot(3.5, 15, 1.1)
            line([7, 5, 17, 5]); line([7, 10, 17, 10]); line([7, 15, 13, 15]); break
        case "home":
            poly([10, 2.8, 17.6, 9.4, 15.6, 9.4, 15.6, 16.8, 4.4, 16.8, 4.4, 9.4, 2.4, 9.4]); break
        case "note":
            dot(6.5, 15, 2.5); dot(13.5, 13, 2.5)
            line([9, 15, 9, 4.5, 16, 3, 16, 13]); break
        case "mic":
            rrect(7.3, 2.5, 5.4, 9.5, 2.7, false)
            ctx.beginPath(); ctx.arc(10, 9.5, 5.6, 0.1, Math.PI - 0.1); ctx.stroke()
            line([10, 15.2, 10, 17.5]); break
        case "albums":
            rrect(3.2, 6.8, 13.6, 10, 2, false)
            line([6, 4, 14, 4]); ctx.globalAlpha = 0.7; line([8, 1.8, 12, 1.8]); ctx.globalAlpha = 1
            dot(8.3, 13.4, 1.5); line([9.8, 13.4, 9.8, 9.8]); break
        case "clock":
            ctx.beginPath(); ctx.arc(10, 10, 7, 0, Math.PI * 2); ctx.stroke()
            line([10, 5.5, 10, 10, 13.5, 12]); break
        case "sliders":
            line([3, 6, 17, 6]); line([3, 14, 17, 14])
            ctx.fillStyle = Theme.sidebar
            ctx.beginPath(); ctx.arc(7, 6, 2.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke()
            ctx.beginPath(); ctx.arc(13, 14, 2.4, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); break
        case "info":
            ctx.beginPath(); ctx.arc(10, 10, 7.2, 0, Math.PI * 2); ctx.stroke()
            dot(10, 6.4, 1.05); line([10, 9.2, 10, 14]); break
        case "sidebar":
            rrect(2.5, 4, 15, 12, 2.4, false); line([8, 4.4, 8, 15.6]); break
        case "ellipsis": dot(4.5, 10, 1.5); dot(10, 10, 1.5); dot(15.5, 10, 1.5); break
        case "shuffle":
            ctx.beginPath(); ctx.moveTo(2.5, 6); ctx.lineTo(5.5, 6); ctx.bezierCurveTo(9.5, 6, 9.5, 14, 13.5, 14); ctx.lineTo(15, 14); ctx.stroke()
            ctx.beginPath(); ctx.moveTo(2.5, 14); ctx.lineTo(5.5, 14); ctx.bezierCurveTo(9.5, 14, 9.5, 6, 13.5, 6); ctx.lineTo(15, 6); ctx.stroke()
            poly([14.2, 11.6, 17.8, 14, 14.2, 16.4]); poly([14.2, 3.6, 17.8, 6, 14.2, 8.4]); break
        case "repeat": case "repeatOne":
            line([4, 10, 4, 7, 15, 7]); poly([13.6, 4.6, 17.4, 7, 13.6, 9.4])
            line([16, 10, 16, 13, 5, 13]); poly([6.4, 10.6, 2.6, 13, 6.4, 15.4])
            if (name === "repeatOne") { ctx.font = "bold 8px sans-serif"; ctx.fillText("1", 8.6, 11.4) }
            break
        case "playlist":
            line([3, 5, 12, 5]); line([3, 10, 10, 10]); line([3, 15, 8, 15])
            poly([12.5, 9, 17.5, 12.5, 12.5, 16]); break
        case "check": line([4.5, 10.5, 8.5, 14.5, 15.5, 6]); break
        case "close": line([5, 5, 15, 15]); line([15, 5, 5, 15]); break
        case "plus": line([10, 4, 10, 16]); line([4, 10, 16, 10]); break
        case "chevronDown": line([4, 7, 10, 13, 16, 7]); break
        case "chevronUp": line([4, 13, 10, 7, 16, 13]); break
        case "back": case "chevronLeft": line([12, 4, 6, 10, 12, 16]); break
        case "chevronRight": line([8, 4, 14, 10, 8, 16]); break
        }
    }
}
