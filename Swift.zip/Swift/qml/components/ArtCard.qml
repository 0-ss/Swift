import QtQuick
import QtQuick.Layouts
import Swift

// Shelf card: square cover, title and subtitle below. On hover the cover dims and,
// for playable cards, a play button appears bottom-left (as in Music).
Item {
    id: c
    property string title
    property string subtitle
    property url artworkUrl
    property bool round: false
    property bool showPlay: false
    property real cardWidth: 176
    signal clicked()
    signal playRequested()

    implicitWidth: cardWidth
    implicitHeight: art.height + col.implicitHeight + 8
    activeFocusOnTab: true
    Keys.onReturnPressed: clicked()
    Keys.onSpacePressed: clicked()
    Accessible.role: Accessible.Button
    Accessible.name: title

    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        onClicked: c.clicked()
    }

    Artwork {
        id: art
        width: c.cardWidth
        height: c.cardWidth
        source: c.artworkUrl
        round: c.round
        corner: Theme.rMd
        Rectangle {
            anchors.fill: parent
            radius: art.radius
            border.width: c.activeFocus ? 2 : 0
            border.color: Theme.accent
            gradient: Gradient {
                GradientStop { position: 0.0; color: "transparent" }
                GradientStop { position: 1.0; color: Theme.alpha("#000000", 0.38) }
            }
            opacity: ma.containsMouse || playMa.containsMouse ? 1 : (c.activeFocus ? 1 : 0)
            Behavior on opacity { NumberAnimation { duration: Theme.fast } }
        }
        Rectangle {
            visible: c.showPlay
            x: 10; y: parent.height - height - 10
            width: 32; height: 32; radius: 16
            color: playMa.pressed ? Theme.alpha("#000000", 0.75) : Theme.alpha("#000000", 0.55)
            opacity: ma.containsMouse || playMa.containsMouse ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Theme.fast } }
            Glyph { anchors.centerIn: parent; anchors.horizontalCenterOffset: 1; name: "play"; size: 15; color: "white" }
            MouseArea { id: playMa; anchors.fill: parent; hoverEnabled: true; onClicked: c.playRequested() }
            Accessible.role: Accessible.Button
            Accessible.name: "Play " + c.title
        }
    }
    ColumnLayout {
        id: col
        anchors.top: art.bottom
        anchors.topMargin: 8
        width: c.cardWidth
        spacing: 1
        Text {
            Layout.fillWidth: true
            text: c.title
            elide: Text.ElideRight
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody
            font.weight: Font.Medium
            horizontalAlignment: c.round ? Text.AlignHCenter : Text.AlignLeft
        }
        Text {
            Layout.fillWidth: true
            text: c.subtitle
            elide: Text.ElideRight
            color: Theme.textSecondary
            font.family: Theme.fontFamily
            font.pixelSize: Theme.sizeBody - 1
            visible: text.length > 0
            horizontalAlignment: c.round ? Text.AlignHCenter : Text.AlignLeft
        }
    }
}
