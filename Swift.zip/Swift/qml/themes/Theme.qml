pragma Singleton
import QtQuick

// Visual tokens modelled on Apple Music for macOS (Sonoma-era): neutral grays,
// a single red accent, 13 pt body text, small corner radii.
QtObject {
    // Set from Main.qml via Bindings to the persisted settings.
    property int mode: 0            // 0 system, 1 light, 2 dark
    property color accent: "#FA233B"
    property bool reduceMotion: false

    // App logo (the image inside qml/assets/image.ico), used by the Info button and Info page.
    readonly property url logo: Qt.resolvedUrl("../assets/image.png")

    readonly property bool dark: mode === 2
        || (mode === 0 && Application.styleHints.colorScheme === Qt.Dark)

    // surfaces
    readonly property color window: dark ? "#1E1E1E" : "#FFFFFF"
    readonly property color sidebar: dark ? "#2A2A2C" : "#F0F0F1"
    // translucent tint laid over the blurred content behind the sidebar
    readonly property color sidebarGlass: dark ? "#A6262628" : "#A6F2F2F4"
    readonly property color toolbar: dark ? "#2B2B2D" : "#F9F9F9"
    // translucent tint laid over the blurred content behind the floating player bar
    readonly property color toolbarGlass: dark ? "#B3262628" : "#B8F6F6F8"
    // Liquid Glass tint for the floating bar: mostly clear, just enough to keep text legible
    readonly property color glassTint: dark ? "#4D1C1C1E" : "#4DFFFFFF"
    readonly property color card: dark ? "#2A2A2C" : "#F5F5F6"
    readonly property color cardRaised: dark ? "#3A3A3C" : "#FFFFFF"
    readonly property color menu: dark ? "#3A3A3C" : "#FFFFFF"
    readonly property color stripe: dark ? "#252527" : "#F6F6F7"
    readonly property color separator: dark ? "#3B3B3D" : "#E4E4E6"

    // text
    readonly property color text: dark ? "#F5F5F7" : "#1D1D1F"
    readonly property color textSecondary: dark ? "#9A9A9F" : "#7C7C80"
    readonly property color textTertiary: dark ? "#6C6C70" : "#A8A8AC"
    readonly property color accentForeground: "#FFFFFF"
    readonly property color accentText: accentForeground

    // controls
    readonly property color fill: dark ? "#3A3A3C" : "#EBEBED"
    readonly property color fillHover: dark ? "#444446" : "#E2E2E5"
    readonly property color fillPressed: dark ? "#4E4E50" : "#D8D8DC"
    readonly property color hover: dark ? "#14FFFFFF" : "#0D000000"
    readonly property color pressed: dark ? "#24FFFFFF" : "#1A000000"
    readonly property color lcd: dark ? "#1AFFFFFF" : "#0A000000"
    readonly property color lcdBorder: dark ? "#1FFFFFFF" : "#14000000"
    readonly property color sliderTrack: dark ? "#33FFFFFF" : "#1F000000"
    readonly property color sliderFill: dark ? "#B8B8BC" : "#7E7E82"
    readonly property color shadow: dark ? "#99000000" : "#33000000"

    readonly property string fontFamily: Qt.platform.os === "osx" ? ".AppleSystemUIFont"
        : Qt.platform.os === "windows" ? "Segoe UI Variable Text"
        : "Inter"

    readonly property string mod: Qt.platform.os === "osx" ? "⌘" : "Ctrl+"

    readonly property int rSm: 5
    readonly property int rMd: 7
    readonly property int rLg: 10
    readonly property int rXl: 12

    readonly property int fast: reduceMotion ? 0 : 120
    readonly property int base: reduceMotion ? 0 : 200

    readonly property int sizeTitle: 28
    readonly property int sizeHeading: 20
    readonly property int sizeBody: 13
    readonly property int sizeSmall: 11

    readonly property int toolbarHeight: 52

    function alpha(c, a) { return Qt.rgba(c.r, c.g, c.b, a) }

    function fmt(ms) {
        const s = Math.max(0, Math.floor(ms / 1000))
        const m = Math.floor(s / 60)
        return m + ":" + (s % 60 < 10 ? "0" : "") + (s % 60)
    }
    function fmtRemaining(pos, dur) { return dur > 0 ? "-" + fmt(Math.max(0, dur - pos)) : "" }
}
