import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Swift

ApplicationWindow {
    id: win
    width: 1180
    height: 780
    minimumWidth: 760
    minimumHeight: 520
    visible: true
    title: player.hasTrack ? player.title + " — " + player.artist : "Swift"
    color: Theme.window
    font.family: Theme.fontFamily
    font.pixelSize: Theme.sizeBody

    // Window chrome. With "Show macOS window buttons" on, the native frame is dropped and Swift
    // draws its own traffic lights. With it off, the platform title bar is used: on macOS with
    // Qt 6.9+ it is merged into the toolbar (native buttons float over the sidebar), elsewhere it
    // is the ordinary title bar above the content.
    readonly property bool customChrome: settings.values.showWindowButtons
    readonly property bool unifiedTitleBar: !customChrome && Qt.platform.os === "osx"
                                            && typeof Qt.ExpandedClientAreaHint !== "undefined"
    readonly property bool zoomed: visibility === Window.Maximized || visibility === Window.FullScreen
    readonly property real lightsRoom: customChrome || unifiedTitleBar ? 78 : 0   // space the buttons need
    flags: customChrome ? (Qt.Window | Qt.FramelessWindowHint)
         : unifiedTitleBar ? (Qt.Window | Qt.ExpandedClientAreaHint)
         : Qt.Window

    property string page: "home"
    property bool nowPlayingOpen: false
    property bool sidebarOpen: true
    property bool upNextOpen: false
    property string playlistId: ""     // playlist shown on the playlist page
    property string notice: ""         // short confirmation shown in the toast
    readonly property bool pushUpNext: width >= 1040   // narrower windows overlay the panel instead

    // Player bar: docked in the top toolbar (default) or floating as a glass bar at the bottom.
    readonly property bool floatingBar: settings.values.floatingPlayerBar
    readonly property real floatingBarHeight: 64
    readonly property real floatingBarGap: 16
    // Docked bar: pages run underneath it (it is blurred glass), so they start this far down.
    readonly property real pageTopInset: floatingBar ? 0 : Theme.toolbarHeight
    // how much room pages leave at the bottom so their last rows scroll clear of the floating bar
    property real playerBarInset: floatingBar ? floatingBarHeight + floatingBarGap + 12 : 0
    Behavior on playerBarInset { NumberAnimation { duration: Theme.base; easing.type: Easing.OutCubic } }

    // The sidebar sits above the content. Pages are laid out clear of it (see PageScaffold),
    // but extend underneath, so wide rows such as shelves slide beneath the glass.
    // Settings > Appearance > Sidebar: "Floating" insets the panel by `sidebarGap` on every side
    // as a rounded glass card; "Docked" is the full-height column flush with the window edge.
    readonly property bool floatingSidebar: settings.values.floatingSidebar
    readonly property real sidebarGap: floatingSidebar ? 10 : 0
    readonly property real sidebarWidth: 210                          // the panel itself
    readonly property real sidebarSpace: sidebarWidth + 2 * sidebarGap // what the pages must clear
    property real sidebarInset: sidebarOpen ? sidebarSpace : 0
    Behavior on sidebarInset { NumberAnimation { duration: Theme.base; easing.type: Easing.OutCubic } }
    // 0 (hidden) .. 1 (shown), follows the slide animation
    readonly property real sidebarOpenness: sidebarSpace > 0 ? sidebarInset / sidebarSpace : 0

    Binding { target: Theme; property: "mode"; value: settings.values.themeMode }
    Binding { target: Theme; property: "accent"; value: settings.values.accentColor }
    Binding { target: Theme; property: "reduceMotion"; value: settings.values.reduceMotion }

    // ---- navigation ------------------------------------------------------
    function go(name) {
        page = name
        nowPlayingOpen = false
        switch (name) {
        case "home": stack.replace(null, homePage); break
        case "search": stack.replace(null, searchPage, {}); break
        case "recent": stack.replace(null, libraryPage, { mode: "recent" }); break
        case "liked": stack.replace(null, libraryPage, { mode: "liked" }); break
        case "albums": stack.replace(null, searchPage, { fixedFilter: 2, heading: "Albums" }); break
        case "artists": stack.replace(null, searchPage, { fixedFilter: 3, heading: "Artists" }); break
        case "playlists": stack.replace(null, searchPage, { fixedFilter: 4, heading: "Playlists" }); break
        case "myplaylists": stack.replace(null, playlistsPage); break
        case "info": stack.replace(null, infoPage); break
        case "settings": stack.replace(null, settingsPage); break
        }
    }
    function openDetail() { stack.push(collectionPage) }

    // ---- playlists ---------------------------------------------------------
    function openPlaylist(id) {
        playlists.open(id)
        playlistId = id
        page = "playlist"
        nowPlayingOpen = false
        stack.replace(null, playlistPage)
    }
    // `tracks`: songs to add right away (an array of track maps), or [] for an empty playlist
    function newPlaylist(tracks) { editor.openCreate(tracks || []) }
    function editPlaylist(id) { editor.openEdit(id) }
    function deletePlaylist(id) {
        const name = playlists.info(id).name
        confirm.ask("Delete “" + name + "”?",
                    "The playlist will be removed from Swift. The songs in it aren’t affected.",
                    "Delete", () => playlists.remove(id))
    }
    function runSearch(text) {
        const f = page === "albums" ? 2 : page === "artists" ? 3 : page === "playlists" ? 4
                : page === "search" ? app.filter : 0
        if (["search", "albums", "artists", "playlists"].indexOf(page) < 0 || stack.depth > 1) go("search")
        app.search(text, f)
    }
    function focusSearch() {
        sidebarOpen = true
        Qt.callLater(() => sidebar.searchField.field.forceActiveFocus())
    }

    Component { id: homePage; HomePage {} }
    Component { id: searchPage; SearchPage {} }
    Component { id: libraryPage; LibraryPage {} }
    Component { id: settingsPage; SettingsPage {} }
    Component { id: infoPage; InfoPage {} }
    Component { id: collectionPage; CollectionPage {} }
    Component { id: playlistsPage; PlaylistsPage {} }
    Component { id: playlistPage; PlaylistPage {} }

    // ---- shortcuts (Ctrl maps to ⌘ on macOS) ----------------------------------
    Shortcut { sequences: ["Media Play", "Media Pause", "Media Toggle Play/Pause"]; onActivated: player.togglePlayback() }
    Shortcut { sequence: "Media Next"; onActivated: player.next() }
    Shortcut { sequence: "Media Previous"; onActivated: player.previous() }
    Shortcut { sequence: "Space"; enabled: !(win.activeFocusItem && win.activeFocusItem.hasOwnProperty("cursorPosition")); onActivated: player.togglePlayback() }
    Shortcut { sequence: "Ctrl+Right"; onActivated: player.next() }
    Shortcut { sequence: "Ctrl+Left"; onActivated: player.previous() }
    Shortcut { sequence: "Ctrl+Up"; onActivated: player.volume = Math.min(1, player.volume + 0.05) }
    Shortcut { sequence: "Ctrl+Down"; onActivated: player.volume = Math.max(0, player.volume - 0.05) }
    Shortcut { sequence: "Ctrl+F"; onActivated: win.focusSearch() }
    Shortcut { sequence: "Ctrl+,"; onActivated: win.go("settings") }
    Shortcut { sequence: "Ctrl+N"; onActivated: win.newPlaylist([]) }
    Shortcut { sequence: "Ctrl+Alt+S"; onActivated: win.sidebarOpen = !win.sidebarOpen }
    Shortcut { sequence: "Ctrl+Alt+U"; onActivated: win.upNextOpen = !win.upNextOpen }
    Shortcut { sequence: "Escape"; enabled: win.nowPlayingOpen; onActivated: win.nowPlayingOpen = false }

    // Passive pointer tracking: the floating glass bar turns its highlights toward the cursor.
    HoverHandler { id: winHover }

    // ---- layout ---------------------------------------------------------
    // Layer 0: toolbar + pages, filling the whole window. The glass sidebar samples this item.
    Item {
        id: contentLayer
        anchors.fill: parent

        // Top strip. In floating mode the bar no longer carries the sidebar / back buttons,
        // so they live here, and it keeps the traffic lights and window drag area in place.
        Item {
            id: topStrip
            visible: win.floatingBar
            x: win.sidebarInset
            width: parent.width - x
            height: Theme.toolbarHeight
            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 12 + win.lightsRoom * (1 - win.sidebarOpenness)
                anchors.rightMargin: 12
                spacing: 6
                IconButton {
                    visible: !win.sidebarOpen
                    glyph: "sidebar"; size: 17; color: Theme.textSecondary; tip: "Show sidebar"
                    onClicked: win.sidebarOpen = true
                }
                IconButton {
                    visible: stack.depth > 1
                    glyph: "back"; size: 16; tip: "Back"
                    onClicked: stack.pop()
                }
                Item { Layout.fillWidth: true }
            }
        }

        Item {
            id: body
            y: win.pageTopInset > 0 ? 0 : Theme.toolbarHeight   // docked bar: pages start at the very top
            width: parent.width
            height: parent.height - y
            clip: true

            StackView {
                id: stack
                anchors.left: parent.left
                anchors.top: parent.top
                anchors.bottom: parent.bottom
                anchors.right: win.pushUpNext ? upNext.left : parent.right
                initialItem: homePage
                pushEnter: Transition { NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.base } }
                pushExit: Transition { NumberAnimation { property: "opacity"; from: 1; to: 0; duration: Theme.base } }
                popEnter: Transition { NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.base } }
                popExit: Transition { NumberAnimation { property: "opacity"; from: 1; to: 0; duration: Theme.base } }
                replaceEnter: Transition { NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.base } }
                replaceExit: Transition { NumberAnimation { property: "opacity"; from: 1; to: 0; duration: Theme.fast } }
            }

            UpNextPanel {
                id: upNext
                width: 300
                y: win.pageTopInset                 // below the docked bar
                height: parent.height - y
                // an overlaid panel sits under the floating bar, so keep its list clear of it
                bottomInset: win.floatingBar && !win.pushUpNext ? win.playerBarInset : 0
                x: win.upNextOpen ? body.width - width : body.width
                visible: x < body.width
                z: 10
                Behavior on x { NumberAnimation { duration: Theme.base; easing.type: Easing.OutCubic } }
            }
        }

    }

    // Layer 1: the player bar. It sits above the content (like the sidebar) so that, when it
    // floats, it can sample the content layer for its glass without sampling itself.
    Toolbar {
        id: toolbar
        readonly property real areaLeft: win.sidebarInset
        readonly property real areaRight: win.pushUpNext ? upNext.x : win.width     // slides with Up Next
        floating: win.floatingBar
        // docked bar: full window width (the sidebar covers its left part), blurred over the pages
        hideSeparator: win.floatingSidebar
        liquid: settings.values.liquidGlass
        glassSource: contentLayer
        pointer: winHover.point.position
        pointerActive: winHover.hovered
        width: floating ? Math.max(320, Math.min(880, areaRight - areaLeft - 2 * win.floatingBarGap))
                        : win.width
        height: floating ? win.floatingBarHeight : Theme.toolbarHeight
        x: floating ? Math.round(areaLeft + (areaRight - areaLeft - width) / 2) : 0
        y: floating ? win.height - height - win.floatingBarGap : 0
        z: 15
        sidebarVisible: win.sidebarOpen
        // room for the window buttons once the sidebar (which carries them) has slid away
        leftInset: floating ? 0 : win.sidebarInset + win.lightsRoom * (1 - win.sidebarOpenness)
        canGoBack: stack.depth > 1
        upNextOpen: win.upNextOpen
        onToggleSidebar: win.sidebarOpen = true
        onBack: stack.pop()
        onToggleUpNext: win.upNextOpen = !win.upNextOpen
        onExpandPlayer: win.nowPlayingOpen = true
    }

    // Layer 2: the glass sidebar, fixed above the content. Floating, it is an inset rounded
    // panel (gap on all sides); docked, it fills the full window height.
    Sidebar {
        id: sidebar
        width: win.sidebarWidth
        height: parent.height - 2 * win.sidebarGap
        x: win.sidebarInset - win.sidebarSpace + win.sidebarGap
        y: win.sidebarGap
        visible: win.sidebarInset > 0.5
        z: 20
        floating: win.floatingSidebar
        liquid: settings.values.liquidGlass
        pointer: winHover.point.position
        pointerActive: winHover.hovered
        current: win.page
        currentPlaylist: win.playlistId
        glassSource: contentLayer
        dragsWindow: win.unifiedTitleBar || win.customChrome
        onNavigate: (p) => win.go(p)
        onSearchSubmitted: (t) => win.runSearch(t)
        onOpenPlaylist: (id) => win.openPlaylist(id)
        onNewPlaylist: win.newPlaylist([])
        onEditPlaylist: (id) => win.editPlaylist(id)
        onDeletePlaylist: (id) => win.deletePlaylist(id)
        onToggleSidebar: win.sidebarOpen = false
        onStartDrag: win.startSystemMove()
    }

    // ---- full-screen player --------------------------------------------------
    NowPlayingPage {
        width: parent.width
        height: parent.height
        y: win.nowPlayingOpen ? 0 : parent.height
        visible: y < parent.height
        z: 50
        Behavior on y { NumberAnimation { duration: Theme.base * 1.3; easing.type: Easing.OutCubic } }
        onClose: win.nowPlayingOpen = false
        onOpenQueue: { win.nowPlayingOpen = false; win.upNextOpen = true }
    }

    Toast {
        bottomInset: win.playerBarInset
        message: win.notice.length ? win.notice
               : app.errorMessage.length ? app.errorMessage : player.errorMessage
        onDismissed: { win.notice = ""; app.clearError() }
    }

    // ---- playlist sheets and events -------------------------------------------
    PlaylistEditor {
        id: editor
        // a playlist made from the "+" button opens straight away so songs can be added;
        // one made from a song's menu already has its songs, so stay where you are
        onCreated: (id, withTracks) => { if (!withTracks) win.openPlaylist(id) }
    }
    ConfirmSheet { id: confirm }

    Connections {
        target: playlists
        function onMessage(text) { win.notice = text }
        function onRemoved(id) {
            if (win.page === "playlist" && win.playlistId === id) win.go("myplaylists")
        }
    }

    // ---- window controls -------------------------------------------------------
    // A Loader, so that with the setting off nothing exists: no hit area, no placeholder.
    // Floating sidebar: they sit inside the glass panel, so they shift in with it.
    Loader {
        active: win.customChrome
        x: 14 + (win.floatingSidebar ? 14 : 0) * win.sidebarOpenness
        y: Math.round((Theme.toolbarHeight - 12) / 2) + win.sidebarGap * win.sidebarOpenness
        z: 100
        sourceComponent: TrafficLights { window: win }
    }

    // A frameless window has no native frame to grab, so provide thin resize handles
    // (only while the custom chrome is on and the window isn't maximized).
    Loader {
        anchors.fill: parent
        active: win.customChrome && !win.zoomed
        z: 90
        sourceComponent: Item {
            // inline components can't see Main's ids, so the window comes from Window.window
            component Edge: MouseArea {
                required property int edges
                hoverEnabled: true
                acceptedButtons: Qt.LeftButton
                onPressed: Window.window.startSystemResize(edges)
            }
            readonly property int t: 5      // edge thickness
            readonly property int c: 10     // corner size
            Edge { edges: Qt.LeftEdge; cursorShape: Qt.SizeHorCursor; x: 0; y: parent.c; width: parent.t; height: parent.height - 2 * parent.c }
            Edge { edges: Qt.RightEdge; cursorShape: Qt.SizeHorCursor; x: parent.width - parent.t; y: parent.c; width: parent.t; height: parent.height - 2 * parent.c }
            Edge { edges: Qt.TopEdge; cursorShape: Qt.SizeVerCursor; x: parent.c; y: 0; width: parent.width - 2 * parent.c; height: parent.t }
            Edge { edges: Qt.BottomEdge; cursorShape: Qt.SizeVerCursor; x: parent.c; y: parent.height - parent.t; width: parent.width - 2 * parent.c; height: parent.t }
            Edge { edges: Qt.LeftEdge | Qt.TopEdge; cursorShape: Qt.SizeFDiagCursor; x: 0; y: 0; width: parent.c; height: parent.c }
            Edge { edges: Qt.RightEdge | Qt.BottomEdge; cursorShape: Qt.SizeFDiagCursor; x: parent.width - parent.c; y: parent.height - parent.c; width: parent.c; height: parent.c }
            Edge { edges: Qt.RightEdge | Qt.TopEdge; cursorShape: Qt.SizeBDiagCursor; x: parent.width - parent.c; y: 0; width: parent.c; height: parent.c }
            Edge { edges: Qt.LeftEdge | Qt.BottomEdge; cursorShape: Qt.SizeBDiagCursor; x: 0; y: parent.height - parent.c; width: parent.c; height: parent.c }
        }
    }

    // Hairline edge for the frameless window, which has no native border.
    Rectangle {
        anchors.fill: parent
        visible: win.customChrome && !win.zoomed
        z: 95
        color: "transparent"
        border.width: 1
        border.color: Theme.alpha(Theme.text, Theme.dark ? 0.14 : 0.12)
    }
}
