# Swift

A desktop music client built with Qt 6, Qt Quick and C++20. The UI is modelled on Apple Music for
macOS: a full-height sidebar with inline search, a unified top toolbar (transport, volume and
the "LCD" now-playing display), striped song tables with hover-only row actions, an Up Next
side panel and a full-screen player. It uses no Apple assets: every icon is drawn in
`Glyph.qml`, and the system font is used on macOS. Music data comes from the unofficial YouTube Music (InnerTube) API behind a
replaceable provider interface.

## Requirements

- Qt 6.5 or newer with: Core, Gui, Qml, Quick, QuickControls2, Network, Multimedia
  (the `QtQuick.Effects` QML module ships with Qt Quick 6.5+)
- CMake 3.21+, a C++20 compiler (GCC 11+, Clang 14+, MSVC 2022)
- Optional but needed for playback of most tracks: [`yt-dlp`](https://github.com/yt-dlp/yt-dlp) on your `PATH`
  (see "Playback" below)

## Build and run

    cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/Qt/6.x/<kit> -DCMAKE_BUILD_TYPE=Release
    cmake --build build
    ./build/Swift            # build/Swift.app on macOS, build\Release\Swift.exe on Windows

## Layout

    src/api/          MusicProvider (interface), YouTubeMusicClient (unofficial API + parser),
                      ApiRequest (async JSON POST, timeout, retry/backoff, error mapping), Types
    src/models/       SongModel, QueueModel, CollectionModel (QAbstractListModel)
    src/playback/     MusicPlayer: QMediaPlayer, queue, shuffle/repeat, session restore
    src/services/     SettingsService, LibraryService (likes, recents), CacheService (artwork)
    src/AppController browsing facade for QML: search, home feed, album/artist/playlist pages
    qml/              Main.qml, themes/Theme.qml (singleton design tokens), components/ (Toolbar, LCD,
                      Sidebar, TrackRow, UpNextPanel, Shelf, ...), pages/

All networking is in C++. QML only sees `app`, `player`, `library`, `settings` and `cache`.
To swap the backend, implement `MusicProvider` and construct it in `main.cpp`.

## Playback

`resolveStream` first asks the player endpoint for a directly playable audio URL. Web responses
usually contain signed formats instead, so Swift then runs the command in
Settings > Network (default `yt-dlp`, called with `-f bestaudio -g <url>`) and plays the URL it prints.
Without that tool, search and browsing work but most tracks report "needs a stream resolver".
The command is user-configured and never hard-coded to a credential.

Using unofficial endpoints and stream extraction may conflict with YouTube's Terms of Service.
Review them before distributing the app.

## Playlists

Library > Playlists (also listed under My Playlists in the sidebar, `Ctrl/⌘+N` to create one).

- **Create, edit, delete:** a sheet with cover preview, name and description. Right-click a playlist
  in the sidebar or on the Playlists page, or use its "…" button.
- **Add songs:** "Add to Playlist" in any song's menu (Search, Home, albums, Liked Songs, Up Next), "Add to
  Playlist" on album/playlist pages for the whole list, or "Save" in Up Next to turn the queue into a playlist.
  Songs already in a playlist are skipped.
- **Custom order:** drag a row to move it (the list scrolls when you hold near the edge), or use
  Move to Top / Up / Down / Bottom in the song menu, or Alt+↑ / Alt+↓ on a focused row. Delete removes it.
- **Sorting:** click Title, Artist, Album or Time in the column header (click again to reverse). The arrow
  icon at the left of the header returns to playlist order. Sorting only changes the view; choose
  "Save as Playlist Order" to keep it. Dragging is off while a sort is active.
- **Storage:** `playlists.json` in the app data folder (written atomically), with song metadata and
  artwork URLs, so playlists open offline.

Code: `src/services/PlaylistService.*` and `qml/pages/Playlist*.qml`.

## Authentication

Browsing works signed out. To sign in, paste the `Cookie` header from a logged-in
music.youtube.com request into Settings > Account. Swift derives the `SAPISIDHASH` header from
it. The cookie is stored in plain `QSettings`; moving it to the OS keychain (for example QtKeychain)
is a sensible next step.

## Status

Implemented: shell and responsive navigation, light/dark/system themes, accent colors, a player bar that
can dock in the top toolbar or float as a blurred glass bar at the bottom (Settings > Appearance > Player bar),
an Info page (version, features, credits), search
(all/songs/albums/artists/playlists), album/artist/playlist pages, home feed, toolbar player (LCD),
full-screen player, Up Next / History panel with queue editing, shuffle/repeat, seek and volume, likes, recents,
persisted session and settings, on-disk artwork cache, keyboard shortcuts and media keys
(via `Shortcut`, so they work while the app has focus).

Not yet:
- OS-level media controls (MPRIS, Now Playing, SMTC) and global media keys
- System tray and system notifications (the Notifications setting is saved but has no effect yet)
- Account library (your YouTube Music playlists and uploads); Artists, Albums and Browse Playlists
  currently run filtered searches. Playlists you create in Swift are stored locally only.
- Background playback is limited to audio continuing while the window is unfocused or minimized
- Unit tests; this code has not been compiled yet, so expect a round of compiler and QML fixes

## Notes on the unofficial API

The search filter `params` strings, client name and response shapes are undocumented and change.
They live only in `src/api/YouTubeMusicClient.cpp`. If a request starts failing with
"unexpected response", that file is where to look.
